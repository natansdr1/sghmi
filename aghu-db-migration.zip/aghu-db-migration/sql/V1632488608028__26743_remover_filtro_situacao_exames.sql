create
or replace view agh.v_ael_exame_mat_analise(sigla, man_seq, descricao_exame, descricao_usual_exame, descricao_material, nome_usual_material, ind_dependente, ind_cci, ind_exige_desc_mat_anls, ind_limita_solic, ind_comedi, ind_situacao) as
SELECT ema.exa_sigla       AS sigla,
       ema.man_seq,
       exa.descricao       AS descricao_exame,
       exa.descricao_usual AS descricao_usual_exame,
       man.descricao       AS descricao_material,
       (exa.descricao_usual::text || ' /  '::text) || man.descricao::text AS nome_usual_material,
       ema.ind_dependente,
       ema.ind_cci,
       man.ind_exige_desc_mat_anls,
       ema.ind_limita_solic,
       ema.ind_comedi,
       ema.ind_situacao
FROM agh.ael_materiais_analises man,
     agh.ael_exames exa,
     agh.ael_exames_material_analise ema
WHERE exa.sigla::text = ema.exa_sigla::text
  AND man.seq = ema.man_seq;

alter table agh.v_ael_exame_mat_analise owner to postgres;

grant
insert,
select,
update,
delete, truncate, references, trigger
on agh.v_ael_exame_mat_analise to acesso_completo;

grant select on agh.v_ael_exame_mat_analise to acesso_leitura;