do
$body$
begin
    if exists (
        select null
        from information_schema.check_constraints
        where constraint_schema = 'agh'
              and constraint_name = 'mbc_mse_ck2'
        ) then begin
alter table agh.mbc_mvto_sala_esp_equipes drop constraint mbc_mse_ck2;
raise notice 'constraint mbc_mse_ck2 excluída da tabela agh.mbc_mvto_sala_esp_equipes.';
exception
            when others then
                raise notice 'Erro na remoção da constraint';
                raise info 'Error Name:%', sqlerrm;
                raise info 'Error State:%', sqlstate;
end;
end if;

begin
alter table agh.mbc_mvto_sala_esp_equipes add constraint mbc_mse_ck2 check
    ((puc_ind_funcao_prof)::text = any
    (array [('MPF'::character varying)::text, ('ANP'::character varying)::text, ('ANR'::character varying)::text,
    ('ENF'::character varying)::text, ('INS'::character varying)::text, ('MAX'::character varying)::text,
    ('CIR'::character varying)::text, ('MCO'::character varying)::text, ('OPF'::character varying)::text,
    ('OCD'::character varying)::text, ('ANC'::character varying)::text]));
raise notice 'constraint mbc_mse_ck2 criada com sucesso na tabela agh.mbc_mvto_sala_esp_equipes.';
exception
        when others then
            raise notice 'Erro na criação da constraint mbc_mse_ck2 na tabela agh.mbc_mvto_sala_esp_equipes.';
            raise info 'Error Name:%', sqlerrm;
            raise info 'Error State:%', sqlstate;
end;
end;
$body$