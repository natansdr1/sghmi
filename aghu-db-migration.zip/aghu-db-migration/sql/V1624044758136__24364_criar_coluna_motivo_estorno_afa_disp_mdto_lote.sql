DO $$
BEGIN

	IF NOT EXISTS (
		SELECT
		FROM information_schema.columns
		WHERE table_schema = 'agh'
		AND table_name = 'afa_disp_mdto_lote'
		AND column_name = 'tod_seq_estornado'
	) THEN
ALTER TABLE agh.afa_disp_mdto_lote ADD COLUMN tod_seq_estornado smallint;
COMMENT ON COLUMN agh.afa_disp_mdto_lote.tod_seq_estornado IS 'Guardar o motivo do estorno da dispensaçao por lote';
	RAISE NOTICE 'EXECUTADO ALTERAÇÃO: #24364 - Novas colunas agh.afa_disp_mdto_lote';
END IF;

END $$