DO $$
DECLARE
  descricao_length INT;
  descricao_usual_length INT;
BEGIN
  RAISE INFO 'Validando tamanho de campos (descricao, descricao_usual) para tabela ael_exames_jn';

  SELECT character_maximum_length INTO descricao_length
  FROM information_schema.columns
  WHERE table_name = 'ael_exames_jn'
  AND column_name ='descricao';

  SELECT character_maximum_length INTO descricao_usual_length
  FROM information_schema.columns
  WHERE table_name = 'ael_exames_jn'
  AND column_name = 'descricao_usual';

  IF descricao_length < 200 THEN
    ALTER TABLE agh.ael_exames_jn
    ALTER COLUMN descricao TYPE VARCHAR(200);
    RAISE INFO 'Coluna descricao da tabela ael_exames_jn definida para VARCHAR(200)';
  ELSE
    RAISE INFO 'Coluna descricao da tabela ael_exames_jn já definida para VARCHAR(%)', descricao_length;
  END IF;

  IF descricao_usual_length < 200 THEN
    ALTER TABLE agh.ael_exames_jn
    ALTER COLUMN descricao_usual TYPE VARCHAR(200);
    RAISE INFO 'Coluna descricao_usual da tabela ael_exames_jn definida para VARCHAR(200)';
  ELSE
    RAISE INFO 'Coluna descricao_usual da tabela ael_exames_jn já definida para VARCHAR(%)', descricao_length;
  END IF;

  RAISE INFO 'Realizado ajuste de campos (descricao, descricao_usual) para tabela ael_exames_jn';
END;
$$;