-- agh.sce_mat_itens_digitacao definição
DO
$$
BEGIN
    if not exists(select null from information_schema.sequences where sequence_schema = 'agh' and sequence_name = 'sce_mat_itens_digitacao_seq_sq1') then
        create sequence agh.sce_mat_itens_digitacao_seq_sq1 increment by 1 minvalue 1 maxvalue 9223372036854775807 start with 1 no cycle;
    end if;

    ALTER SEQUENCE agh.sce_mat_itens_digitacao_seq_sq1 OWNER TO postgres;
    GRANT ALL ON SEQUENCE agh.sce_mat_itens_digitacao_seq_sq1 TO postgres;
    GRANT ALL ON SEQUENCE agh.sce_mat_itens_digitacao_seq_sq1 TO acesso_completo;
    GRANT SELECT ON SEQUENCE agh.sce_mat_itens_digitacao_seq_sq1 TO acesso_leitura;

    if not exists (select 1 from information_schema.tables where table_schema = 'agh'and table_name = 'agh.sce_mat_itens_digitacao') then
        CREATE TABLE IF NOT EXISTS agh.sce_mat_itens_digitacao(
            seq int8 DEFAULT nextval('agh.sce_mat_itens_digitacao_seq_sq1'),
            seq_itens_mat_inventario int8 NOT NULL,
            seq_lote int4 NULL,
            cod_lote varchar(20) NULL,
            validade_lote date NULL,
            quantidade_lote int4 NOT NULL,
            fora_do_inventario boolean DEFAULT FALSE NOT NULL,
            servidor_matricula int4 NOT NULL,
            servidor_vinculo_codigo int2 NOT NULL,
            quantidade_inicial_lote int4 NULL,
            mcm_codigo int4 NULL,
            material_sem_lote_valido bool DEFAULT false NOT NULL,
            CONSTRAINT sce_mat_itens_digitacao_pk PRIMARY KEY (seq)
        );
        
        GRANT ALL ON TABLE agh.sce_mat_itens_digitacao TO acesso_completo;
        GRANT SELECT ON TABLE agh.sce_mat_itens_digitacao TO acesso_leitura;

        COMMENT ON COLUMN agh.sce_mat_itens_digitacao.seq IS 'Chave primaria PK';
        COMMENT ON COLUMN agh.sce_mat_itens_digitacao.seq_itens_mat_inventario IS 'Sequencia de itens_mat_inventario';
        COMMENT ON COLUMN agh.sce_mat_itens_digitacao.seq_lote IS 'Sequencia do lote';
        COMMENT ON COLUMN agh.sce_mat_itens_digitacao.cod_lote IS 'Codigo do lote FK';
        COMMENT ON COLUMN agh.sce_mat_itens_digitacao.validade_lote IS 'Validade do lote';
        COMMENT ON COLUMN agh.sce_mat_itens_digitacao.quantidade_lote IS 'Quantidade do lote';
        COMMENT ON COLUMN agh.sce_mat_itens_digitacao.fora_do_inventario IS 'Define se o lote não existe no almoxarifado do invetario';
        COMMENT ON COLUMN agh.sce_mat_itens_digitacao.servidor_matricula IS 'Matricula do ultimo servidor que inseriu ou atualizou o registro';
        COMMENT ON COLUMN agh.sce_mat_itens_digitacao.servidor_vinculo_codigo IS 'Vinculo do ultimo servidor que inseriu ou atualizou o registro';
        COMMENT ON COLUMN agh.sce_mat_itens_digitacao.quantidade_inicial_lote IS 'Quantidade inicial do lote antes do inventario';
        COMMENT ON COLUMN agh.sce_mat_itens_digitacao.mcm_codigo IS 'Codigo da marca comercial do material';
        COMMENT ON COLUMN agh.sce_mat_itens_digitacao.material_sem_lote_valido IS 'Material que não tinha lotes validos(data ou quantidade) para aquele inventário';

        -- Permissões
        ALTER TABLE agh.sce_mat_itens_digitacao OWNER TO postgres;
        GRANT ALL ON TABLE agh.sce_mat_itens_digitacao TO postgres;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace WHERE c.relname = 'sce_mat_itens_digitacao_pk_idx' AND n.nspname = 'agh') THEN
        CREATE UNIQUE INDEX sce_mat_itens_digitacao_pk_idx ON agh.sce_mat_itens_digitacao USING btree (seq);
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace WHERE c.relname = 'seq_cod_lote_unique_idx' AND n.nspname = 'agh') THEN
        CREATE UNIQUE INDEX seq_cod_lote_unique_idx ON agh.sce_mat_itens_digitacao USING btree (seq_itens_mat_inventario, cod_lote, seq_lote);
    END IF;

    IF NOT EXISTS (SELECT 1 FROM information_schema.table_constraints WHERE constraint_schema = 'agh' AND constraint_name = 'sce_mid_imi_fk1') THEN
        ALTER TABLE agh.sce_mat_itens_digitacao ADD CONSTRAINT sce_mid_imi_fk1 FOREIGN KEY (seq_itens_mat_inventario) REFERENCES agh.sce_itens_mat_inventario (seq);
    END IF;

    IF NOT EXISTS (SELECT 1 FROM information_schema.table_constraints WHERE constraint_schema = 'agh' AND constraint_name = 'sce_mid_mcm_fk1') THEN
        ALTER TABLE agh.sce_mat_itens_digitacao ADD CONSTRAINT sce_mid_mcm_fk1 FOREIGN KEY (mcm_codigo) REFERENCES agh.sco_marcas_comerciais (codigo);
    END IF;

    IF NOT EXISTS (SELECT 1 FROM information_schema.table_constraints WHERE constraint_schema = 'agh' AND constraint_name = 'sce_mid_rap_fk1') THEN
        ALTER TABLE agh.sce_mat_itens_digitacao ADD CONSTRAINT sce_mid_rap_fk1 FOREIGN KEY (servidor_matricula, servidor_vinculo_codigo) REFERENCES agh.rap_servidores (matricula, vin_codigo);
    END IF;

    IF NOT EXISTS (SELECT 1 FROM information_schema.table_constraints WHERE constraint_schema = 'agh' AND constraint_name = 'seq_cod_lote_unique') THEN
        ALTER TABLE agh.sce_mat_itens_digitacao ADD CONSTRAINT seq_cod_lote_unique UNIQUE (seq_itens_mat_inventario, cod_lote, seq_lote);
    END IF;
END $$;

--- fim