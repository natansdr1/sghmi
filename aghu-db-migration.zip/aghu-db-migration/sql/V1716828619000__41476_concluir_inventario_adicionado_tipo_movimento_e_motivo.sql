DO
$$
BEGIN

IF NOT EXISTS (SELECT 1 FROM agh.sce_tipo_movimentos WHERE seq = 30 AND complemento = 4) THEN
    INSERT INTO agh.sce_tipo_movimentos
    (seq, complemento, descricao, ind_movimento, ind_situacao, ind_altera_af, ind_gera_titulo, ind_exige_motivo, ind_qtde_disponivel, ind_qtde_bloqueada, ind_uso_cm, ind_uso_residuo, ind_alt_valr_estq_almox_mvto, ind_guarda_qtde_pos_mvto, ind_ccusto_requisita, ind_ccusto_aplica, ind_fornecedor_prop, ind_nro_doc_geracao, ind_almox, ind_guarda_valor, ind_guarda_cm_gerado, ind_alt_valr_estq_geral, ind_almox_complemento, ind_qtde_bloq_problema, ind_guarda_historico, ind_depende_caract, ind_operacao_basica, ind_guarda_residuo_utlz, ind_guarda_residuo_ger, ind_qtde_entrada_valid, ind_qtde_consumo_valid, ind_qtde_disponivel_valid, ind_documento_validade, ind_movimento_consumo, ind_usa_qtde_disponivel, tmv_seq, tmv_complemento, tmv_seq_proximo, tmv_complemento_proximo, ind_alt_qtde_estq_almox_mvto, ind_gera_reg_movimento, ind_trata_devolucao, sigla, ind_bloqueio_uso, ordem, ind_movimento_empr, "version", ind_esl)
    VALUES(30, 4, 'AJUSTE MAIS CONCLUIR INVENTARIO', 'MAN', 'A', 'N', 'N', 'S', 'S', 'N', 'U', 'N', 'S', 'S', 'N', 'N', 'S', 'N', 'S', 'S', 'N', 'S', 'N', 'N', 'N', 'N', 'CR', 'N', 'N', 'NN', 'NN','CR', 'N', 'N', 'N', NULL, NULL, NULL, NULL, 'S', 'S', 'N', 'AJSTE', 'N', 5, 'N', 0, NULL);
END IF;

IF NOT EXISTS (SELECT 1 FROM agh.sce_tipo_movimentos WHERE seq = 29 AND complemento = 5) THEN
    INSERT INTO agh.sce_tipo_movimentos
    (seq, complemento, descricao, ind_movimento, ind_situacao, ind_altera_af, ind_gera_titulo, ind_exige_motivo, ind_qtde_disponivel, ind_qtde_bloqueada, ind_uso_cm, ind_uso_residuo, ind_alt_valr_estq_almox_mvto, ind_guarda_qtde_pos_mvto, ind_ccusto_requisita, ind_ccusto_aplica, ind_fornecedor_prop, ind_nro_doc_geracao, ind_almox, ind_guarda_valor, ind_guarda_cm_gerado, ind_alt_valr_estq_geral, ind_almox_complemento, ind_qtde_bloq_problema, ind_guarda_historico, ind_depende_caract, ind_operacao_basica, ind_guarda_residuo_utlz, ind_guarda_residuo_ger, ind_qtde_entrada_valid, ind_qtde_consumo_valid, ind_qtde_disponivel_valid, ind_documento_validade, ind_movimento_consumo, ind_usa_qtde_disponivel, tmv_seq, tmv_complemento, tmv_seq_proximo, tmv_complemento_proximo, ind_alt_qtde_estq_almox_mvto, ind_gera_reg_movimento, ind_trata_devolucao, sigla, ind_bloqueio_uso, ordem, ind_movimento_empr, "version", ind_esl)
    VALUES(29, 5, 'AJUSTE MENOS CONCLUIR INVENTARIO', 'MAN', 'A', 'N', 'N', 'S', 'S', 'N', 'U', 'N', 'S', 'S', 'N', 'N', 'S', 'N', 'S', 'S', 'N', 'S', 'N', 'N', 'N', 'N', 'DB', 'N', 'N', 'NN', 'NN','DB', 'N', 'N', 'N', NULL, NULL, NULL, NULL, 'S', 'S', 'N', 'AJSTE', 'N', 24, 'N', 0, NULL);
END IF;

IF NOT EXISTS (SELECT 1 FROM agh.sce_motivo_movimentos WHERE tmv_seq = 30 AND tmv_complemento = 4) THEN
    INSERT INTO agh.sce_motivo_movimentos
    (tmv_seq, tmv_complemento, numero, descricao, ind_situacao, "version")
    VALUES(30, 4, 58, 'GANHOS COM CONCLUIR INVENTARIO', 'A', 0);
END IF;

IF NOT EXISTS (SELECT 1 FROM agh.sce_motivo_movimentos WHERE tmv_seq = 29 AND tmv_complemento = 5) THEN
    INSERT INTO agh.sce_motivo_movimentos
    (tmv_seq, tmv_complemento, numero, descricao, ind_situacao, "version")
    VALUES(29, 5, 63, 'PERDAS COM CONCLUIR INVENTARIO', 'A', 0);
END IF;
END $$;