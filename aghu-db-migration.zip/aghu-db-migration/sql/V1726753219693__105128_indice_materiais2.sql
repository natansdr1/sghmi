do
$$
begin   
IF not EXISTS (select 1 from pg_indexes ix where ix.schemaname = 'agh' and tablename = 'sce_movimento_materiais' and indexname = 'sce_movimento_materiais_i_4') THEN
  CREATE INDEX sce_movimento_materiais_i_4 ON agh.sce_movimento_materiais USING btree (extract('month' from dt_competencia)) tablespace tblspc_idx;
   RAISE NOTICE 'Indice agh.sce_movimento_materiais.sce_movimento_materiais_i_4 criado com sucesso.';
else
   RAISE NOTICE 'Indice já existe agh.sce_movimento_materiais.sce_movimento_materiais_i_4 nada foi feito.';	
END IF;

IF not EXISTS (select 1 from pg_indexes ix where ix.schemaname = 'agh' and tablename = 'sce_movimento_materiais' and indexname = 'sce_movimento_materiais_i_5') THEN
  CREATE INDEX sce_movimento_materiais_i_5 ON agh.sce_movimento_materiais USING btree (extract('year' from dt_competencia)) tablespace tblspc_idx;
   RAISE NOTICE 'Indice agh.sce_movimento_materiais.sce_movimento_materiais_i_5 criado com sucesso.';
else
   RAISE NOTICE 'Indice já existe agh.sce_movimento_materiais.sce_movimento_materiais_i_5 nada foi feito.';	
END IF;

end;
$$