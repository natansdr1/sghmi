DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM agh.agh_parametros WHERE nome = 'SCHEDULERINIT_CARGA_TABELA_EXTRATO_CENSO_LEITO_DIA') THEN
    INSERT INTO agh.agh_parametros (
        seq, nome, vlr_texto, criado_em, criado_por, sis_sigla, mantem_historico
    )
SELECT
    nextval('agh.agh_psi_sq1'),
    'SCHEDULERINIT_CARGA_TABELA_EXTRATO_CENSO_LEITO_DIA',
    'S',
    now(),
    'SYSTEM',
    'AGH',
    'N';
RAISE NOTICE 'Parâmetros inseridos com sucesso.';
end if;

 IF NOT EXISTS (SELECT 1 FROM agh.agh_parametros WHERE nome = 'SCHEDULERINIT_CORRIGIR_CALCULO_INDICADOR_PACIENTE') THEN
    INSERT INTO agh.agh_parametros (
        seq, nome, vlr_texto, criado_em, criado_por, sis_sigla, mantem_historico
    )
SELECT
    nextval('agh.agh_psi_sq1'),
    'SCHEDULERINIT_CORRIGIR_CALCULO_INDICADOR_PACIENTE',
    'S',
    now(),
    'SYSTEM',
    'AGH',
    'N';
RAISE NOTICE 'Parâmetros inseridos com sucesso.';
end if;

RAISE NOTICE 'Aplicando permissões nas sequências.';

EXECUTE 'ALTER SEQUENCE agh.ain_calculo_paciente_seq_sq1 OWNER TO postgres';
EXECUTE 'GRANT ALL ON SEQUENCE agh.ain_calculo_paciente_seq_sq1 TO ugen_aghu';
EXECUTE 'GRANT ALL ON SEQUENCE agh.ain_calculo_paciente_seq_sq1 TO ugen_quartz';
EXECUTE 'GRANT ALL ON SEQUENCE agh.ain_calculo_paciente_seq_sq1 TO postgres';
EXECUTE 'GRANT ALL ON SEQUENCE agh.ain_calculo_paciente_seq_sq1 TO acesso_completo';
EXECUTE 'GRANT ALL ON SEQUENCE agh.ain_calculo_paciente_seq_sq1 TO acesso_leitura';

EXECUTE 'ALTER SEQUENCE agh.ain_extrato_censo_leito_dia_seq_sq1 OWNER TO postgres';
EXECUTE 'GRANT ALL ON SEQUENCE agh.ain_extrato_censo_leito_dia_seq_sq1 TO ugen_aghu';
EXECUTE 'GRANT ALL ON SEQUENCE agh.ain_extrato_censo_leito_dia_seq_sq1 TO ugen_quartz';
EXECUTE 'GRANT ALL ON SEQUENCE agh.ain_extrato_censo_leito_dia_seq_sq1 TO postgres';
EXECUTE 'GRANT ALL ON SEQUENCE agh.ain_extrato_censo_leito_dia_seq_sq1 TO acesso_completo';
EXECUTE 'GRANT ALL ON SEQUENCE agh.ain_extrato_censo_leito_dia_seq_sq1 TO acesso_leitura';

RAISE NOTICE 'Execução finalizada.';
END $$;