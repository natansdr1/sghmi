do $$
begin
    grant select,insert on agh.sce_itens_mat_inventario_seq_sq1 to acesso_completo;
    grant select,insert on agh.sce_inventario_seq_sq1 to acesso_completo;

    grant select,insert on agh.sce_itens_mat_inventario_seq_sq1 to acesso_leitura;
    grant select,insert on agh.sce_inventario_seq_sq1 to acesso_leitura;
end $$;