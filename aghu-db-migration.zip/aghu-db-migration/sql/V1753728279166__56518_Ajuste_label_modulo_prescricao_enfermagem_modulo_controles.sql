DO $$
DECLARE
    v_id_pai_origem        INT; -- ID do menu 'Controles do Paciente' a ser removido
    v_id_pai_destino       INT; -- ID do menu 'Enfermagem' que receberá os filhos
    v_filhos_movidos       INT := 0; -- Contador de filhos movidos
    v_max_ordem_destino    INT; -- A maior ordem existente nos filhos do menu de destino
    v_filho                RECORD; -- Para iterar sobre os filhos a serem movidos
BEGIN
    -- =========================================================================
    -- ETAPA 0: VALIDAÇÃO DO ESTADO INICIAL (sem alterações)
    -- =========================================================================
    RAISE NOTICE 'ETAPA 0: Validando o estado inicial dos menus...';

    SELECT id INTO v_id_pai_origem
    FROM casca.csc_menu
    WHERE 
        nome = 'Controles do Paciente' 
        AND classe_icone = 'silk-controles-paciente' 
        AND parent_id = (select id from casca.csc_menu where nome ilike 'Enfermagem' and parent_id is null);

    SELECT id INTO v_id_pai_destino
    FROM casca.csc_menu
    WHERE nome = 'Enfermagem' AND parent_id IS NULL;

    IF v_id_pai_origem IS NULL OR v_id_pai_destino IS NULL THEN
        RAISE EXCEPTION 'AÇÃO CANCELADA: Não foi possível encontrar ambos os menus raiz. Verifique se existe um "Enfermagem" e um "Controles do Paciente" (com classe_icone silk-controles-paciente), ambos com parent_id NULO.';
    END IF;
    IF v_id_pai_origem = v_id_pai_destino THEN
        RAISE EXCEPTION 'AÇÃO CANCELADA: O menu de origem e destino são os mesmos.';
    END IF;
    RAISE NOTICE 'Menus validados. Origem ID: %, Destino ID: %', v_id_pai_origem, v_id_pai_destino;

    -- =========================================================================
    -- ETAPA 1: MOVER OS FILHOS COM REORDENAÇÃO (Lógica corrigida)
    -- =========================================================================
    RAISE NOTICE 'ETAPA 1: Reatribuindo filhos de "Controles do Paciente" para "Enfermagem" com reordenação...';

    -- *** NOVO ***: Encontrar a ordem máxima atual no destino para evitar conflitos.
    -- COALESCE garante que, se não houver filhos, começaremos com 0.
    SELECT COALESCE(MAX(ordem), 0) INTO v_max_ordem_destino
    FROM casca.csc_menu
    WHERE parent_id = v_id_pai_destino;
    RAISE NOTICE 'Ordem máxima encontrada no destino: %. Os novos filhos começarão a partir do próximo número.', v_max_ordem_destino;

    -- *** NOVO ***: Iterar sobre cada filho a ser movido para atribuir uma nova ordem.
    FOR v_filho IN
        SELECT id FROM casca.csc_menu WHERE parent_id = v_id_pai_origem ORDER BY ordem LOOP
        
        -- Incrementa o contador da ordem para o próximo valor disponível.
        v_max_ordem_destino := v_max_ordem_destino + 1;

        -- Atualiza o filho atual com o novo pai e a nova ordem.
        UPDATE casca.csc_menu
        SET
            parent_id = v_id_pai_destino,
            ordem = v_max_ordem_destino
        WHERE id = v_filho.id;
        
        v_filhos_movidos := v_filhos_movidos + 1;
    END LOOP;

    RAISE NOTICE '% filho(s) foram movidos e reordenados com sucesso.', v_filhos_movidos;

    -- =========================================================================
    -- ETAPA 2: DELETAR O PAI ANTIGO (sem alterações)
    -- =========================================================================
    RAISE NOTICE 'ETAPA 2: Removendo o menu "Controles do Paciente" (ID: %) que agora está vazio...', v_id_pai_origem;
    DELETE FROM casca.csc_menu WHERE id = v_id_pai_origem;
    RAISE NOTICE 'Menu de origem removido com sucesso.';

    -- =========================================================================
    -- ETAPA 3: RENOMEAR O NOVO PAI (sem alterações)
    -- =========================================================================
    RAISE NOTICE 'ETAPA 3: Renomeando o menu "Enfermagem" (ID: %) para "Controles do Paciente"...', v_id_pai_destino;
    UPDATE casca.csc_menu SET nome = 'Controles do Paciente' WHERE id = v_id_pai_destino;
    RAISE NOTICE 'Menu de destino renomeado com sucesso.';
    
    RAISE NOTICE 'Script de refatoração concluído!';

END $$;