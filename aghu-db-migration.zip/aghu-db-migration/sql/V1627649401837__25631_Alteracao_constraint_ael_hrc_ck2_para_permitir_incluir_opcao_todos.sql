DO $$
BEGIN

    ALTER TABLE agh.ael_horario_rotina_coletas DROP CONSTRAINT ael_hrc_ck2;
    ALTER TABLE agh.ael_horario_rotina_coletas
        ADD CONSTRAINT ael_hrc_ck2 CHECK
            (dia::text = ANY (ARRAY['DOM'::character varying::text, 'FER'::character varying::text,
        'FERM'::character varying::text, 'FERT'::character varying::text, 'SAB'::character varying::text,
        'SEG'::character varying::text, 'TER'::character varying::text, 'QUA'::character varying::text,
        'QUI'::character varying::text, 'SEX'::character varying::text, 'VFE'::character varying::text,
        'TOD'::character varying::text]));

END $$