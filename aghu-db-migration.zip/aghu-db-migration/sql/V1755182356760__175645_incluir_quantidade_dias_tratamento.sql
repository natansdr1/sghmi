DO $$
BEGIN

    IF NOT EXISTS(
            SELECT 1
            FROM information_schema.columns
            WHERE table_schema = 'AGH'
                AND table_name = 'MPM_MOD_BASIC_MDTOS'
                AND column_name = 'QUANTIDADE_DIAS_TRATAMENTO'
        ) THEN
ALTER TABLE agh.MPM_MOD_BASIC_MDTOS ADD COLUMN quantidade_dias_tratamento int4 NULL;
COMMENT ON COLUMN agh.fat_espelhos_proced_amb.quantidade_nok IS 'Quantidade de dias de tratamento para medicamentos controlados.';
        RAISE NOTICE 'Criação da Coluna: QUANTIDADE_DIAS_TRATAMENTO, na Tabela: AGH.MPM_MOD_BASIC_MDTOS #175645';
END IF;

END $$