DO $$
DECLARE
view_def text;
    new_def text;
BEGIN
    -- Definição esperada da view (sem 'CREATE OR REPLACE VIEW', apenas o SELECT)
    new_def := '
    SELECT x.atd_seq,
           x.seq,
           x.dt_referencia,
           x.dthr_inicio,
           x.dthr_fim,
           x.atd_seq_local,
           coalesce(x.prontuario,p.prontuario) as prontuario,
           x.lto_lto_id,
           x.qrt_numero,
           x.unf_seq,
           x.trp_seq,
           x.codigo,
           x.nome,
           x.apa_atd_seq,
           x.apa_seq,
           x.seqp,
           x.countsolic,
           x.countdisp,
           x.countconf,
           x.countenv,
           x.counttriado,
           x.countocorr,
           (((COALESCE(unf.andar, '''')::text || '' '') || COALESCE(unf.ind_ala, '''')::text) || '' - '') || COALESCE(unf.descricao, '''')::text AS unf_descricao,
           CASE
               WHEN CASE WHEN atd.ind_pac_atendimento::text = ''S'' AND cuf.unf_seq IS NOT NULL THEN ''false'' ELSE ''true'' END = ''true'' THEN ''''
               WHEN NOT EXISTS (
                   SELECT 1 FROM agh.mpm_prescricao_medicas pm
                   WHERE pm.atd_seq = atd.seq
                     AND pm.ser_matricula_valida IS NOT NULL
                     AND pm.ser_vin_codigo_valida IS NOT NULL
                     AND pm.dthr_fim > now()
               ) THEN ''PRESCRICAO_NAO_REALIZADA''
               WHEN NOT EXISTS (
                   SELECT 1 FROM agh.mpm_prescricao_medicas pm
                   WHERE pm.atd_seq = atd.seq
                     AND pm.ser_matricula_valida IS NOT NULL
                     AND pm.ser_vin_codigo_valida IS NOT NULL
                     AND pm.dthr_inicio > now()
                     AND to_char(unf.hrio_validade_pme, ''HH24:mi'') = to_char(pm.dthr_inicio, ''HH24:mi'')
               ) THEN ''PRESCRICAO_VENCE_NO_DIA''
               ELSE ''PRESCRICAO_VENCE_NO_DIA_SEGUINTE''
           END AS configprescmed,
           CASE
               WHEN CASE WHEN atd.ind_pac_atendimento::text = ''S'' AND cuf.unf_seq IS NOT NULL THEN ''false'' ELSE ''true'' END = ''true'' THEN NULL::timestamp
               WHEN NOT EXISTS (
                   SELECT 1 FROM agh.mpm_prescricao_medicas pm
                   WHERE pm.atd_seq = atd.seq
                     AND pm.ser_matricula_valida IS NOT NULL
                     AND pm.ser_vin_codigo_valida IS NOT NULL
                     AND pm.dthr_fim > now()
               ) THEN NULL::timestamp
               ELSE (
                   SELECT max(pm.dthr_inicio)
                   FROM agh.mpm_prescricao_medicas pm
                   WHERE pm.atd_seq = atd.seq
                     AND pm.ser_matricula_valida IS NOT NULL
                     AND pm.ser_vin_codigo_valida IS NOT NULL
                     AND to_char(unf.hrio_validade_pme, ''HH24:mi'') = to_char(pm.dthr_inicio, ''HH24:mi'')
               )
           END AS dataprescmed,
           CASE
               WHEN CASE WHEN atd.ind_pac_atendimento::text = ''S'' AND cuf.unf_seq IS NOT NULL THEN ''false'' ELSE ''true'' END = ''true'' THEN ''''
               WHEN NOT EXISTS (
                   SELECT 1 FROM agh.mpm_prescricao_medicas pm
                   WHERE pm.atd_seq = atd.seq
                     AND pm.ser_matricula_valida IS NOT NULL
                     AND pm.ser_vin_codigo_valida IS NOT NULL
                     AND pm.dthr_fim > now()
               ) THEN ''''
               WHEN NOT EXISTS (
                   SELECT 1 FROM agh.mpm_prescricao_medicas pm
                   WHERE pm.atd_seq = atd.seq
                     AND pm.ser_matricula_valida IS NOT NULL
                     AND pm.ser_vin_codigo_valida IS NOT NULL
                     AND pm.dthr_inicio > now()
                     AND to_char(unf.hrio_validade_pme, ''HH24:mi'') = to_char(pm.dthr_inicio, ''HH24:mi'')
               ) THEN CASE
                   WHEN EXISTS (
                       SELECT 1 FROM agh.v_agh_versoes_documentos docs
                       WHERE docs.dov_situacao = ''A''
                         AND docs.dok_tipo = ''PM''
                         AND docs.pac_codigo = atd.pac_codigo
                   ) THEN ''ASSINADO''
                   ELSE ''''
               END
               ELSE CASE
                   WHEN EXISTS (
                       SELECT 1 FROM agh.v_agh_versoes_documentos docs
                       WHERE docs.dov_situacao = ''A''
                         AND docs.dok_tipo = ''PM''
                         AND docs.pac_codigo = atd.pac_codigo
                   ) THEN ''ASSINADO''
                   ELSE ''''
               END
           END AS configprescmedassinada,
           CASE
               WHEN EXISTS (
                   SELECT 1 FROM agh.v_agh_versoes_documentos docs
                   WHERE docs.dov_situacao = ''A''
                     AND docs.dok_tipo = ''PM''
                     AND docs.pac_codigo = atd.pac_codigo
               ) THEN ''ASSINADO''
               ELSE ''''
           END AS esta_assinada,
           clinicas.codigo AS clinica_codigo
    FROM agh.v_afa_prcr_disp_mdtos x
    JOIN agh.agh_atendimentos atd ON atd.seq = x.atd_seq
    LEFT JOIN agh.aip_pacientes p ON atd.pac_codigo = p.codigo
    LEFT JOIN agh.agh_unidades_funcionais unf ON atd.unf_seq = unf.seq
    LEFT JOIN agh.agh_caract_unid_funcionais cuf ON cuf.unf_seq = atd.unf_seq AND cuf.caracteristica = ''Pme Informatizada''
    LEFT JOIN agh.agh_clinicas clinicas ON unf.clc_codigo = clinicas.codigo
    ';

    -- Verifica se a view existe
    IF EXISTS (
        SELECT 1 FROM pg_views
        WHERE schemaname = 'agh'
          AND viewname = 'v_afa_prcr_disp_mdtos_painel'
    ) THEN
SELECT pg_get_viewdef('agh.v_afa_prcr_disp_mdtos_painel', true) INTO view_def;

IF replace(view_def, ' ', '') <> replace(new_def, ' ', '') THEN
            RAISE NOTICE 'A view foi modificada. Atualizada.';
EXECUTE 'CREATE OR REPLACE VIEW agh.v_afa_prcr_disp_mdtos_painel AS ' || new_def;
ELSE
            RAISE NOTICE 'Nenhuma alteração necessária. A definição atual já está em conformidade.';
END IF;
ELSE
        RAISE NOTICE 'A view não existe. Nenhuma ação foi realizada.';
END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Erro ao verificar ou atualizar a view: %', SQLERRM;
END $$;