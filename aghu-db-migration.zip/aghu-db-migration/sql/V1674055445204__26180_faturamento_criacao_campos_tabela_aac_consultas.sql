DO $$
BEGIN

--- Criação do campo: ser_matricula_supervisionado_por ---

if not exists (
			select 1 from information_schema.columns
			where table_schema = 'agh' and table_name = 'aac_consultas'
			and column_name = 'ser_matricula_supervisionado_por') then begin

alter table agh.aac_consultas add ser_matricula_supervisionado_por integer;

raise notice 'Coluna ser_matricula_supervisionado_por integer criada na tabela agh.aac_consultas';

comment on column agh.aac_consultas.ser_matricula_supervisionado_por
    is 'Matricula do Servidor responsavel pela supervisao do procedimento';

raise notice 'Comentario da coluna ser_matricula_supervisionado_por criado na tabela agh.aac_consultas';


exception
			when others then
				raise info 'Error Name:%', sqlerrm;
				raise info 'Error State:%', sqlstate;
end;
end if;

--- Criação do campo: ser_vin_codigo_supervisionado_por ---

if not exists (
			select 1 from information_schema.columns
			where table_schema = 'agh' and table_name = 'aac_consultas'
			and column_name = 'ser_vin_codigo_supervisionado_por') then begin

alter table agh.aac_consultas add ser_vin_codigo_supervisionado_por smallint;

raise notice 'Coluna ser_vin_codigo_supervisionado_por smallint criada na tabela agh.aac_consultas';

comment on column agh.aac_consultas.ser_vin_codigo_supervisionado_por
    is 'Codigo do Vinculo do servidor responsavel pela supervisao do procedimento';

raise notice 'Comentario da coluna ser_vin_codigo_supervisionado_por criado na tabela agh.aac_consultas';

exception
			when others then
				raise info 'Error Name:%', sqlerrm;
				raise info 'Error State:%', sqlstate;
end;
end if;


--- Criação da CONSTRAINT: aac_con_ser_supervisionado_fk referente aos
--- campos: ser_matricula_supervisionado_por / ser_vin_codigo_supervisionado_por

if not exists (
			select 1 from information_schema.table_constraints tc
			where tc.constraint_name = 'aac_con_ser_supervisionado_fk'
			and tc.table_name='aac_consultas' and tc.table_schema = 'agh') then begin

alter table agh.aac_consultas add constraint aac_con_ser_supervisionado_fk
    foreign key (ser_matricula_supervisionado_por, ser_vin_codigo_supervisionado_por)
        references agh.rap_servidores (matricula, vin_codigo)
        match SIMPLE on update no action on delete no action;

raise notice 'Foreign key aac_con_ser_supervisionado_fk criada na tabela agh.aac_consultas.';

CREATE INDEX aac_con_ser_supervisionado_fk_i
    ON agh.aac_consultas USING btree
    (ser_matricula_supervisionado_por ASC NULLS LAST, ser_vin_codigo_supervisionado_por ASC NULLS LAST)
    TABLESPACE tblspc_idx;

raise notice 'Indice aac_con_ser_supervisionado_fk_i criado na tabela agh.aac_consultas.';

exception
			when others then
				raise info 'Error Name:%', sqlerrm;
				raise info 'Error State:%', sqlstate;
end;
end if;



--- Criação do campo: ser_matricula_finalizado_por ---

if not exists (
			select 1 from information_schema.columns
			where table_schema = 'agh' and table_name = 'aac_consultas'
			and column_name = 'ser_matricula_finalizado_por') then begin

alter table agh.aac_consultas add ser_matricula_finalizado_por integer;

raise notice 'Coluna ser_matricula_finalizado_por integer criada na tabela agh.aac_consultas';

comment on column agh.aac_consultas.ser_matricula_finalizado_por
    is 'Matricula do servidor responsavel por finalizar o atendimento';

raise notice 'Comentario da coluna ser_matricula_finalizado_por criado na tabela agh.aac_consultas';

exception
			when others then
				raise info 'Error Name:%', sqlerrm;
				raise info 'Error State:%', sqlstate;
end;
end if;

--- Criação do campo: ser_vin_codigo_finalizado_por ---

if not exists (
			select 1 from information_schema.columns
			where table_schema = 'agh' and table_name = 'aac_consultas'
			and column_name = 'ser_vin_codigo_finalizado_por') then begin

alter table agh.aac_consultas add ser_vin_codigo_finalizado_por smallint;

raise notice 'Coluna ser_vin_codigo_finalizado_por smallint criada na tabela agh.aac_consultas';

comment on column agh.aac_consultas.ser_vin_codigo_finalizado_por
    is 'Codigo do Vinculo do servidor responsavel por finalizar o processo';

raise notice 'Comentario da coluna ser_vin_codigo_finalizado_por criado na tabela agh.aac_consultas';

exception
			when others then
				raise info 'Error Name:%', sqlerrm;
				raise info 'Error State:%', sqlstate;
end;
end if;


--- Criação da CONSTRAINT: aac_con_ser_finalizado_fk referente aos
--- campos: ser_matricula_finalizado_por / ser_vin_codigo_finalizado_por

if not exists (
			select 1 from information_schema.table_constraints tc
			where tc.constraint_name = 'aac_con_ser_finalizado_fk'
			and tc.table_name='aac_consultas' and tc.table_schema = 'agh') then begin

alter table agh.aac_consultas add constraint aac_con_ser_finalizado_fk
    foreign key (ser_matricula_finalizado_por, ser_vin_codigo_finalizado_por)
        references agh.rap_servidores (matricula, vin_codigo)
        match SIMPLE on update no action on delete no action;

raise notice 'Foreign key aac_con_ser_finalizado_fk criada na tabela agh.aac_consultas.';

CREATE INDEX aac_con_ser_finalizado_fk_i
    ON agh.aac_consultas USING btree
    (ser_matricula_finalizado_por ASC NULLS LAST, ser_vin_codigo_finalizado_por ASC NULLS LAST)
    TABLESPACE tblspc_idx;

raise notice 'Indice aac_con_ser_finalizado_fk_i criado na tabela agh.aac_consultas.';

exception
			when others then
				raise info 'Error Name:%', sqlerrm;
				raise info 'Error State:%', sqlstate;
end;
end if;


----- Criação do campo: supervisionado_em

if not exists (
			select 1 from information_schema.columns
			where table_schema = 'agh' and table_name = 'aac_consultas'
			and column_name = 'supervisionado_em') then begin

alter table agh.aac_consultas add supervisionado_em timestamp without time zone;

raise notice 'Coluna supervisionado_em timestamp without time zone, criada na tabela agh.aac_consultas';

comment on column agh.aac_consultas.supervisionado_em is 'Data da supervisão do procedimento';

raise notice 'Comentario da coluna supervisionado_em criado na tabela agh.aac_consultas';

exception
			when others then
				raise info 'Error Name:%', sqlerrm;
				raise info 'Error State:%', sqlstate;
end;
end if;


----- Criação do campo: finalizado_em

if not exists (
			select 1 from information_schema.columns
			where table_schema = 'agh' and table_name = 'aac_consultas'
			and column_name = 'finalizado_em') then begin

alter table agh.aac_consultas add finalizado_em timestamp without time zone;

raise notice 'Coluna finalizado_em timestamp without time zone, criada na tabela agh.aac_consultas';

comment on column agh.aac_consultas.finalizado_em is 'Data em que o processo foi finalizado';

raise notice 'Comentario da coluna finalizado_em criado na tabela agh.aac_consultas';

exception
			when others then
				raise info 'Error Name:%', sqlerrm;
				raise info 'Error State:%', sqlstate;
end;
end if;

END $$