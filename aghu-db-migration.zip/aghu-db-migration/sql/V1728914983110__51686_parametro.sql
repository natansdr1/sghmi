-- V1728914983110__51686_parametro.sql
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'agh' AND table_name = 'agh_parametros') THEN
        IF NOT EXISTS (SELECT 1 FROM agh.agh_parametros WHERE upper(nome) = 'P_CID_PROCEDIMENTO_PADRAO_EXAME_EXTERNO' AND upper(sis_sigla) = 'FAT') THEN
            BEGIN
                INSERT INTO agh.agh_parametros(
                    seq, sis_sigla, nome, mantem_historico, criado_em, criado_por, alterado_em, alterado_por,
                    vlr_data, vlr_numerico, vlr_texto, descricao, rotina_consistencia, version, vlr_data_padrao,
                    vlr_numerico_padrao, vlr_texto_padrao, exemplo_uso, tipo_dado
                )
                VALUES (
                    nextval('agh.agh_psi_sq1'),
                    'FAT',
                    'P_CID_PROCEDIMENTO_PADRAO_EXAME_EXTERNO',
                    'S',
                    now(),
                    'AGHU',
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    'S',
                    'Parâmetro responsável por definir a obrigatoriedade do CID Procedimento nas solicitações de exames externos com o objetivo de vincular o CID ao procedimento para fins de faturamento.',
                    NULL,
                    0,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    'T'
                );
                RAISE NOTICE 'Inserção realizada com sucesso.';
            EXCEPTION
                WHEN unique_violation THEN
                    RAISE NOTICE 'O registro já existe e não foi inserido.';
                WHEN others THEN
                    RAISE EXCEPTION 'Erro inesperado: %', SQLERRM;
            END;
        ELSE
            RAISE NOTICE 'O registro já existe, nada feito.';
        END IF;
    ELSE
        RAISE NOTICE 'A tabela agh.agh_parametros não existe, nada feito.';
    END IF;
END $$;
 
 
