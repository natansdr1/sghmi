DO $faturamento_salva_exclusao$
begin
	if not exists (
			select 1 from information_schema.tables
			where table_schema = 'agh' and table_name = 'fat_proc_registro_exclusao') then
		CREATE TABLE agh.fat_proc_registro_exclusao (
			iph_pho_seq int2 NOT NULL,
			iph_seq int4 NOT NULL,
		    cod_registro varchar(2) NOT null
		         constraint CKC_VALORES_BPA check (cod_registro in ('01','02')),
			dt_exclusao timestamp not null,
			CONSTRAINT fat_proc_registro_exc_pkey PRIMARY KEY (iph_pho_seq, iph_seq, cod_registro)
		);
		
		comment on table agh.fat_proc_registro_exclusao is
		'Lista os Procedimentos de Registro que tiveram exclusão manual de algum tipo de BPA (I ou C)';
		
		comment on column agh.fat_proc_registro_exclusao.iph_pho_seq is 'Sequencial PHO do Item de Procedimento Hospitalar';
		
		comment on column agh.fat_proc_registro_exclusao.iph_seq is 'Sequencial do Item de Procedimento Hospitalar';
		
		comment on column agh.fat_proc_registro_exclusao.cod_registro is 'Codigo de registro que só podem ser do tipo BPA (I ou C)';
		
		comment on column agh.fat_proc_registro_exclusao.dt_exclusao is 'Data de exclusão do registro';
	
		GRANT INSERT, SELECT, UPDATE, DELETE ON TABLE agh.fat_proc_registro_exclusao TO acesso_completo;
		GRANT SELECT ON TABLE agh.fat_proc_registro_exclusao TO acesso_leitura;

	end if;
END $faturamento_salva_exclusao$