DO $$
BEGIN
 
IF exists (SELECT count(*) FROM information_schema.tables WHERE table_schema = 'agh' and table_name = 'sco_materiais_almoxarifados_entrada') then
  GRANT ALL ON TABLE agh.sco_materiais_almoxarifados_entrada TO acesso_completo;
  raise notice 'Grant realizado com sucesso. acesso_completo.';
  GRANT SELECT ON TABLE agh.sco_materiais_almoxarifados_entrada TO acesso_leitura;
  raise notice 'Grant realizado com sucesso. acesso_leitura.';
end if;
 
IF exists (SELECT count(*) FROM information_schema.tables WHERE table_schema = 'agh' and table_name = 'fat_cbos') then
  update agh.fat_cbos set dt_fim = null where codigo = '000000';
  raise notice 'Update executado com sucesso.';
end if;
 
END $$