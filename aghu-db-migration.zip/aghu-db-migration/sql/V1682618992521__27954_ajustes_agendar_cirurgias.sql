DO $$
BEGIN

if not exists (
			select 1 from information_schema.columns
			where table_schema = 'agh' and table_name = 'mbc_proc_esp_por_cirurgias' and column_name = 'agh_cid_proced_cirurgico_seq') then begin
alter table agh.mbc_proc_esp_por_cirurgias add agh_cid_proced_cirurgico_seq integer;
raise notice 'Coluna agh_cid_proced_cirurgico_seq integer criada na tabela agh.mbc_proc_esp_por_cirurgias';
alter table agh.mbc_proc_esp_por_cirurgias add constraint mbc_ppc_agh_cid_proced_cirurgico_fk foreign key (agh_cid_proced_cirurgico_seq)
    references agh.agh_cids (seq) match SIMPLE on update no action on delete no action;
raise notice 'Foreign key mbc_ppc_agh_cid_proced_cirurgico_fk criada na tabela agh.mbc_proc_esp_por_cirurgias.';
exception
			when others then
				raise info 'Error Name:%', sqlerrm;
				raise info 'Error State:%', sqlstate;
end;
end if;

END $$