do $$
begin
	if not exists(select null from information_schema.sequences where sequence_schema = 'agh' and sequence_name = 'sce_inventario_seq_sq1') then begin
		create sequence agh.sce_inventario_seq_sq1 increment by 1 minvalue 1 maxvalue 9223372036854775807 start with 1 no cycle;
		raise info 'sequence ''agh.sce_inventario_seq_sq1'' criada com sucesso.';
		exception
			when others then
			raise notice 'Erro na criação da sequence agh.sce_inventario_seq_sq1 - % %', sqlerrm, sqlstate;
		end;
		else raise notice 'Sequence agh.sce_inventario_seq_sq1 já existia.';
	end if;
	
	if not exists(select 1 from information_schema.tables where table_schema = 'agh' and table_name = 'sce_inventario') then begin
		create table agh.sce_inventario(
		   seq int8 not null default nextval('agh.sce_inventario_seq_sq1'::regclass),
		   tipo_inventario int8  not null,
		   seq_almoxarifado int8  not null,
		   dt_inicial timestamp null,
		   dt_final timestamp null,
		   num_sei int8 null,
		   status varchar(1) not null,
		   servidor_matricula_abrir int4 null,
		   servidor_matricula_editar int4 null,
		   servidor_matricula_concluir int4 null,
		   servidor_vinculo_codigo_abrir int2 null,
		   servidor_vinculo_codigo_editar int2 null,
		   servidor_vinculo_codigo_concluir int2 null,
		   constraint sce_inventario_pk primary key(seq)
		);
		
		GRANT ALL ON TABLE agh.sce_inventario TO acesso_completo;
        GRANT SELECT ON TABLE agh.sce_inventario TO acesso_leitura;
 
CREATE UNIQUE INDEX sce_inventario_pk_idx ON agh.sce_inventario USING btree (seq);

alter table agh.sce_inventario
    add constraint seq_almoxarifado foreign key (seq_almoxarifado) references agh.sce_almoxarifados (seq);
		raise notice 'Tabela agh.sce_inventario criada';
        raise notice 'CONSTRAINT SEQ_ALMOXARIFADO criada';
		COMMENT ON COLUMN agh.sce_inventario.seq IS 'Chave primaria';
		COMMENT ON COLUMN agh.sce_inventario.tipo_inventario IS 'tipo do inventario';
		COMMENT ON COLUMN agh.sce_inventario.seq_almoxarifado IS 'sequencial de almoxarifado';
		COMMENT ON COLUMN agh.sce_inventario.dt_inicial IS 'Data e hora inicial que o inventario foi aberto';
		COMMENT ON COLUMN agh.sce_inventario.dt_final IS 'Data e hora final que o inventario foi concluido';
		COMMENT ON COLUMN agh.sce_inventario.num_sei IS 'numero sei';
		COMMENT ON COLUMN agh.sce_inventario.status IS 'guardar o status do inventario';
		COMMENT ON COLUMN agh.sce_inventario.servidor_matricula_abrir IS 'Login do servidor que abriu o inventario';
		COMMENT ON COLUMN agh.sce_inventario.servidor_vinculo_codigo_concluir IS 'Login do servidor que concluiu o inventario';
	exception
		when others then
        	raise notice 'Erro na criação da tabela ''agh.sce_inventario'' - % %', sqlerrm, sqlstate;
	end;
	else raise info 'Tabela agh.sce_inventario já existia';
	--end;
	end if;	

	if not exists(select 1 from information_schema.table_constraints where constraint_schema = 'agh' and constraint_name = 'sce_inv_abrir_rap_fk1') then
	   alter table agh.sce_inventario add constraint sce_inv_abrir_rap_fk1 foreign key(servidor_matricula_abrir, servidor_vinculo_codigo_abrir) references agh.rap_servidores (matricula, vin_codigo);
	end if;

	if not exists (select 1 from information_schema.table_constraints where constraint_schema = 'agh' and constraint_name = 'sce_inv_editar_rap_fk1') then
	   alter table agh.sce_inventario add constraint sce_inv_editar_rap_fk1 foreign key (servidor_matricula_editar, servidor_vinculo_codigo_editar) references agh.rap_servidores (matricula, vin_codigo);
	end if;

	if not exists (select 1 from information_schema.table_constraints where constraint_schema = 'agh' and constraint_name = 'sce_inv_concluir_rap_fk1') then
	   alter table agh.sce_inventario add constraint sce_inv_concluir_rap_fk1 foreign key (servidor_matricula_concluir, servidor_vinculo_codigo_concluir) references agh.rap_servidores (matricula, vin_codigo);
	end if;

    if not exists(select 1 from information_schema.tables where table_schema = 'agh' and table_name = 'sce_itens_mat_inventario') then begin
		create sequence agh.sce_itens_mat_inventario_seq_sq1 increment by 1 minvalue 1 maxvalue 9223372036854775807 start with 1 no cycle;
		raise info 'Sequence ''agh.sce_itens_mat_inventario_seq_sq1'' criada com sucesso.';
		create table agh.sce_itens_mat_inventario (
			seq int8 NOT NULL DEFAULT nextval('agh.sce_itens_mat_inventario_seq_sq1'::regclass),
			seq_inv int8  NOT NULL,
			cod_gru_mat int8  NOT NULL,
			cod_material int8  NOT null,
			constraint sce_itens_mat_inventario_pk primary key(seq)
		);
		
		GRANT ALL ON TABLE agh.sce_itens_mat_inventario TO acesso_completo;
        GRANT SELECT ON TABLE agh.sce_itens_mat_inventario TO acesso_leitura;
		
		alter table agh.sce_itens_mat_inventario add constraint fk_sce_itens_mat_inventario_reference_sce_inventario_seq foreign key(seq_inv) references agh.sce_inventario(seq);
		alter table agh.sce_itens_mat_inventario add constraint fk_cod_gru_mat_reference_sco_grupos_materiais_cod foreign key(cod_gru_mat) references agh.sco_grupos_materiais(codigo);
		alter table agh.sce_itens_mat_inventario add constraint fk_cod_material_reference_sco_materiais_cod foreign key(cod_material) references agh.sco_materiais(codigo);
	exception
		when others then
			raise notice 'Erro na criação da tabela ''agh.sce_itens_mat_inventario'' - % %', sqlerrm, sqlstate;
	end;
end if; 
end $$;

