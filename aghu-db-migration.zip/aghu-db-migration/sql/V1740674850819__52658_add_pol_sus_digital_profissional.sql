DO $$
BEGIN

    if not exists (select COUNT (*) from agh.agh_nodos_pol where nome = 'susDigitalProfissional' and descricao = 'SUS Digital Profissional') then
        INSERT INTO agh.agh_nodos_pol (seq, nome, descricao, status, ordem, icone, alterado_em, alterado_por, "version")
        VALUES((select max(seq) + 1 from agh.AGH_NODOS_POL), 'susDigitalProfissional', 'SUS Digital Profissional', 'A', (select max(ordem) + 1 from agh.AGH_NODOS_POL), '/images/icons/logo-sus-digital.png', now(), 'aghu', 0);
    end if;

END $$;