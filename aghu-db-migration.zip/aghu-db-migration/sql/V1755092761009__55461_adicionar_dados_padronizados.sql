DO $$
BEGIN
    -- Verifica se a constraint da coluna tipo existe
    IF EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname = 'mbc_mtc_ck4'
    ) THEN
        -- Remove a constraint existente
        ALTER TABLE agh.mbc_motivo_cancelamentos
        DROP CONSTRAINT mbc_mtc_ck4;
        RAISE NOTICE 'Constraint mbc_mtc_ck4 existe e foi excluída';
        -- Recria a constraint sem validar os dados já existentes
        ALTER TABLE agh.mbc_motivo_cancelamentos
            ADD CONSTRAINT mbc_mtc_ck4 CHECK (
                tipo::text = ANY (
            ARRAY[
                'P'::character varying,
                'T'::character varying,
                'F'::character varying,
                'M'::character varying
              ]
            )
        ) NOT VALID;
            RAISE NOTICE 'Constraint mbc_mtc_ck4 criada com NOT VALID';
    ELSE
        RAISE NOTICE 'Constraint mbc_mtc_ck4 não existe';
    END IF;
END
$$;

DO $$
DECLARE
v_table_exists BOOLEAN;
    v_column_exists BOOLEAN;
BEGIN
    -- Verifica se a tabela existe
SELECT EXISTS (
    SELECT 1
    FROM information_schema.tables
    WHERE table_schema = 'agh'
      AND table_name = 'mbc_motivo_cancelamentos'
) INTO v_table_exists;

IF v_table_exists THEN
        -- Verifica se a coluna existe
SELECT EXISTS (
    SELECT 1
    FROM information_schema.columns
    WHERE table_schema = 'agh'
      AND table_name = 'mbc_motivo_cancelamentos'
      AND column_name = 'tipo'
) INTO v_column_exists;

IF v_column_exists THEN
            -- Altera o comentário da coluna
            COMMENT ON COLUMN agh.mbc_motivo_cancelamentos.tipo IS
            'Tipos válidos:
''P'' = Paciente
''T'' = Processo de Trabalho
''F'' = Profissionais
''M'' = Materiais';
            RAISE NOTICE 'Comentário da coluna "tipo" alterado com sucesso.';
ELSE
            RAISE NOTICE 'A coluna "tipo" não existe na tabela agh.mbc_motivo_cancelamentos.';
END IF;
ELSE
        RAISE NOTICE 'A tabela agh.mbc_motivo_cancelamentos não existe.';
END IF;
END
$$;


