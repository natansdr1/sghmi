DO $$
BEGIN

    IF NOT EXISTS(
            SELECT 1
            FROM information_schema.columns
            WHERE table_schema = 'agh'
                AND table_name = 'pdt_procs'
                AND column_name = 'qtd_procedimento'
        ) THEN
        ALTER TABLE agh.pdt_procs ADD COLUMN qtd_procedimento integer null;
        COMMENT ON COLUMN agh.pdt_procs.qtd_procedimento IS 'Quantidade de procedimentos.';
        RAISE NOTICE 'EXECUTADO ALTERAÇÃO: #16988 - agh.pdt_procs.qtd_procedimento';
    END IF;

    IF NOT EXISTS(
            SELECT 1
            FROM information_schema.columns
            WHERE table_schema = 'agh'
                AND table_name = 'pdt_procs'
                AND column_name = 'cid_seq'
        ) THEN
        ALTER TABLE agh.pdt_procs ADD cid_seq integer null;
        COMMENT ON COLUMN agh.pdt_procs.cid_seq IS 'Referencia a tabela de CID.';
        RAISE NOTICE 'EXECUTADO ALTERAÇÃO: #16988 - agh.pdt_procs.cid_seq';
    END IF;

    IF NOT EXISTS(
            SELECT 1
            FROM information_schema.columns
            WHERE table_schema = 'agh'
                AND table_name = 'pdt_procs'
                AND column_name = 'proc_principal'
        ) THEN
        ALTER TABLE agh.pdt_procs ADD COLUMN proc_principal boolean null;
        COMMENT ON COLUMN agh.pdt_procs.proc_principal IS 'indica o procedimento principal.';
        RAISE NOTICE 'EXECUTADO ALTERAÇÃO: #16988 - agh.pdt_procs.proc_principal';
    END IF;

    IF NOT EXISTS(
            SELECT 1
            FROM information_schema.columns
            WHERE table_schema = 'agh'
                AND table_name = 'pdt_procs'
                AND column_name = 'lado_cirurgia'
        ) THEN
        ALTER TABLE agh.pdt_procs ADD COLUMN lado_cirurgia varchar(1);
        COMMENT ON COLUMN agh.pdt_procs.qtd_procedimento IS 'Informa a quantidade de cada procedimento procedimentos.';
        RAISE NOTICE 'EXECUTADO ALTERAÇÃO: #16988 - agh.pdt_procs.lado_cirurgia';
    END IF;
END $$