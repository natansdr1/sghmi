DO
$$
BEGIN

if not exists(  select * from information_schema.columns
                    where   table_schema = 'agh'
                            and table_name = 'agh_tipos_unidade_funcional'
                            and column_name = 'assistencial') then
    
	alter sequence if exists agh.agh_tuf_sq1 maxvalue 9223372036854775807;
                        
	ALTER TABLE agh.agh_tipos_unidade_funcional ADD ATIVO BOOL NOT null default true;
	ALTER TABLE agh.agh_tipos_unidade_funcional ADD ASSISTENCIAL BOOL NOT null default false;
	
	comment on column agh.agh_tipos_unidade_funcional.ativo is 'Coluna para dizer se o registro está ativo ou não';
	comment on column agh.agh_tipos_unidade_funcional.assistencial is 'Coluna para dizer se o registro é assistencial ou não. Os assitenciais não podem ser alterados nem excluídos';
	
	INSERT INTO agh.agh_tipos_unidade_funcional (seq, descricao, "version", seq_esperanto, ativo, assistencial) VALUES (nextval('AGH.AGH_TUF_SQ1'), 'Clínica Adulto', 0, null, true, true);	
	INSERT INTO agh.agh_tipos_unidade_funcional (seq, descricao, "version", seq_esperanto, ativo, assistencial) VALUES (nextval('AGH.AGH_TUF_SQ1'), 'Cirúrgica Adulto', 0, null, true, true);
	INSERT INTO agh.agh_tipos_unidade_funcional (seq, descricao, "version", seq_esperanto, ativo, assistencial) VALUES (nextval('AGH.AGH_TUF_SQ1'), 'Obstétrica', 0, null, true, true);
	INSERT INTO agh.agh_tipos_unidade_funcional (seq, descricao, "version", seq_esperanto, ativo, assistencial) VALUES (nextval('AGH.AGH_TUF_SQ1'), 'Pediátrico Clínica/Cirúrgica', 0, null, true, true);
	INSERT INTO agh.agh_tipos_unidade_funcional (seq, descricao, "version", seq_esperanto, ativo, assistencial) VALUES (nextval('AGH.AGH_TUF_SQ1'), 'UTI Pediátrico', 0, null, true, true);
	INSERT INTO agh.agh_tipos_unidade_funcional (seq, descricao, "version", seq_esperanto, ativo, assistencial) VALUES (nextval('AGH.AGH_TUF_SQ1'), 'UTI Adulto', 0, null, true, true);
	INSERT INTO agh.agh_tipos_unidade_funcional (seq, descricao, "version", seq_esperanto, ativo, assistencial) VALUES (nextval('AGH.AGH_TUF_SQ1'), 'UTI Neo', 0, null, true, true);
	INSERT INTO agh.agh_tipos_unidade_funcional (seq, descricao, "version", seq_esperanto, ativo, assistencial) VALUES (nextval('AGH.AGH_TUF_SQ1'), 'UTI Queimados', 0, null, true, true);
	INSERT INTO agh.agh_tipos_unidade_funcional (seq, descricao, "version", seq_esperanto, ativo, assistencial) VALUES (nextval('AGH.AGH_TUF_SQ1'), 'Unidade Coronariana', 0, null, true, true);
	INSERT INTO agh.agh_tipos_unidade_funcional (seq, descricao, "version", seq_esperanto, ativo, assistencial) VALUES (nextval('AGH.AGH_TUF_SQ1'), 'Unidade Cuidados Intermediários Adulto', 0, null, true, true);
	INSERT INTO agh.agh_tipos_unidade_funcional (seq, descricao, "version", seq_esperanto, ativo, assistencial) VALUES (nextval('AGH.AGH_TUF_SQ1'), 'Unidade Cuidados Intermediários Pediátrico', 0, null, true, true);
	INSERT INTO agh.agh_tipos_unidade_funcional (seq, descricao, "version", seq_esperanto, ativo, assistencial) VALUES (nextval('AGH.AGH_TUF_SQ1'), 'UCINCO', 0, null, true, true);
	INSERT INTO agh.agh_tipos_unidade_funcional (seq, descricao, "version", seq_esperanto, ativo, assistencial) VALUES (nextval('AGH.AGH_TUF_SQ1'), 'UCINCA', 0, null, true, true);
	INSERT INTO agh.agh_tipos_unidade_funcional (seq, descricao, "version", seq_esperanto, ativo, assistencial) VALUES (nextval('AGH.AGH_TUF_SQ1'), 'Hospital Dia', 0, null, true, true);
	INSERT INTO agh.agh_tipos_unidade_funcional (seq, descricao, "version", seq_esperanto, ativo, assistencial) VALUES (nextval('AGH.AGH_TUF_SQ1'), 'Centro Cirúrgico', 0, null, true, true);
	INSERT INTO agh.agh_tipos_unidade_funcional (seq, descricao, "version", seq_esperanto, ativo, assistencial) VALUES (nextval('AGH.AGH_TUF_SQ1'), 'Centro Obstétrico', 0, null, true, true);
	INSERT INTO agh.agh_tipos_unidade_funcional (seq, descricao, "version", seq_esperanto, ativo, assistencial) VALUES (nextval('AGH.AGH_TUF_SQ1'), 'Urgência/Emergência Adulto', 0, null, true, true);
	INSERT INTO agh.agh_tipos_unidade_funcional (seq, descricao, "version", seq_esperanto, ativo, assistencial) VALUES (nextval('AGH.AGH_TUF_SQ1'), 'Urgência/Emergência Pediátrica', 0, null, true, true);
	INSERT INTO agh.agh_tipos_unidade_funcional (seq, descricao, "version", seq_esperanto, ativo, assistencial) VALUES (nextval('AGH.AGH_TUF_SQ1'), 'Urgência/Emergência Obstétrica', 0, null, true, true);
	INSERT INTO agh.agh_tipos_unidade_funcional (seq, descricao, "version", seq_esperanto, ativo, assistencial) VALUES (nextval('AGH.AGH_TUF_SQ1'), 'Unidade Internação Domiciliar', 0, null, true, true);
	INSERT INTO agh.agh_tipos_unidade_funcional (seq, descricao, "version", seq_esperanto, ativo, assistencial) VALUES (nextval('AGH.AGH_TUF_SQ1'), 'Ambulatório', 0, null, true, true);
	
end if;
  
END $$;