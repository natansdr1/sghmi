DO $$
begin

/* Modulo SAMIS */

-- add column qtde_volumes
IF not exists (SELECT COUNT(*) FROM information_schema.columns WHERE column_name = 'qtde_volumes' and table_name = 'aip_paciente_prontuario') THEN
ALTER TABLE agh.aip_paciente_prontuario ADD qtde_volumes smallint;
END IF;

IF not exists (SELECT COUNT(*) FROM information_schema.columns WHERE column_name = 'qtde_volumes' and table_name = 'aip_paciente_prontuario_jn') THEN
ALTER TABLE agh.aip_paciente_prontuario_jn ADD qtde_volumes smallint;
END IF;


-- Table: agh.aip_solicitacao_tramite_prontuarios
-- DROP TABLE agh.aip_solicitacao_tramite_prontuarios;
IF not exists (SELECT COUNT(*) FROM information_schema.tables WHERE table_name = 'aip_solicitacao_tramite_prontuarios') THEN
CREATE TABLE agh.aip_solicitacao_tramite_prontuarios (
                                                         seq integer NOT NULL,
                                                         volume smallint NOT NULL,
                                                         pac_prontuario integer NOT NULL,
                                                         unf_seq smallint NOT NULL,
                                                         data timestamp without time zone,
                                                         ser_matricula integer,
                                                         ser_vin_codigo smallint,
                                                         observacao character varying(200),
                                                         ind_situacao character varying(1) DEFAULT 'P'::character varying,
                                                         seq_finalidade_movimentacao smallint NOT NULL,
                                                         version integer DEFAULT 0,

                                                         CONSTRAINT aip_solicitacao_tramite_prontuarios_pkey PRIMARY KEY (seq),

                                                         CONSTRAINT aip_stp_pac_fk1 FOREIGN KEY (pac_prontuario)
                                                             REFERENCES agh.aip_paciente_prontuario (pac_prontuario) MATCH SIMPLE
                                                             ON UPDATE NO ACTION ON DELETE NO ACTION,

                                                         CONSTRAINT aip_stp_unf_fk1 FOREIGN KEY (unf_seq)
                                                             REFERENCES agh.agh_unidades_funcionais (seq) MATCH SIMPLE
                                                             ON UPDATE NO ACTION ON DELETE NO ACTION,

                                                         CONSTRAINT aip_stp_ser_fk1 FOREIGN KEY (ser_matricula, ser_vin_codigo)
                                                             REFERENCES agh.rap_servidores (matricula, vin_codigo) MATCH SIMPLE
                                                             ON UPDATE NO ACTION ON DELETE NO ACTION,

                                                         CONSTRAINT aip_stp_fmv_fk1 FOREIGN KEY (seq_finalidade_movimentacao)
                                                             REFERENCES agh.aip_finalidades_movimentacao (seq) MATCH SIMPLE
                                                             ON UPDATE NO ACTION ON DELETE NO ACTION,

                                                         CONSTRAINT aip_stp_ck1 CHECK (ind_situacao::text = ANY (ARRAY['P'::character varying::text, 'A'::character varying::text, 'C'::character varying::text]))
    )
	WITH (
	  OIDS=FALSE
	);

ALTER TABLE agh.aip_solicitacao_tramite_prontuarios  OWNER TO postgres;
GRANT ALL ON TABLE agh.aip_solicitacao_tramite_prontuarios TO postgres;
	GRANT ALL ON TABLE agh.aip_solicitacao_tramite_prontuarios TO acesso_completo;
GRANT SELECT ON TABLE agh.aip_solicitacao_tramite_prontuarios TO acesso_leitura;
END IF;

IF not exists (SELECT COUNT(*) FROM information_schema.sequences WHERE sequence_schema = 'agh' AND sequence_name = 'aip_stp_sq1') THEN
CREATE SEQUENCE agh.aip_stp_sq1
    INCREMENT 1
		MINVALUE 1
		MAXVALUE 99999999999999
		START 1
		CACHE 2;

ALTER SEQUENCE agh.aip_stp_sq1 OWNER TO postgres;
GRANT ALL ON SEQUENCE agh.aip_stp_sq1 TO postgres;
	GRANT ALL ON SEQUENCE agh.aip_stp_sq1 TO acesso_completo;
GRANT SELECT ON SEQUENCE agh.aip_stp_sq1 TO acesso_leitura;

COMMENT ON COLUMN agh.aip_solicitacao_tramite_prontuarios.ind_situacao IS 'Campo para determinar a situação de solicitação do prontuário. Permite os valores: P=Pendente, A=Atendido, C=Cancelado.';
END IF;

-- Table: agh.aip_tramite_prontuarios
-- DROP TABLE agh.aip_tramite_prontuarios;
IF not exists (SELECT COUNT(*) FROM information_schema.tables WHERE table_name = 'aip_tramite_prontuarios') THEN
CREATE TABLE agh.aip_tramite_prontuarios (
                                             seq integer NOT NULL,
                                             volume smallint NOT NULL,
                                             pac_prontuario integer NOT NULL,
                                             unf_seq smallint NOT NULL,
                                             ind_tipo_tramite character varying(1) NOT NULL,
                                             criado_em timestamp without time zone NOT NULL,
                                             data_envio timestamp without time zone,
                                             ser_matricula_envio integer,
                                             ser_vin_codigo_envio smallint,
                                             observacao character varying(200),
                                             data_recebimento timestamp without time zone,
                                             ser_matricula_recebimento integer,
                                             ser_vin_codigo_recebimento smallint,
                                             seq_solicitacao_tramite_prontuarios integer,
                                             seq_finalidade_movimentacao smallint,
                                             version integer DEFAULT 0,

                                             CONSTRAINT aip_tramite_prontuarios_pkey PRIMARY KEY (seq),

                                             CONSTRAINT aip_trp_pac_fk1 FOREIGN KEY (pac_prontuario)
                                                 REFERENCES agh.aip_paciente_prontuario (pac_prontuario) MATCH SIMPLE
                                                 ON UPDATE NO ACTION ON DELETE NO ACTION,

                                             CONSTRAINT aip_trp_unf_fk1 FOREIGN KEY (unf_seq)
                                                 REFERENCES agh.agh_unidades_funcionais (seq) MATCH SIMPLE
                                                 ON UPDATE NO ACTION ON DELETE NO ACTION,

                                             CONSTRAINT aip_trp_ser_fk2 FOREIGN KEY (ser_matricula_envio, ser_vin_codigo_envio)
                                                 REFERENCES agh.rap_servidores (matricula, vin_codigo) MATCH SIMPLE
                                                 ON UPDATE NO ACTION ON DELETE NO ACTION,

                                             CONSTRAINT aip_trp_ser_fk3 FOREIGN KEY (ser_matricula_recebimento, ser_vin_codigo_recebimento)
                                                 REFERENCES agh.rap_servidores (matricula, vin_codigo) MATCH SIMPLE
                                                 ON UPDATE NO ACTION ON DELETE NO ACTION,

                                             CONSTRAINT aip_trp_stp_fk1 FOREIGN KEY (seq_solicitacao_tramite_prontuarios)
                                                 REFERENCES agh.aip_solicitacao_tramite_prontuarios (seq) MATCH SIMPLE
                                                 ON UPDATE NO ACTION ON DELETE NO ACTION,

                                             CONSTRAINT aip_trp_fmv_fk1 FOREIGN KEY (seq_finalidade_movimentacao)
                                                 REFERENCES agh.aip_finalidades_movimentacao (seq) MATCH SIMPLE
                                                 ON UPDATE NO ACTION ON DELETE NO ACTION,

                                             CONSTRAINT aip_trp_ck1 CHECK (ind_tipo_tramite::text = ANY (ARRAY['A'::character varying::text, 'S'::character varying::text, 'E'::character varying::text, 'R'::character varying::text, 'D'::character varying::text, 'X'::character varying::text]))
    )
	WITH (
	  OIDS=FALSE
	);

ALTER TABLE agh.aip_tramite_prontuarios  OWNER TO postgres;
GRANT ALL ON TABLE agh.aip_tramite_prontuarios TO postgres;
	GRANT ALL ON TABLE agh.aip_tramite_prontuarios TO acesso_completo;
GRANT SELECT ON TABLE agh.aip_tramite_prontuarios TO acesso_leitura;
COMMENT ON COLUMN agh.aip_tramite_prontuarios.ind_tipo_tramite IS 'Campo para determinar o tipo de tramite do prontuário. Permite os valores: S=Solicitação, E=Envio, R=Resgate, D=Devolução.';
END IF;

-- Index: agh.AIP_TRAMITE_PRONTUARIOS_PAC_PRONTUARIO_VOLUME
-- DROP INDEX agh.AIP_TRAMITE_PRONTUARIOS_PAC_PRONTUARIO_VOLUME;
IF not exists (SELECT COUNT(*) FROM pg_indexes WHERE indexname = 'aip_tramite_prontuarios_pac_prontuario_volume') THEN
CREATE INDEX AIP_TRAMITE_PRONTUARIOS_PAC_PRONTUARIO_VOLUME
    ON agh.AIP_TRAMITE_PRONTUARIOS
    USING btree
    (PAC_PRONTUARIO, VOLUME);
END IF;

IF not exists (SELECT COUNT(*) FROM information_schema.sequences WHERE sequence_schema = 'agh' AND sequence_name = 'aip_trp_sq1') THEN
CREATE SEQUENCE agh.aip_trp_sq1
    INCREMENT 1
		MINVALUE 1
		MAXVALUE 99999999999999
		START 1
		CACHE 2;
ALTER SEQUENCE agh.aip_trp_sq1 OWNER TO postgres;
GRANT ALL ON SEQUENCE agh.aip_trp_sq1 TO postgres;
	GRANT ALL ON SEQUENCE agh.aip_trp_sq1 TO acesso_completo;
GRANT SELECT ON SEQUENCE agh.aip_trp_sq1 TO acesso_leitura;
END IF;

IF not exists (SELECT COUNT(*) FROM information_schema.columns WHERE column_name = 'unf_seq_lotacao' and table_name = 'rap_servidores') THEN
ALTER TABLE agh.rap_servidores ADD unf_seq_lotacao smallint NULL;
END IF;

IF not exists (SELECT COUNT(*) FROM information_schema.table_constraints AS tc WHERE tc.constraint_name = 'rap_ser_unf_fk1' and tc.table_name='rap_servidores') THEN
ALTER TABLE agh.rap_servidores ADD CONSTRAINT rap_ser_unf_fk1 FOREIGN KEY (unf_seq_lotacao)
    REFERENCES agh.agh_unidades_funcionais (seq) MATCH SIMPLE
    ON UPDATE NO ACTION ON DELETE NO ACTION;
END IF;
END $$