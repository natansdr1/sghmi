DO $$
BEGIN
    DROP VIEW agh.v_ael_exames_solicitacao;

    IF EXISTS (
          SELECT
          FROM information_schema.columns
          WHERE table_schema = 'agh'
          AND table_name = 'ael_sinonimos_exames'
          AND column_name = 'nome'
       ) THEN
    ALTER TABLE agh.ael_sinonimos_exames ALTER COLUMN nome TYPE varchar(200);
    END IF;

    CREATE OR REPLACE VIEW agh.v_ael_exames_solicitacao
     AS
     SELECT ema.exa_sigla AS sigla,
        ema.man_seq,
        ufe.unf_seq,
        exa.descricao AS descricao_exame,
        sie.nome AS descricao_usual_exame,
        man.descricao AS descricao_material,
        unf.descricao AS descricao_unidade,
        ema.ind_dependente
       FROM agh.agh_unidades_funcionais unf,
        agh.ael_materiais_analises man,
        agh.ael_exames exa,
        agh.ael_sinonimos_exames sie,
        agh.ael_exames_material_analise ema,
        agh.ael_unf_executa_exames ufe
      WHERE ufe.ind_situacao::text = 'A'::text AND ema.exa_sigla::text = ufe.ema_exa_sigla::text AND ema.man_seq = ufe.ema_man_seq AND ema.ind_situacao::text = 'A'::text AND sie.exa_sigla::text = ema.exa_sigla::text AND sie.ind_situacao::text = 'A'::text AND exa.sigla::text = ema.exa_sigla::text AND exa.ind_situacao::text = 'A'::text AND man.seq = ema.man_seq AND man.ind_situacao::text = 'A'::text AND unf.seq = ufe.unf_seq AND unf.ind_sit_unid_func::text = 'A'::text;

    ALTER TABLE agh.v_ael_exames_solicitacao
        OWNER TO postgres;

    GRANT ALL ON TABLE agh.v_ael_exames_solicitacao TO acesso_completo;
    GRANT ALL ON TABLE agh.v_ael_exames_solicitacao TO postgres;
    GRANT SELECT ON TABLE agh.v_ael_exames_solicitacao TO acesso_leitura;

 END $$