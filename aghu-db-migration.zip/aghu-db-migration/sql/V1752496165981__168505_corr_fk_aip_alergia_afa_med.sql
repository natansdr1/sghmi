DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE contype = 'f'
    AND conrelid = 'agh.aip_alergia_pacientes'::REGCLASS
    AND conname = 'aip_alp_med_fk1'
  ) THEN
ALTER TABLE agh.aip_alergia_pacientes
    ADD CONSTRAINT aip_alp_med_fk1 FOREIGN KEY (med_codigo)
        REFERENCES agh.afa_medicamentos(mat_codigo) NOT VALID;
RAISE INFO 'Constraint aip_alp_med_fk1 criada com sucesso';
END IF;

  IF NOT EXISTS (
    select 1
    from pg_indexes ix
    where ix.schemaname = 'agh'
    and tablename = 'aip_alergia_pacientes'
    and indexname = 'aip_alp_med_fk1_i'
  ) THEN
CREATE INDEX aip_alp_med_fk1_i ON agh.aip_alergia_pacientes USING btree (med_codigo);
RAISE INFO 'Index aip_alp_med_fk1_i criado com sucesso';
END IF;
END;
$$;