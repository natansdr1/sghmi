do $$
    declare
columnName varchar(256) := null;
    isNullable varchar(5) := null;
    columnDefault varchar(50) := null;
begin
select a.column_name, a.is_nullable, a.column_default
into columnName, isNullable, columnDefault
from information_schema.columns a
where a.table_schema = 'agh' and a.table_name = 'agh_prof_especialidades' and a.column_name = 'ind_prof_supervisor';
if(columnName is null) then
        -- Se a coluna não existe, adicione-a com DEFAULT VALUE 'N'
alter table agh.agh_prof_especialidades add column ind_prof_supervisor varchar(1) not null default 'N'::character varying;
comment on column agh.agh_prof_especialidades.ind_prof_supervisor is 'Indica que o profissional poderá supervisionar os atendimentos desta especialidade.';
        raise notice 'EXECUTADO ALTERAÇÃO: #25228 - Novas coluna agh.agh_prof_especialidades.ind_prof_supervisor';
    elsif(columnName is not null and isNullable = 'YES') then
        -- Se a coluna já existe, atualiza valores nulos para o DEFAULT 'N'
update agh.agh_prof_especialidades
set ind_prof_supervisor = 'N'
where ind_prof_supervisor is null or trim(ind_prof_supervisor) = '';
-- Ajusta coluna para NOT NULL
alter table agh.agh_prof_especialidades alter column ind_prof_supervisor set not null;
end if;

-- Cria check constraint 'N' e 'S'
begin
alter table agh.agh_prof_especialidades add constraint agh_cki_ind_prof_supervisor check (ind_prof_supervisor = any (array['S', 'N']::varchar[]));
exception
        when others then 
        	--raise info 'error name:%', sqlerrm;
            --raise info 'error state:%', sqlstate;
            --Erro na criação da constraint. Não há problema, simplesmente ignorar, a mesma já existe.
            null;
end;
exception
    when others then
        raise notice 'erro na verificação da tabela agh_prof_especialidades';
		raise info 'error name:%', sqlerrm;
		raise info 'error state:%', sqlstate;
end $$;    