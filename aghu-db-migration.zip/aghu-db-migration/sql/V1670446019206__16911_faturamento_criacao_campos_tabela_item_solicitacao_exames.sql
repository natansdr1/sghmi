DO $$
BEGIN

if not exists (
			select 1 from information_schema.columns
			where table_schema = 'agh' and table_name = 'ael_item_solicitacao_exames' and column_name = 'agh_cid_procedimento_seq') then begin
alter table agh.ael_item_solicitacao_exames add agh_cid_procedimento_seq integer null;
raise notice 'Coluna agh_cid_procedimento_seq integer criada na tabela agh.ael_item_solicitacao_exames';
alter table agh.ael_item_solicitacao_exames add constraint ael_ise_agh_cid_procedimento_fk foreign key (agh_cid_procedimento_seq)
references agh.agh_cids (seq) match SIMPLE on update no action on delete no action;
raise notice 'Foreign key ael_ise_agh_cid_procedimento_fk criada na tabela agh.ael_item_solicitacao_exames.';
exception
			when others then
				raise info 'Error Name:%', sqlerrm;
				raise info 'Error State:%', sqlstate;
end;
end if;

if not exists (
			select 1 from information_schema.columns
			where table_schema = 'agh' and table_name = 'ael_item_solicitacao_exames' and column_name = 'fat_cbos_liberacao_exame_seq') then begin
alter table agh.ael_item_solicitacao_exames add fat_cbos_liberacao_exame_seq integer null;
raise notice 'Coluna fat_cbos_liberacao_exame_seq integer criada na tabela agh.ael_item_solicitacao_exames';
alter table agh.ael_item_solicitacao_exames add constraint ael_ise_fat_cbos_liberacao_exame_fk foreign key (fat_cbos_liberacao_exame_seq)
references agh.fat_cbos (seq) match SIMPLE on update no action on delete no action;
raise notice 'Foreign key ael_ise_fat_cbos_liberacao_exame_fk criada na tabela agh.ael_item_solicitacao_exames.';
exception
			when others then
				raise info 'Error Name:%', sqlerrm;
				raise info 'Error State:%', sqlstate;
end;
end if;

END $$