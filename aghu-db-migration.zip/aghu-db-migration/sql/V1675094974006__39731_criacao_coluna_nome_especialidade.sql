do $$
begin
	if not exists(
		select null from information_schema.columns where table_schema = 'agh' and table_name = 'mpm_nota_adicional_evolucoes'
		and column_name = 'nome_especialidade') then 
		begin
			alter table agh.mpm_nota_adicional_evolucoes add nome_especialidade text null;
			comment on column agh.afa_disp_mdto_cb_sps.lote_mat is 'Guardar as notas adicionais das Evolucao da Internação';
			raise notice 'EXECUTADO ALTERAÇÃO: #39731 - Novas colunas agh.mpm_nota_adicional_evolucoes';
		exception
			when others then
				raise notice 'Erro na criação da coluna nome_especialidade na tabela agh.mpm_nota_adicional_evolucoes';
				raise info 'Error Name:%', sqlerrm;
				raise info 'Error State:%', sqlstate;
		end;
	end if;

	if not exists(select null from information_schema.columns where table_schema = 'agh' and table_name = 'mpm_nota_adicional_anamneses'
		and column_name = 'nome_especialidade') then
		begin
			alter table agh.mpm_nota_adicional_anamneses add nome_especialidade text null;
			comment on column agh.afa_disp_mdto_cb_sps.lote_mat is 'Guardar as notas adicionais das Anamneses da Internação';
			raise notice 'EXECUTADO ALTERAÇÃO: #39731 - Novas colunas agh.mpm_nota_adicional_anamneses';
		exception
			when others then
				raise notice 'Erro na criação da coluna nome_especialidade na tabela agh.mpm_nota_adicional_anamneses';
				raise info 'Error Name:%', sqlerrm;
				raise info 'Error State:%', sqlstate;
		end;
	end if;
end $$;
