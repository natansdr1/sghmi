DO $$
BEGIN

IF not exists(SELECT null
    FROM information_schema.columns
    WHERE table_name = 'agh_versoes_documentos' and column_name = 'justificativa' and table_schema = 'agh')
    then ALTER TABLE agh.agh_versoes_documentos add justificativa varchar(100);
        comment on column agh.agh_versoes_documentos.justificativa is 'Coluna responsável por guardar as justificativas porque o documento não ter sido assinado digitalmente.';
END IF;

END $$