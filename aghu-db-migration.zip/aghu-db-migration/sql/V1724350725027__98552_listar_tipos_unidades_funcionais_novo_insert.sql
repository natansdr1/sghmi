DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM information_schema.columns
        WHERE table_schema = 'agh'
        AND table_name = 'agh_tipos_unidade_funcional'
        AND column_name = 'ativo'
         AND column_name = 'assistencial'
    ) THEN
        IF NOT EXISTS (SELECT 1 FROM agh.agh_tipos_unidade_funcional WHERE descricao = 'RN Virtual') THEN
            INSERT INTO agh.agh_tipos_unidade_funcional (seq, descricao, "version", seq_esperanto, ativo, assistencial)
            VALUES (nextval('AGH.AGH_TUF_SQ1'), 'RN Virtual', 0, null, true, true);
        END IF;
    END IF;
END $$;
