--demanda sustentação requisição #39853
--[sustentação]- análise de script para inclusão no flyway
--testes realizados na máquina 46 database hcufpe.
--select current_database();

do $$
declare
obj_existe decimal(1) := null;
	error_count decimal(3) := 0;
begin
select 1 into obj_existe from information_schema.tables a where a.table_schema = 'casca' and a.table_name = 'csc_usuarios_api';
if(obj_existe is null) then begin
create table casca.csc_usuarios_api (
                                        seq int4 not null,
                                        nome varchar(255) not null,
                                        login_hcpa varchar(80) null,
                                        data_criacao timestamp null,
                                        email varchar(250) null,
                                        data_ultimo_acesso timestamp null,
                                        ativo bool not null,
                                        tempo_token_minutos int2 null,
                                        limite_tokens_ativos int2 null,
                                        auth_usuario varchar(25) null,
                                        auth_key varchar(250) null,
                                        "version" int4 not null,
                                        constraint csc_usuarios_api_pk primary key (seq)
);
comment on table casca.csc_usuarios_api is 'Tabela que armazena os usuários utilizados na api.';
		comment on column casca.csc_usuarios_api.seq is 'Chave primária da tabela casca.csc_usuarios_api. Coluna alimentada pela sequence casca.casca_usuarios_api_sq1';
		comment on column casca.csc_usuarios_api.nome is 'Nome completo do usuário';
		comment on column casca.csc_usuarios_api.login_hcpa is ' ';
		comment on column casca.csc_usuarios_api.data_criacao is 'Data de criação do registro.';
		comment on column casca.csc_usuarios_api.email is 'EMail do usuário.';
		comment on column casca.csc_usuarios_api.data_ultimo_acesso is 'Data de último acesso do usuário no sistema.';
		comment on column casca.csc_usuarios_api.ativo is 'Indica se o usuário está ativo ou não. O tipo é booleano.';
		comment on column casca.csc_usuarios_api.tempo_token_minutos is ' ';
		comment on column casca.csc_usuarios_api.limite_tokens_ativos is ' ';
		comment on column casca.csc_usuarios_api.auth_usuario is ' ';
		comment on column casca.csc_usuarios_api.auth_key is ' ';
		comment on column casca.csc_usuarios_api.version is ' ';
		raise notice 'Tabela casca.csc_usuarios_api criada com sucesso.';
exception
		when others then
			error_count := error_count + 1;
			raise notice 'Erro na criação da tabela casca.csc_usuarios_api';
		    raise info 'Error Name:%', sqlerrm;
		    raise info 'Error State:%', sqlstate;
end;
else raise notice 'A tabela casca.csc_usuarios_api já existe.';
end if;

select 1 into obj_existe from information_schema.sequences a where a.sequence_schema = 'casca' and a.sequence_name = 'casca_usuarios_api_sq1';
if(obj_existe is null) then begin
create sequence casca.casca_usuarios_api_sq1 increment by 1 minvalue 1 maxvalue 9223372036854775807 start 1 cache 1 no cycle owned by casca.csc_usuarios_api.seq;
raise notice 'sequence casca.casca_usuarios_api_sq1 criada com sucesso.';
exception
			when others then
				error_count := error_count + 1;
				raise notice 'Erro na criação da sequence casca.casca_usuarios_api_sq1';
			    raise info 'Error Name:%', sqlerrm;
			    raise info 'Error State:%', sqlstate;
end;
else raise notice 'Sequence casca.casca_usuarios_api_sq1 já existe.';
end if;

select 1 into obj_existe from information_schema.tables a where a.table_schema = 'casca' and a.table_name = 'csc_perfil_api';
if(obj_existe is null) then begin
create table casca.csc_perfil_api (
                                      seq int4 not null,
                                      nome varchar(255) not null,
                                      descricao varchar(1024) null,
                                      descricao_resumida varchar(255) null,
                                      data_criacao timestamp not null,
                                      situacao bpchar(1) not null,
                                      "version" int4 not null,
                                      constraint csc_perfil_api_pk primary key (seq)
);
comment on table casca.csc_perfil_api is 'Tabela que armazena os perfis utilizados na api.';
			comment on column casca.csc_perfil_api.seq is 'Chave primária da tabela casca.csc_perfil_api. Coluna alimentada pela sequence casca.csc_perfil_api_sq1.';
			comment on column casca.csc_perfil_api.nome is 'Nome completo do perfil.';
			comment on column casca.csc_perfil_api.descricao is 'Texto descritivo do perfil.';
			comment on column casca.csc_perfil_api.descricao_resumida is 'Texto descritivo resumido do perfil.';
			comment on column casca.csc_perfil_api.data_criacao is 'Data de criação do registro.';
			comment on column casca.csc_perfil_api.situacao is ' ';
			comment on column casca.csc_perfil_api.version is ' ';
			raise notice 'Tabela casca.csc_perfil_api criada com sucesso.';
exception
			when others then
				error_count := error_count + 1;
				raise notice 'Erro na criação da tabela casca.csc_perfil_api';
			    raise info 'Error Name:%', sqlerrm;
			    raise info 'Error State:%', sqlstate;
end;
else raise notice 'Tabela casca.csc_perfil_api já existe.';
end if;

select 1 into obj_existe from information_schema.sequences a where a.sequence_schema = 'casca' and a.sequence_name = 'csc_perfil_api_sq1';
if(obj_existe is null) then begin
create sequence casca.csc_perfil_api_sq1 increment by 1 minvalue 1 maxvalue 9223372036854775807 start 1 cache 1 no cycle owned by casca.csc_perfil_api.seq;
raise notice 'sequence casca.csc_perfil_api_sq1 criada com sucesso.';
exception
			when others then
				error_count := error_count + 1;
				raise notice 'Erro na criação da sequence casca.csc_perfil_api_sq1';
			    raise info 'Error Name:%', sqlerrm;
			    raise info 'Error State:%', sqlstate;
end;
else raise notice 'Sequence casca.csc_perfil_api_sq1 já existe.';
end if;

select 1 into obj_existe from information_schema.tables a where a.table_schema = 'casca' and a.table_name = 'csc_tokens_api';
if(obj_existe is null) then begin
create table casca.csc_tokens_api (
                                      seq int4 not null,
                                      seq_usuario int4 not null,
                                      host_cliente varchar(255) null,
                                      "token" varchar(1024) null,
                                      data_criacao timestamp null,
                                      data_expiracao timestamp null,
                                      limite_operacoes int4 null,
                                      refresh_token varchar(1024) null,
                                      ind_refresh int4 null,
                                      login_hcpa varchar(80) null,
                                      "version" int4 null,
                                      constraint csc_tokens_api_pk primary key (seq),
                                      constraint csc_tokens_api_fk foreign key (seq_usuario) references casca.csc_usuarios_api(seq)
);
comment on table casca.csc_tokens_api is 'Tabela que armazena as descrições dos tokens.';
		comment on column casca.csc_tokens_api.seq is 'Chave primária da tabela casca.csc_tokens_api. Coluna alimentada pela sequence casca.casca_tokens_api_sq1.';
		comment on column casca.csc_tokens_api.seq_usuario is 'Chave estrangeira da tabela casca.csc_usuarios_api.';
		comment on column casca.csc_tokens_api.host_cliente is ' ';
		comment on column casca.csc_tokens_api.token is ' ';
		comment on column casca.csc_tokens_api.data_criacao is 'Data de criação do registro.';
		comment on column casca.csc_tokens_api.data_expiracao is 'Data de expiração do token.';
		comment on column casca.csc_tokens_api.limite_operacoes is ' ';
		comment on column casca.csc_tokens_api.refresh_token is ' ';
		comment on column casca.csc_tokens_api.ind_refresh is ' ';
		comment on column casca.csc_tokens_api.login_hcpa is ' ';
		comment on column casca.csc_tokens_api.version is ' ';
		raise notice 'Tabela casca.csc_tokens_api criada com sucesso.';
exception
		when others then
			error_count := error_count + 1;
			raise notice 'Erro na criação da tabela casca.csc_perfil_api';
		    raise info 'Error Name:%', sqlerrm;
		    raise info 'Error State:%', sqlstate;
end;
else raise notice 'Tabela casca.csc_tokens_api já existe.';
end if;

select 1 into obj_existe from information_schema.sequences a where a.sequence_schema = 'casca' and a.sequence_name = 'casca_tokens_api_sq1';
if(obj_existe is null) then begin
create sequence casca.casca_tokens_api_sq1 increment by 1 minvalue 1 maxvalue 9223372036854775807 start 1 cache 1 no cycle owned by casca.csc_tokens_api.seq;
raise notice 'sequence casca.casca_tokens_api_sq1 criada com sucesso';
exception
		when others then
			error_count := error_count + 1;
			raise notice 'Erro na criação da sequence casca.casca_tokens_api_sq1';
		    raise info 'Error Name:%', sqlerrm;
		    raise info 'Error State:%', sqlstate;
end;
else raise notice 'Sequence casca.casca_tokens_api_sq1 já existe.';
end if;

select 1 into obj_existe from pg_indexes a where a.tablename = 'csc_tokens_api' and a.indexname = 'csc_tokens_api_seq_usuario_idx';
if(obj_existe is null) then begin
create index csc_tokens_api_seq_usuario_idx on casca.csc_tokens_api(seq_usuario);
raise notice 'index csc_tokens_api_seq_usuario_idx criado com sucesso.';
exception
		when others then
			error_count := error_count + 1;
			raise notice 'Erro na criação do índice csc_tokens_api_seq_usuario_idx';
		    raise info 'Error Name:%', sqlerrm;
		    raise info 'Error State:%', sqlstate;
end;
else raise notice 'Index csc_tokens_api_seq_usuario_idx já existe.';
end if;

select 1 into obj_existe from information_schema.tables a where a.table_schema = 'casca' and a.table_name = 'csc_perfis_usuarios_api';
if(obj_existe is null) then begin
create table casca.csc_perfis_usuarios_api (
                                               seq int4 not null,
                                               id_usuario_api int4 not null,
                                               id_perfil int4 not null,
                                               dt_atribuicao timestamp not null,
                                               constraint csc_perfis_usuarios_api_pk primary key (seq),
                                               constraint csc_perfis_usuarios_api_fk foreign key (id_perfil) references casca.csc_perfil_api(seq),
                                               constraint csc_perfis_usuarios_api_fk2 foreign key (id_usuario_api) references casca.csc_usuarios_api(seq)
);
comment on table casca.csc_perfis_usuarios_api is 'Tabela associativa entre as tabelas casca.csc_perfil_api e casca.csc_usuarios_api.';
		comment on column casca.csc_perfis_usuarios_api.seq is 'Chave primária da tabela casca.csc_perfis_usuarios_api. Coluna alimentada pela sequence casca.csc_perfis_usuarios_api_sq1.';
		comment on column casca.csc_perfis_usuarios_api.id_usuario_api is 'Chave estrangeira da tabela csc_usuarios_api.';
		comment on column casca.csc_perfis_usuarios_api.id_perfil is 'Chave estrangeira da tabela csc_perfil_api.';
		comment on column casca.csc_perfis_usuarios_api.dt_atribuicao is 'Data em que o perfil foi vinculado ao usuário.';
		raise notice 'Tabela casca.csc_perfis_usuarios_api criada com sucesso.';
exception
		when others then
			error_count := error_count + 1;
			raise notice 'Erro na criação da tabela casca.csc_perfis_usuarios_api.';
		    raise info 'Error Name:%', sqlerrm;
		    raise info 'Error State:%', sqlstate;
end;
else raise notice 'Tabela casca.csc_perfis_usuarios_api já existe.';
end if;

select 1 into obj_existe from information_schema.sequences a where a.sequence_schema = 'casca' and a.sequence_name = 'csc_perfis_usuarios_api_sq1';
if(obj_existe is null) then begin
create sequence casca.csc_perfis_usuarios_api_sq1 increment by 1 minvalue 1 maxvalue 9223372036854775807 start 1 cache 1 no cycle owned by casca.csc_perfis_usuarios_api.seq;
raise notice 'sequence casca.csc_perfis_usuarios_api_sq1 criada com sucesso.';
exception
		when others then
			error_count := error_count + 1;
			raise notice 'Erro na criação da sequence casca.csc_perfis_usuarios_api_sq1';
		    raise info 'Error Name:%', sqlerrm;
		    raise info 'Error State:%', sqlstate;
end;
else raise notice 'Sequence casca.csc_perfis_usuarios_api_sq1 já existe.';
end if;

select 1 into obj_existe from pg_indexes a where a.tablename = 'csc_perfis_usuarios_api' and a.indexname = 'csc_perfis_usuarios_api_id_perfil_idx';
if(obj_existe is null) then begin
create index csc_perfis_usuarios_api_id_perfil_idx on casca.csc_perfis_usuarios_api(id_perfil);
raise notice 'index csc_perfis_usuarios_api_id_perfil_idx criado com sucesso.';
exception
		when others then
			error_count := error_count + 1;
			raise notice 'Erro na criação do índice csc_perfis_usuarios_api_id_perfil_idx';
		    raise info 'Error Name:%', sqlerrm;
		    raise info 'Error State:%', sqlstate;
end;
else raise notice 'Index csc_perfis_usuarios_api_id_perfil_idx já existe.';
end if;

select 1 into obj_existe from pg_indexes a where a.tablename = 'csc_perfis_usuarios_api' and a.indexname = 'csc_perfis_usuarios_api_id_usuario_api_idx';
if(obj_existe is null) then begin
create index csc_perfis_usuarios_api_id_usuario_api_idx on casca.csc_perfis_usuarios_api(id_usuario_api);
raise notice 'index csc_perfis_usuarios_api_id_usuario_api_idx criado com sucesso';
exception
		when others then
			error_count := error_count + 1;
			raise notice 'Erro na criação do índice csc_perfis_usuarios_api_id_usuario_api_idx';
		    raise info 'Error Name:%', sqlerrm;
		    raise info 'Error State:%', sqlstate;
end;
else raise notice 'Index csc_perfis_usuarios_api_id_usuario_api_idx já existe.';
end if;

	raise notice 'Número de erros durante a operação: %', error_count;
end $$;


/* Remoção dos objetos, caso necessário;
drop sequence casca.casca_tokens_api_sq1;
drop sequence casca.casca_usuarios_api_sq1;
drop sequence casca.csc_perfil_api_sq1;
drop sequence casca.csc_perfis_usuarios_api_sq1;
drop table casca.csc_perfis_usuarios_api;
drop table casca.csc_tokens_api;
drop table casca.csc_usuarios_api;
drop table casca.csc_perfil_api;
*/

