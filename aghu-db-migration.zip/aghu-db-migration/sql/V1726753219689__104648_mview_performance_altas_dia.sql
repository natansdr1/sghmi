do
$$
declare
atualizou_mview boolean;
begin
 
if EXISTS (SELECT 1 FROM pg_catalog.pg_views WHERE schemaname = 'agh' and viewname = 'v_aip_ceps') then
  drop VIEW if exists agh.v_aip_ceps;
RAISE NOTICE 'Drop View agh.v_aip_ceps';
end if;
 
if EXISTS (SELECT 1 FROM pg_catalog.pg_matviews WHERE schemaname = 'agh' and matviewname = 'v_aip_ceps') then
  drop MATERIALIZED VIEW if exists agh.v_aip_ceps;
  RAISE NOTICE 'Drop MVIew agh.v_aip_ceps';
end if;
 
create MATERIALIZED VIEW agh.v_aip_ceps
TABLESPACE tblspc_one
AS SELECT bcl.clo_cep AS cep,
    ((tip.abreviatura::text || ' '::text) ||
        CASE
            WHEN tit.descricao IS NULL THEN ''::text
            ELSE tit.descricao::text || ' '::text
        END) || lgr.nome::text AS logradouro,
    bcl.clo_lgr_codigo AS lgr_codigo,
    bcl.bai_codigo AS lgr_bai_codigo,
    clo.nro_inicial AS lgr_nro_inicial,
    clo.nro_final AS lgr_nro_final,
    clo.lado AS lgr_lado,
    NULL::character varying AS nome,
    cdd.codigo AS cdd_codigo,
    cdd.nome AS cidade,
    cdd.cod_ibge,
    bai.descricao AS bairro,
    uf.sigla AS uf_sigla,
    bcl.ind_situacao,
    'Logradouro'::text AS tipo,
    '0'::text AS classificacao,
    lgr.codigo_base_correio,
    bcl.ctid AS row_id
   FROM agh.aip_bairros_cep_logradouro bcl
     JOIN agh.aip_bairros bai ON bai.codigo = bcl.bai_codigo
     JOIN agh.aip_cep_logradouros clo ON clo.cep = bcl.clo_cep AND clo.lgr_codigo = bcl.clo_lgr_codigo
     JOIN agh.aip_logradouros lgr ON lgr.codigo = clo.lgr_codigo
     JOIN agh.aip_tipo_logradouros tip ON tip.codigo = lgr.tlg_codigo
     LEFT JOIN agh.aip_titulo_logradouros tit ON tit.codigo = lgr.tit_codigo
     JOIN agh.aip_cidades cdd ON lgr.cdd_codigo = cdd.codigo AND cdd.cep = 0
     JOIN agh.aip_ufs uf ON cdd.uf_sigla::text = uf.sigla::text
  WHERE (bcl.ind_situacao::text = 'A'::text OR bcl.ind_situacao IS NULL) AND (clo.ind_situacao::text = 'A'::text OR clo.ind_situacao IS NULL)
UNION
SELECT cdd.cep,
    NULL::text AS logradouro,
    NULL::integer AS lgr_codigo,
    NULL::integer AS lgr_bai_codigo,
    NULL::character varying AS lgr_nro_inicial,
    NULL::character varying AS lgr_nro_final,
    NULL::character varying AS lgr_lado,
    cdd.nome,
    cdd.codigo AS cdd_codigo,
    cdd.nome AS cidade,
    cdd.cod_ibge,
    NULL::character varying AS bairro,
    cdd.uf_sigla,
    cdd.ind_situacao,
    'Cidade (Sem logradouros)'::text AS tipo,
    '1'::text AS classificacao,
    cdd.codigo_base_correio,
    cdd.ctid AS row_id
   FROM agh.aip_cidades cdd
  WHERE cdd.cep > 0 AND (cdd.ind_situacao::text = 'A'::text OR cdd.ind_situacao IS NULL)
UNION
SELECT uno.cep,
    uno.endereco AS logradouro,
    NULL::integer AS lgr_codigo,
    NULL::integer AS lgr_bai_codigo,
    NULL::character varying AS lgr_nro_inicial,
    NULL::character varying AS lgr_nro_final,
    NULL::character varying AS lgr_lado,
    uno.descricao AS nome,
    cdd.codigo AS cdd_codigo,
    cdd.nome AS cidade,
    cdd.cod_ibge,
    bai.descricao AS bairro,
    cdd.uf_sigla,
    cdd.ind_situacao,
    'Unidade de operacao'::text AS tipo,
    '3'::text AS classificacao,
    uno.codigo_base_correio,
    uno.ctid AS row_id
   FROM agh.aip_bairros bai
     JOIN agh.aip_unidade_operacao uno ON bai.codigo = uno.bai_codigo
     JOIN agh.aip_cidades cdd ON cdd.codigo = uno.cdd_codigo
  WHERE (cdd.ind_situacao::text = 'A'::text OR cdd.ind_situacao IS NULL) AND (uno.ind_situacao::text = 'A'::text OR uno.ind_situacao IS NULL)
UNION
SELECT cpc.cep,
    (cpc.nome::text || ' '::text) || cpc.endereco::text AS logradouro,
    NULL::integer AS lgr_codigo,
    NULL::integer AS lgr_bai_codigo,
    NULL::character varying AS lgr_nro_inicial,
    NULL::character varying AS lgr_nro_final,
    NULL::character varying AS lgr_lado,
    (cpc.nome::text || ' '::text) || cpc.endereco::text AS nome,
    cdd.codigo AS cdd_codigo,
    cdd.nome AS cidade,
    cdd.cod_ibge,
        CASE
            WHEN "position"(cpc.nome::text, '- '::text) = 0 THEN ''::text
            ELSE ltrim(substr(cpc.nome::text, "position"(cpc.nome::text, '- '::text) + 1, length(cpc.nome::text) - "position"(cpc.nome::text, '- '::text) + 1), ' '::text)
        END AS bairro,
    cdd.uf_sigla,
    cdd.ind_situacao,
    'Caixa Postal Comunitária'::text AS tipo,
    '2'::text AS classificacao,
    cpc.codigo_base_correio,
    cpc.ctid AS row_id
   FROM agh.aip_cidades cdd
     JOIN agh.aip_caixa_postal_comunitarias cpc ON cdd.codigo = cpc.cdd_codigo
  WHERE (cdd.ind_situacao::text = 'A'::text OR cdd.ind_situacao IS NULL) AND (cpc.ind_situacao::text = 'A'::text OR cpc.ind_situacao IS NULL)
UNION
SELECT gus.cep,
    gus.endereco AS logradouro,
    gus.lgr_codigo,
    gus.bai_codigo AS lgr_bai_codigo,
    NULL::character varying AS lgr_nro_inicial,
    NULL::character varying AS lgr_nro_final,
    NULL::character varying AS lgr_lado,
    (gus.nome::text || ' '::text) || gus.endereco::text AS nome,
    cdd.codigo AS cdd_codigo,
    cdd.nome AS cidade,
    cdd.cod_ibge,
    bai.descricao AS bairro,
    cdd.uf_sigla,
    gus.ind_situacao,
    'Grandes Usuários'::text AS tipo,
    '4'::text AS classificacao,
    gus.codigo_base_correio,
    gus.ctid AS row_id
   FROM agh.aip_bairros bai
     JOIN agh.aip_grandes_usuarios gus ON bai.codigo = gus.bai_codigo
     JOIN agh.aip_cidades cdd ON cdd.codigo = gus.cdd_codigo
  WHERE gus.ind_situacao::text = 'A'::text OR gus.ind_situacao IS NULL
WITH no DATA;
RAISE NOTICE 'MView com sua estrutura criada agh.v_aip_ceps';
 
CREATE INDEX v_aip_ceps_cep_idx1 ON agh.v_aip_ceps (cep) tablespace tblspc_idx;
RAISE NOTICE 'Indice v_aip_ceps_cep_idx1 criado';
CREATE INDEX v_aip_ceps_cep_idx2 ON agh.v_aip_ceps (lgr_codigo) tablespace tblspc_idx;
RAISE NOTICE 'Indice v_aip_ceps_cep_idx2 criado';
CREATE INDEX v_aip_ceps_cep_idx3 ON agh.v_aip_ceps (lgr_bai_codigo) tablespace tblspc_idx;
RAISE NOTICE 'Indice v_aip_ceps_cep_idx3 criado';
 
 
GRANT SELECT ON TABLE agh.v_aip_ceps TO acesso_completo, acesso_leitura;
RAISE NOTICE 'Grant concedido agh.v_aip_ceps TO acesso_completo, acesso_leitura';
 
CREATE OR REPLACE FUNCTION agh.atualiza_mview_v_aip_ceps()
RETURNS boolean
LANGUAGE plpgsql
AS $function$
BEGIN
    drop index if exists agh.v_aip_ceps_cep_idx1;
    drop index if exists agh.v_aip_ceps_cep_idx2;
    drop index if exists agh.v_aip_ceps_cep_idx3;   
    REFRESH MATERIALIZED VIEW agh.v_aip_ceps;
    CREATE INDEX v_aip_ceps_cep_idx1 ON agh.v_aip_ceps (cep) tablespace tblspc_idx;
    CREATE INDEX v_aip_ceps_cep_idx2 ON agh.v_aip_ceps (lgr_codigo) tablespace tblspc_idx;
    CREATE INDEX v_aip_ceps_cep_idx3 ON agh.v_aip_ceps (lgr_bai_codigo) tablespace tblspc_idx;
    raise notice 'MView (agh.v_aip_ceps) atualizada com sucesso!';
    Return TRUE;
    EXCEPTION
    WHEN OTHERS THEN
    raise notice 'MView (agh.v_aip_ceps) não foi atualizada!';
    Return FALSE;
END;
$function$
;
RAISE NOTICE 'Função de Atualização da MView criada [agh.atualiza_mview_v_aip_ceps]';
 
GRANT execute on function agh.atualiza_mview_v_aip_ceps() TO acesso_completo;
RAISE NOTICE 'Grant concedido agh.atualiza_mview_v_aip_ceps() TO acesso_completo';
 
select agh.atualiza_mview_v_aip_ceps() into atualizou_mview;
RAISE NOTICE 'Atualizou MVIEW: [%]',atualizou_mview;
 
end;
$$
LANGUAGE plpgsql;