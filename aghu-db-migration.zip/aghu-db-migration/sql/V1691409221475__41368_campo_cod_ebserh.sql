DO $$
BEGIN

    IF NOT EXISTS(
            SELECT 1
            FROM information_schema.columns
            WHERE table_schema = 'agh'
                AND table_name = 'sco_materiais'
                AND column_name = 'cod_ebserh'
        ) THEN
alter table agh.sco_materiais add cod_ebserh char(8);
END IF;

END $$