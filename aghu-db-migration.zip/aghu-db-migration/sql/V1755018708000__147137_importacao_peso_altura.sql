/**
 * @arquivo   migrar_dados_antropometricos.sql
 * @objetivo  Script para migrar dados antropométricos (altura, peso e superfície corpórea) 
 *            para tabela de controles
 *
 * @autor     Marco Leony e Ricardo Leitinho
 * @data      2025-07-10
 * @versao    1.0
 *
 * Este script realiza a migração de dados de:
 * 1. Altura (aip_altura_pacientes)
 * 2. Peso (aip_peso_pacientes)
 * 3. Superfície Corpórea calculada (mpm_param_calculo_prescricoes)
 * 
 * Para as tabelas de controle:
 * - ecp_horario_controles (registro do momento da medição)
 * - ecp_controle_pacientes (valores das medições)
 *
 * Fluxo principal:
 * 1. Verifica existência dos itens de controle necessários
 * 2. Para cada registro de parâmetro de cálculo:
 *    a. Cria horário de controle se não existir
 *    b. Insere medições de altura, peso e SC como itens de controle
 * 3. Reporta estatísticas da migração
 *
 * @observacao   Requer que os itens de controle Altura (Alt), Peso (Peso) e 
 *               Superfície Corpórea (SC) estejam previamente cadastrados
 *               em produção e verificação prévia dos itens de controle
 */
DO $$
DECLARE
  cursor_medidas CURSOR FOR
    SELECT
      atp.altura / 100 AS altura,
      pep.peso,
      DATE_TRUNC('MINUTE', pca.criado_em) AS data_hora,
      pca.criado_em,
      pca.ser_matricula,
      pca.ser_vin_codigo,
      pca.version,
      atd.pac_codigo,
      pca.sc_calculada
    FROM agh.mpm_param_calculo_prescricoes pca
    JOIN agh.agh_atendimentos atd
      ON pca.atd_seq = atd.seq
    LEFT JOIN agh.aip_altura_pacientes atp
      ON pca.atp_pac_codigo = atp.pac_codigo
      AND pca.atp_criado_em = atp.criado_em
    LEFT JOIN agh.aip_peso_pacientes pep
      ON pca.pep_pac_codigo = pep.pac_codigo
      AND pca.pep_criado_em = pep.criado_em
    WHERE pca.sc_calculada IS NOT NULL
    OR pca.atp_pac_codigo IS NOT NULL
    OR pca.pep_pac_codigo IS NOT NULL;

  v_altura agh.aip_altura_pacientes.altura%type;
  v_peso agh.aip_peso_pacientes.peso%type;
  v_criado_em agh.mpm_param_calculo_prescricoes.criado_em%type;
  v_data_hora agh.ecp_horario_controles.data_hora%type;
  v_ser_matricula agh.mpm_param_calculo_prescricoes.ser_matricula%type;
  v_ser_vin_codigo agh.mpm_param_calculo_prescricoes.ser_vin_codigo%type;
  v_version agh.mpm_param_calculo_prescricoes.version%type;
  v_pac_codigo agh.agh_atendimentos.pac_codigo%type;
  v_sc_calculada agh.mpm_param_calculo_prescricoes.sc_calculada%type;
  v_hct_seq agh.ecp_horario_controles.seq%type;
  v_ice_seq_altura agh.ecp_item_controles.seq%type;
  v_umm_seq_altura agh.mpm_unidade_medida_medicas.seq%type;
  v_ice_seq_peso agh.ecp_item_controles.seq%type;
  v_umm_seq_peso agh.mpm_unidade_medida_medicas.seq%type;
  v_ice_seq_sc agh.ecp_item_controles.seq%type;
  v_umm_seq_sc agh.mpm_unidade_medida_medicas.seq%type;

  v_sigla_altura TEXT := 'Alt';
  v_sigla_peso TEXT := 'Peso';
  v_sigla_sc TEXT := 'SC';
  v_error BOOLEAN := FALSE;

  v_alturas_inseridas INT := 0;
  v_pesos_inseridos INT := 0;
  v_scs_inseridas INT := 0;
BEGIN
  SELECT seq, umm_seq
  INTO v_ice_seq_altura, v_umm_seq_altura
  FROM agh.ecp_item_controles
  WHERE sigla = v_sigla_altura;
  IF v_ice_seq_altura IS NULL THEN
    RAISE INFO 'Item de controle % não encontrado', v_sigla_altura;
    v_error := TRUE;
  END IF;

  SELECT seq, umm_seq
  INTO v_ice_seq_peso, v_umm_seq_peso
  FROM agh.ecp_item_controles
  WHERE sigla = v_sigla_peso;
  IF v_ice_seq_peso IS NULL THEN
    RAISE INFO 'Item de controle % não encontrado', v_sigla_peso;
    v_error := TRUE;
  END IF;

  SELECT seq, umm_seq
  INTO v_ice_seq_sc, v_umm_seq_sc
  FROM agh.ecp_item_controles
  WHERE sigla = v_sigla_sc;
  IF v_ice_seq_sc IS NULL THEN
    RAISE INFO 'Item de controle % não encontrado', v_sigla_sc;
    v_error := TRUE;
  END IF;

  IF v_error THEN
    RAISE EXCEPTION '01 - Erro ao localizar itens de controle';
  END IF;

  RAISE NOTICE 'Iniciada a migração de altura, peso e superfície corpórea';
  RAISE NOTICE '-----------------------------';
  OPEN cursor_medidas;
  LOOP
    FETCH cursor_medidas INTO
      v_altura,
      v_peso,
      v_data_hora,
      v_criado_em,
      v_ser_matricula,
      v_ser_vin_codigo,
      v_version,
      v_pac_codigo,
      v_sc_calculada;
    EXIT
    WHEN NOT FOUND;

    SELECT seq INTO v_hct_seq
    FROM agh.ecp_horario_controles
    WHERE data_hora = v_data_hora
    AND pac_codigo = v_pac_codigo;

    IF v_hct_seq IS NULL THEN
      BEGIN
      v_hct_seq := NEXTVAL('agh.ecp_hct_sq1');
        INSERT INTO agh.ecp_horario_controles(
          seq, data_hora, criado_em, pac_codigo, ser_matricula,
          ser_vin_codigo, version
        )
        VALUES(
          v_hct_seq, v_data_hora, v_criado_em, v_pac_codigo, v_ser_matricula,
          v_ser_vin_codigo, v_version
        );
        RAISE NOTICE 'Inserido horário de controle (%) para o paciente código %',
        v_hct_seq, v_pac_codigo;
        EXCEPTION
        WHEN OTHERS THEN
          RAISE WARNING '02 - Erro ao inserir o horário de controle: % - %',
          SQLERRM, v_hct_seq;
      END;
    END IF;
    BEGIN
      IF v_sc_calculada IS NOT NULL THEN
        IF NOT EXISTS (
          SELECT 1 FROM agh.ecp_controle_pacientes
          WHERE hct_seq = v_hct_seq
          AND ice_seq = v_ice_seq_sc
        ) THEN
          INSERT INTO agh.ecp_controle_pacientes(
            seq, medicao, fora_limite_normal, criado_em,
            ser_matricula, ser_vin_codigo, ice_seq, hct_seq,
            version, umm_seq
          )
          VALUES(
            NEXTVAL('agh.ecp_rcp_sq1'), ROUND(v_sc_calculada::NUMERIC, 2), 'N', v_criado_em,
            v_ser_matricula, v_ser_vin_codigo, v_ice_seq_sc, v_hct_seq,
            v_version, v_umm_seq_sc
          );
          v_scs_inseridas := v_scs_inseridas + 1;
        ELSE
          RAISE WARNING '04 - Já existe item de controle para o horário de controle % (%) e item de controle % (Superfície Corpórea). Paciente: %',
            v_hct_seq, v_data_hora, v_ice_seq_sc, v_pac_codigo;
        END IF;
      END IF;
      IF v_altura IS NOT NULL THEN
        IF NOT EXISTS (
          SELECT 1 FROM agh.ecp_controle_pacientes
          WHERE hct_seq = v_hct_seq
          AND ice_seq = v_ice_seq_altura
        ) THEN
          INSERT INTO agh.ecp_controle_pacientes(
            seq, medicao, fora_limite_normal, criado_em,
            ser_matricula, ser_vin_codigo, ice_seq, hct_seq,
            version, umm_seq
          )
          VALUES(
            NEXTVAL('agh.ecp_rcp_sq1'), ROUND(v_altura::NUMERIC, 2), 'N', v_criado_em,
            v_ser_matricula, v_ser_vin_codigo, v_ice_seq_altura, v_hct_seq,
            v_version, v_umm_seq_altura
          );
          v_alturas_inseridas := v_alturas_inseridas + 1;
        ELSE
          RAISE WARNING '04 - Já existe item de controle para o horário de controle % (%) e item de controle % (Altura). Paciente: %',
            v_hct_seq, v_data_hora, v_ice_seq_altura, v_pac_codigo;
        END IF;
      END IF;
      IF v_peso IS NOT NULL THEN
        IF NOT EXISTS (
          SELECT 1 FROM agh.ecp_controle_pacientes
          WHERE hct_seq = v_hct_seq
          AND ice_seq = v_ice_seq_peso
        ) THEN
          INSERT INTO agh.ecp_controle_pacientes(
            seq, medicao, fora_limite_normal, criado_em,
            ser_matricula, ser_vin_codigo, ice_seq, hct_seq,
            version, umm_seq
          )
          VALUES(
            NEXTVAL('agh.ecp_rcp_sq1'), ROUND(v_peso::NUMERIC, 2), 'N', v_criado_em,
            v_ser_matricula, v_ser_vin_codigo, v_ice_seq_peso, v_hct_seq,
            v_version, v_umm_seq_peso
          );
          v_pesos_inseridos := v_pesos_inseridos + 1;
        ELSE
          RAISE WARNING '04 - Já existe item de controle para o horário de controle % (%) e item de controle % (Peso). Paciente: %',
            v_hct_seq, v_data_hora, v_ice_seq_peso, v_pac_codigo;
        END IF;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        RAISE WARNING '03 - Erro ao inserir item de controle: % - %',
          SQLERRM, v_pac_codigo;
    END;
  RAISE NOTICE '-----------------------------';
  END LOOP;
CLOSE cursor_medidas;
RAISE NOTICE 'Migração de altura, peso e superfície corpórea finalizada';
RAISE INFO 'Inseridos % pesos
Inseridas % alturas
Inseridas % superfícies corpóreas',
  v_pesos_inseridos, v_alturas_inseridas, v_scs_inseridas;
END
$$;
