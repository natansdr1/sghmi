DO
$$
BEGIN
        IF EXISTS(
                SELECT null
                FROM information_schema.check_constraints
                WHERE constraint_schema = 'agh'
                  AND constraint_name = 'mbc_puc_ck1'
            ) THEN
ALTER TABLE AGH.mbc_prof_atua_unid_cirgs DROP CONSTRAINT mbc_puc_ck1;
END IF;
ALTER TABLE agh.mbc_prof_atua_unid_cirgs
    ADD CONSTRAINT mbc_puc_ck1 CHECK (((ind_funcao_prof)::text = ANY
    (ARRAY [('MPF'::character varying)::text, ('ANP'::character varying)::text, ('ANR'::character varying)::text, ('ENF'::character varying)::text, ('INS'::character varying)::text, ('MAX'::character varying)::text, ('CIR'::character varying)::text, ('MCO'::character varying)::text, ('ANC'::character varying)::text, ('ESE'::character varying)::text, ('MRE'::character varying)::text, ('OPF'::character varying)::text, ('ORE'::character varying)::text, ('TEF'::character varying)::text, ('OCD'::character varying)::text, ('TSB'::character varying)::text, ('AXE'::character varying)::text])));

END
$$