DO $$
BEGIN
    --Insere novo código sus para procedimentos internos de prescrição de enfermagem nao faturados
    IF not exists(select 1 from agh.AGH_PARAMETROS p where p.nome = 'P_CAMPO_INFORMACOES_GERAIS') then
        INSERT INTO agh.AGH_PARAMETROS(seq,sis_sigla, nome, mantem_historico, criado_em,criado_por,vlr_texto,version,tipo_dado)
        VALUES(nextval('agh.AGH_PSI_SQ1'),'AGH', 'P_CAMPO_INFORMACOES_GERAIS', 'S','2023-07-18 12:46:24.004','AGHU','SOMOS UM HOSPITAL 100% SUS. Caso alguém cobre por qualquer atendimento, NÃO PAGUE e procure a Ouvidoria.',1,'T');
END IF;
END $$;
