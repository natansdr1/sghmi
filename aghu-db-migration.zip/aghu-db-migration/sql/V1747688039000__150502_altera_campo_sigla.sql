DO $$
DECLARE
  campos text[] := ARRAY[
'agh.ael_exames_jn.sigla.8',
'agh.ael_exames.sigla.8',
'agh.ael_exames_material_analise.exa_sigla.8',
'agh.ael_exames_mat_analise_jn.exa_sigla.8',
'agh.ael_unf_executa_exames.ema_exa_sigla.8',
'agh.ael_tipos_amostra_exames.ema_exa_sigla.8',
'agh.ael_tipos_amostra_exames_jn.ema_exa_sigla.8',
'agh.ael_item_solicitacao_exames.ufe_ema_exa_sigla.8',
'agh.ael_parametro_campos_laudo.vel_ema_exa_sigla.8',
'agh.ael_versao_laudos.ema_exa_sigla.8',
'agh.ael_resultados_exames.pcl_vel_ema_exa_sigla.8',
'agh.ael_exames_equipamentos.eem_ema_exa_sigla.8',
'agh.ael_exames_equipamentos_jn.eem_ema_exa_sigla.8',
'agh.ael_lote_exames.ema_exa_sigla.8',
'agh.ael_sinonimos_exames.exa_sigla.8',
'agh.ael_exames_dependentes.ema_exa_sigla.8',
'agh.ael_exames_dependentes.ema_exa_sigla_eh_dependente.8',
'agh.ael_exames_dependentes_jn.ema_exa_sigla.8',
'agh.ael_exames_dependentes_jn.ema_exa_sigla_eh_dependente.8',
'agh.ael_ord_exame_mat_analises.ema_exa_sigla.8',
'agh.ael_descricoes_resultado.ree_pcl_vel_ema_exa_sigla.8',
'hist.ael_descricoes_resultado.ree_pcl_vel_ema_exa_sigla.8',
'agh.fat_proced_hosp_internos.ema_exa_sigla.8',
'agh.fat_proced_hosp_internos_jn.ema_exa_sigla.8',
'agh.ael_intervalo_coletas.ema_exa_sigla.8',
'agh.ael_etapas_exame.exa_sigla.8',
'agh.mpa_pop_exames.exa_sigla.8',
'agh.ael_fonemas_exame.exa_sigla.8',
'agh.mtx_exame_ult_results.sigla.8',
'agh.pdt_proc_diag_teraps.exa_sigla.8',
'agh.pdt_proc_diag_teraps_jn.exa_sigla.8',
'agh.ael_exame_conselho_profs.ema_exa_sigla.8',
'agh.ael_copia_resultados.ema_exa_sigla.8',
'agh.ael_exames_especialidade.ufe_ema_exa_sigla.8',
'agh.ael_exames_especialidade_jn.ufe_ema_exa_sigla.8',
'agh.ael_permissao_unid_solics.ufe_ema_exa_sigla.8',
'agh.ael_permissao_unid_solics_jn.ufe_ema_exa_sigla.8',
'agh.ael_servidores_exame_unid.ufe_ema_exa_sigla.8',
'agh.ael_metodo_unf_exames.ufe_ema_exa_sigla.8',
'agh.ael_metodo_unf_exames_jn.ufe_ema_exa_sigla.8',
'agh.ael_exames_questionario.ema_exa_sigla.8',
'agh.ael_exames_questionario_jn.ema_exa_sigla.8',
'agh.ael_exame_horario_coletas.ema_exa_sigla.8',
'agh.ael_exame_horario_coletas_jn.ema_exa_sigla.8',
'agh.ael_exame_dept_convenios.exd_ema_exa_sigla.8',
'agh.ael_exame_dept_convenios.exd_ema_exa_sigla_eh_dependent.8',
'agh.ael_exame_dept_convenios_jn.exd_ema_exa_sigla.8',
'agh.ael_exame_dept_convenios_jn.exd_ema_exa_sigla_eh_dependent.8',
'agh.ael_campos_codif_relacionados.pcl_vel_ema_exa_sigla.8',
'agh.ael_campos_codif_relacionados.pcl_vel_ema_exa_sigla_vinculad.8',
'agh.ael_campos_laudo_relacionados.pcl_vel_ema_exa_sigla.8',
'agh.ael_campos_laudo_relacionados.pcl_vel_ema_exa_sigla_pertence.8',
'agh.abs_exame_metodo_confirms.emm_ufe_ema_exa_sigla.8',
'agh.abs_exame_metodo_confirms.emm_ufe_ema_exa_sigla_filho.8',
'agh.abs_exame_metodo_confirms_jn.emm_ufe_ema_exa_sigla.8',
'agh.abs_exame_metodo_confirms_jn.emm_ufe_ema_exa_sigla_filho.8',
'agh.ael_campos_uso_faturamento.ema_exa_sigla.8',
'agh.ael_campos_vinculados.pcl_vel_ema_exa_sigla.8',
'agh.ael_campos_vinculados.pcl_vel_ema_exa_sigla_vinculad.8',
'agh.ael_config_mapa_exames.ufe_ema_exa_sigla.8',
'agh.ael_config_mapa_exames_jn.ufe_ema_exa_sigla.8',
'agh.ael_unf_executa_exames_jn.ema_exa_sigla.8',
'agh.ael_exame_equip_campos_laud.pcl_vel_ema_exa_sigla.8',
'agh.ael_exame_equip_campos_laud.eeq_eem_ema_exa_sigla.8',
'agh.ael_exame_equip_campos_laud_jn.pcl_vel_ema_exa_sigla.8',
'agh.ael_exame_equip_campos_laud_jn.eeq_eem_ema_exa_sigla.8',
'agh.abs_conclusao_exames.emm_ufe_ema_exa_sigla.8',
'agh.abs_conclusao_exames_jn.emm_ufe_ema_exa_sigla.8',
'agh.ael_exames_limitado_atend.ema_exa_sigla.8',
'agh.ael_exames_limitado_atend_jn.ema_exa_sigla.8',
'agh.ael_exames_notificacao.ema_exa_sigla.8',
'agh.ael_exames_notificacao_jn.ema_exa_sigla.8',
'agh.ael_exames_resu_notificacao.exn_ema_exa_sigla.8',
'agh.ael_exames_resu_notificacao_jn.exn_ema_exa_sigla.8',
'agh.ael_exame_fora_aghs.ema_exa_sigla.8',
'agh.ael_exames_prova.ema_exa_sigla.8',
'agh.ael_exames_prova.ema_exa_sigla_eh_prova.8',
'agh.ael_exames_prova_jn.ema_exa_sigla.8',
'agh.ael_exames_prova_jn.ema_exa_sigla_eh_prova.8',
'agh.ael_exec_exames_mat_analise.ema_exa_sigla.8',
'agh.ael_exec_exames_mat_analise_jn.ema_exa_sigla.8',
'agh.ael_exigencia_exames.ufe_ema_exa_sigla.8',
'agh.ael_exigencia_exames_jn.ufe_ema_exa_sigla.8',
'agh.ael_grp_tecnica_unf_exames.ufe_ema_exa_sigla.8',
'agh.ael_grp_tecnica_unf_exames_jn.ufe_ema_exa_sigla.8',
'agh.ael_grupo_exame_priorizas.grx_ema_exa_sigla.8',
'agh.ael_grupo_exame_priorizas.ema_exa_sigla.8',
'agh.ael_grupo_exame_priorizas_jn.grx_ema_exa_sigla.8',
'agh.ael_grupo_exame_priorizas_jn.ema_exa_sigla.8',
'agh.ael_grupo_exame_unid_exames.ufe_ema_exa_sigla.8',
'agh.ael_grupo_recomendacao_exames.ema_exa_sigla.8',
'agh.ael_grupo_recomendacao_exam_jn.ema_exa_sigla.8',
'agh.ael_grp_tecnica_campos.tce_ufe_ema_exa_sigla.8',
'agh.ael_grp_tecnica_campos_jn.tce_ufe_ema_exa_sigla.8',
'agh.ael_ig_exames_monitorados.exa_sigla.8',
'agh.ael_intervalo_coletas_jn.ema_exa_sigla.8',
'agh.ael_item_config_exames.ufe_ema_exa_sigla.8',
'agh.ael_item_config_exames_jn.ufe_ema_exa_sigla.8',
'agh.ael_exame_reflexos.ema_exa_sigla.8',
'agh.ael_exame_reflexos.ema_exa_sigla_reflexo.8',
'agh.ael_exame_reflexos_jn.ema_exa_sigla.8',
'agh.ael_exame_reflexos_jn.ema_exa_sigla_reflexo.8',
'agh.ael_pol_sum_exames_masc.ufe_ema_exa_sigla.8',
'agh.ael_pol_sum_exames_tab.ufe_ema_exa_sigla.8',
'agh.ael_projeto_exames.ema_exa_sigla.8',
'agh.ael_projeto_exames_jn.ema_exa_sigla.8',
'agh.ael_recomendacoes_exame.ema_exa_sigla.8',
'agh.abs_exame_metodos.ufe_ema_exa_sigla.8',
'agh.abs_exame_metodos.sigla_exame.8',
'agh.abs_exame_metodos_jn.ufe_ema_exa_sigla.8',
'agh.abs_exame_metodos_jn.sigla_exame.8',
'agh.ael_itens_pedidos_exames.ufe_ema_exa_sigla.8',
'agh.ael_respostas_questoes.eqe_ema_exa_sigla.8',
'agh.ael_respostas_questoes_jn.eqe_ema_exa_sigla.8',
'hist.ael_respostas_questoes.eqe_ema_exa_sigla.8',
'agh.ael_sumamb_exames_masc.ufe_ema_exa_sigla.8',
'agh.ael_sumamb_exames_tab.ufe_ema_exa_sigla.8',
'agh.ael_projeto_interc_exames.ema_exa_sigla.8',
'agh.ael_projeto_interc_exames_jn.ema_exa_sigla.8',
'agh.ael_tipos_amo_exame_conv.tae_ema_exa_sigla.8',
'agh.ael_tipos_amo_exame_conv_jn.tae_ema_exa_sigla.8',
'agh.ael_tmp_bull_int.exa_sigla.8',
'agh.ael_unid_exame_significativos.ema_exa_sigla.8',
'agh.epe_presc_cuid_exames.cex_ema_exa_sigla.8',
'agh.ael_sumario_exames_masc.ufe_ema_exa_sigla.8',
'agh.mam_pc_sum_exames_masc.ufe_ema_exa_sigla.8',
'agh.ael_sumario_exames_tab.ufe_ema_exa_sigla.8',
'agh.mam_pc_sum_exames_tab.ufe_ema_exa_sigla.8',
'agh.mco_resultado_exame_signifs.ema_exa_sigla.8',
'agh.mco_resultado_exame_signifs_jn.ema_exa_sigla.8',
'agh.mpa_cad_ord_item_exames.ufe_ema_exa_sigla.8',
'agh.mpm_alta_item_pedido_exames.ufe_ema_exa_sigla.8',
'agh.ael_ex_questionario_origens.eqe_ema_exa_sigla.8'
  ];
  
  max_recursion_depth int := 15;
  timeout_threshold interval := '2 minutes';
  batch_size int := 10;
  
  item text;
  partes text[];
  p_schema text;
  p_table text;
  p_column text;
  p_newlen int;
  colinfo record;
  rec_view record;
  rec_alt record;
  rec_fun record;
  rec_trig record;
  rec_const record;
  row_count int := 0;
  processed_count int := 0;
  start_time timestamp;
  step_time timestamp;
  global_start_time timestamp;
  i int;
  current_level int;
  has_changes boolean;
BEGIN
  SET client_min_messages TO DEBUG;
  SET work_mem = '64MB';  
  SET maintenance_work_mem = '256MB';
  global_start_time := clock_timestamp();
  RAISE NOTICE '==================================================================';
  RAISE NOTICE 'INÍCIO DO PROCESSO: %', global_start_time;
  RAISE NOTICE 'Configurações:';
  RAISE NOTICE '  - Profundidade máxima: % níveis', max_recursion_depth;
  RAISE NOTICE '  - Timeout total: %', timeout_threshold;
  RAISE NOTICE '  - Tamanho do lote: % itens', batch_size;
  RAISE NOTICE '==================================================================';

  start_time := clock_timestamp();
  
  CREATE TEMP TABLE tmp_to_alter (
    schema_name text,
    table_name text,
    column_name text,
    new_len int
  );
  
  CREATE INDEX tmp_to_alter_idx ON tmp_to_alter (schema_name, table_name, column_name);
  RAISE NOTICE 'Tabela tmp_to_alter criada com índice';

  CREATE TEMP TABLE tmp_views (
    view_schema text,
    view_name text,
    view_level int,
    view_sql text,
    view_owner text,
    grant_stmts text[]
  );
  
  CREATE INDEX tmp_views_idx ON tmp_views (view_schema, view_name);
  CREATE INDEX tmp_views_level_idx ON tmp_views (view_level);
  RAISE NOTICE 'Tabela tmp_views criada com índices';

  CREATE TEMP TABLE tmp_funcs (
    func_schema text,
    func_name text,
    func_signature text,
    func_oid oid,
    func_sql text,
    func_owner text,
    func_language text,
    func_volatility char,
    func_returns text,
    func_security char,
    grant_stmts text[],
    dependency_level int DEFAULT 1
  );
  
  CREATE INDEX tmp_funcs_idx ON tmp_funcs (func_schema, func_name, func_signature);
  CREATE INDEX tmp_funcs_oid_idx ON tmp_funcs (func_oid);
  RAISE NOTICE 'Tabela tmp_funcs criada com índice';

  CREATE TEMP TABLE tmp_triggers (
    trig_schema text,
    trig_table text,
    trig_name text,
    trig_oid oid,
    trig_sql text,
    trig_owner text,
    trig_enabled char,
    trig_timing char,
    trig_events text,
    trig_orientation char,
    trig_when_clause text,
    trig_function_schema text,
    trig_function_name text,
    is_constraint boolean DEFAULT false,
    is_deferrable boolean DEFAULT false,
    is_deferred boolean DEFAULT false,
    constraint_name text,
    should_skip boolean DEFAULT false
  );
  
  CREATE INDEX tmp_triggers_idx ON tmp_triggers (trig_schema, trig_table, trig_name);
  CREATE INDEX tmp_triggers_oid_idx ON tmp_triggers (trig_oid);
  RAISE NOTICE 'Tabela tmp_triggers criada com índice';

  CREATE TEMP TABLE tmp_constraints (
    const_schema text,
    const_table text,
    const_name text,
    const_type char,
    const_sql text,
    const_owner text,
    fk_schema text,
    fk_table text,
    is_deferrable boolean,
    is_deferred boolean,
    match_type char,
    update_action char,
    delete_action char,
    check_clause text,
    columns text[],
    ref_columns text[]
  );
  
  CREATE INDEX tmp_constraints_idx ON tmp_constraints (const_schema, const_table, const_name);
  RAISE NOTICE 'Tabela tmp_constraints criada com índice';

  step_time := clock_timestamp();
  RAISE NOTICE 'Tempo de criação: %', (step_time - start_time);
  RAISE NOTICE '--------------------------------------------------';

  start_time := clock_timestamp();
  RAISE NOTICE 'Processando % colunas para alteração', array_length(campos, 1);

  FOR i IN 1..array_length(campos, 1) LOOP
    IF clock_timestamp() - global_start_time > timeout_threshold THEN
      RAISE NOTICE 'TIMEOUT: Tempo máximo de execução atingido durante validação';
      EXIT;
    END IF;
    
    item := campos[i];
    partes := string_to_array(item, '.');
    
    IF array_length(partes, 1) != 4 THEN
      RAISE NOTICE 'Formato inválido para item: %', item;
      CONTINUE;
    END IF;
    
    p_schema := partes[1]; 
    p_table := partes[2]; 
    p_column := partes[3]; 
    
    BEGIN
      p_newlen := partes[4]::int;
    EXCEPTION WHEN OTHERS THEN
      RAISE NOTICE 'Tamanho inválido para %.%.%: %', p_schema, p_table, p_column, partes[4];
      CONTINUE;
    END;

    BEGIN
      SELECT 
        t.typname, 
        CASE 
          WHEN a.atttypmod > 0 THEN a.atttypmod - 4 
          ELSE NULL 
        END AS curr_len 
      INTO colinfo
      FROM pg_class c 
      JOIN pg_namespace n ON n.oid = c.relnamespace
      JOIN pg_attribute a ON a.attrelid = c.oid AND a.attnum > 0 AND NOT a.attisdropped
      JOIN pg_type t ON t.oid = a.atttypid
      WHERE n.nspname = p_schema 
        AND c.relname = p_table 
        AND a.attname = p_column
        AND c.relkind IN ('r','p');

      IF NOT FOUND THEN
        RAISE NOTICE 'Coluna %.%.% não encontrada', p_schema, p_table, p_column;
        CONTINUE;
      END IF;

      IF colinfo.typname NOT IN ('varchar','character varying','bpchar') THEN
        RAISE NOTICE 'Coluna %.%.% não é varchar/char (tipo: %)', p_schema, p_table, p_column, colinfo.typname;
        CONTINUE;
      END IF;
      
      IF colinfo.curr_len IS NOT NULL AND colinfo.curr_len >= p_newlen THEN
        RAISE NOTICE 'Coluna %.%.% já tem tamanho % (novo: %)', p_schema, p_table, p_column, colinfo.curr_len, p_newlen;
        CONTINUE;
      END IF;

      IF NOT EXISTS (
        SELECT 1 FROM tmp_to_alter 
        WHERE schema_name = p_schema AND table_name = p_table AND column_name = p_column
      ) THEN
        INSERT INTO tmp_to_alter VALUES (p_schema, p_table, p_column, p_newlen);
        processed_count := processed_count + 1;
        RAISE NOTICE 'Agendada alteração de %.%.% de % para %', 
                     p_schema, p_table, p_column, COALESCE(colinfo.curr_len::text, 'unlimited'), p_newlen;
      END IF;
      
    EXCEPTION WHEN OTHERS THEN
      RAISE NOTICE 'Erro ao processar %.%.%: %', p_schema, p_table, p_column, SQLERRM;
    END;
  END LOOP;

  step_time := clock_timestamp();
  RAISE NOTICE 'Colunas processadas: %/%', processed_count, array_length(campos, 1);
  RAISE NOTICE 'Tempo de processamento: %', (step_time - start_time);
  RAISE NOTICE '--------------------------------------------------';

  start_time := clock_timestamp();
  RAISE NOTICE 'Iniciando mapeamento de constraints...';

  FOR rec_alt IN SELECT * FROM tmp_to_alter LOOP
    IF clock_timestamp() - global_start_time > timeout_threshold THEN
      RAISE NOTICE 'TIMEOUT: Tempo máximo de execução atingido durante mapeamento';
      EXIT;
    END IF;

    RAISE NOTICE 'Mapeando constraints para %.%.%', 
                 rec_alt.schema_name, rec_alt.table_name, rec_alt.column_name;


    INSERT INTO tmp_constraints (
      const_schema, const_table, const_name, const_type, 
      fk_schema, fk_table, is_deferrable, is_deferred,
      match_type, update_action, delete_action, check_clause,
      columns, ref_columns
    )
    SELECT DISTINCT
      ns.nspname,
      c.relname,
      con.conname,
      con.contype,
      fns.nspname,
      fc.relname,
      con.condeferrable,
      con.condeferred,
      con.confmatchtype,
      con.confupdtype,
      con.confdeltype,
      pg_get_constraintdef(con.oid),
      ARRAY(
        SELECT a.attname 
        FROM pg_attribute a, generate_subscripts(con.conkey, 1) AS col_idx
        WHERE a.attrelid = con.conrelid 
          AND a.attnum = con.conkey[col_idx] 
        ORDER BY col_idx
      ),
      ARRAY(
        SELECT a.attname 
        FROM pg_attribute a, generate_subscripts(con.confkey, 1) AS ref_idx
        WHERE a.attrelid = con.confrelid 
          AND a.attnum = con.confkey[ref_idx] 
        ORDER BY ref_idx
      )
    FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace ns ON ns.oid = c.relnamespace
    LEFT JOIN pg_class fc ON fc.oid = con.confrelid
    LEFT JOIN pg_namespace fns ON fns.oid = fc.relnamespace
    WHERE ns.nspname = rec_alt.schema_name
      AND c.relname = rec_alt.table_name
      AND (
        EXISTS (
          SELECT 1 FROM pg_attribute a 
          WHERE a.attrelid = con.conrelid 
            AND a.attname = rec_alt.column_name
            AND a.attnum = ANY(con.conkey)
        )
        OR
        EXISTS (
          SELECT 1 FROM pg_attribute a 
          WHERE a.attrelid = con.confrelid 
            AND a.attname = rec_alt.column_name
            AND a.attnum = ANY(con.confkey)
        )
      )
      AND con.contype IN ('p', 'f', 'u', 'c')  
      AND NOT EXISTS (
        SELECT 1 FROM tmp_constraints 
        WHERE const_schema = ns.nspname 
          AND const_table = c.relname 
          AND const_name = con.conname
      );

    GET DIAGNOSTICS row_count = ROW_COUNT;
    IF row_count > 0 THEN
      RAISE NOTICE 'Encontradas % constraints envolvendo a coluna', row_count;
    END IF;

    INSERT INTO tmp_constraints (
      const_schema, const_table, const_name, const_type, 
      fk_schema, fk_table, is_deferrable, is_deferred,
      match_type, update_action, delete_action, check_clause,
      columns, ref_columns
    )
    SELECT DISTINCT
      ns.nspname,
      c.relname,
      con.conname,
      con.contype,
      fns.nspname,
      fc.relname,
      con.condeferrable,
      con.condeferred,
      con.confmatchtype,
      con.confupdtype,
      con.confdeltype,
      pg_get_constraintdef(con.oid),
      ARRAY(
        SELECT a.attname 
        FROM pg_attribute a, generate_subscripts(con.conkey, 1) AS col_idx
        WHERE a.attrelid = con.conrelid 
          AND a.attnum = con.conkey[col_idx] 
        ORDER BY col_idx
      ),
      ARRAY(
        SELECT a.attname 
        FROM pg_attribute a, generate_subscripts(con.confkey, 1) AS ref_idx
        WHERE a.attrelid = con.confrelid 
          AND a.attnum = con.confkey[ref_idx] 
        ORDER BY ref_idx
      )
    FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace ns ON ns.oid = c.relnamespace
    JOIN pg_class fc ON fc.oid = con.confrelid
    JOIN pg_namespace fns ON fns.oid = fc.relnamespace
    WHERE fns.nspname = rec_alt.schema_name
      AND fc.relname = rec_alt.table_name
      AND con.contype = 'f'  
      AND EXISTS (
        SELECT 1 FROM pg_attribute a 
        WHERE a.attrelid = con.confrelid 
          AND a.attname = rec_alt.column_name
          AND a.attnum = ANY(con.confkey)
      )
      AND NOT EXISTS (
        SELECT 1 FROM tmp_constraints 
        WHERE const_schema = ns.nspname 
          AND const_table = c.relname 
          AND const_name = con.conname
      );

    GET DIAGNOSTICS row_count = ROW_COUNT;
    IF row_count > 0 THEN
      RAISE NOTICE 'Encontradas % FKs que referenciam a tabela', row_count;
    END IF;
  END LOOP;

  step_time := clock_timestamp();
  RAISE NOTICE 'Total de constraints mapeadas: %', (SELECT count(*) FROM tmp_constraints);
  RAISE NOTICE 'Tempo de mapeamento constraints: %', (step_time - start_time);
  RAISE NOTICE '--------------------------------------------------';

  start_time := clock_timestamp();
  RAISE NOTICE 'Coletando metadados das constraints...';

  FOR rec_const IN SELECT * FROM tmp_constraints WHERE const_sql IS NULL LOOP
    IF clock_timestamp() - global_start_time > timeout_threshold THEN
      RAISE NOTICE 'TIMEOUT: Tempo máximo de execução atingido durante coleta';
      EXIT;
    END IF;

    BEGIN

      SELECT 
        pg_get_constraintdef(con.oid),
        pg_get_userbyid(c.relowner)
      INTO rec_const.const_sql, rec_const.const_owner
      FROM pg_constraint con
      JOIN pg_class c ON c.oid = con.conrelid
      JOIN pg_namespace ns ON ns.oid = c.relnamespace
      WHERE ns.nspname = rec_const.const_schema
        AND c.relname = rec_const.const_table
        AND con.conname = rec_const.const_name;

      IF FOUND THEN
        UPDATE tmp_constraints 
        SET const_sql = rec_const.const_sql,
            const_owner = rec_const.const_owner
        WHERE const_schema = rec_const.const_schema 
          AND const_table = rec_const.const_table 
          AND const_name = rec_const.const_name;
          
        RAISE NOTICE 'Coletados metadados da constraint %.%.% (tipo: %)', 
                     rec_const.const_schema, rec_const.const_table, 
                     rec_const.const_name, rec_const.const_type;
      END IF;
      
    EXCEPTION WHEN OTHERS THEN
      RAISE NOTICE 'Erro ao coletar metadados da constraint %.%.%: %', 
                  rec_const.const_schema, rec_const.const_table, rec_const.const_name, SQLERRM;
    END;
  END LOOP;

  step_time := clock_timestamp();
  RAISE NOTICE 'Metadados de constraints coletados: %/% constraints', 
               (SELECT count(*) FROM tmp_constraints WHERE const_sql IS NOT NULL),
               (SELECT count(*) FROM tmp_constraints);
  RAISE NOTICE 'Tempo de coleta constraints: %', (step_time - start_time);
  RAISE NOTICE '--------------------------------------------------';

  start_time := clock_timestamp();
  RAISE NOTICE 'Iniciando mapeamento de views dependentes...';


  FOR rec_alt IN SELECT * FROM tmp_to_alter LOOP
    IF clock_timestamp() - global_start_time > timeout_threshold THEN
      RAISE NOTICE 'TIMEOUT: Tempo máximo de execução atingido durante mapeamento';
      EXIT;
    END IF;

    INSERT INTO tmp_views (view_schema, view_name, view_level)
    SELECT DISTINCT
      vs.nspname AS view_schema,
      v.relname AS view_name,
      1 AS view_level
    FROM pg_class t
    JOIN pg_namespace ts ON ts.oid = t.relnamespace
    JOIN pg_depend d ON d.refobjid = t.oid
    JOIN pg_rewrite r ON r.oid = d.objid
    JOIN pg_class v ON v.oid = r.ev_class AND v.relkind = 'v'
    JOIN pg_namespace vs ON vs.oid = v.relnamespace
    WHERE ts.nspname = rec_alt.schema_name
      AND t.relname = rec_alt.table_name
      AND NOT EXISTS (
        SELECT 1 FROM tmp_views 
        WHERE view_schema = vs.nspname AND view_name = v.relname
      );

    GET DIAGNOSTICS row_count = ROW_COUNT;
    IF row_count > 0 THEN
      RAISE NOTICE 'Encontradas % views dependentes da tabela %.%', 
                   row_count, rec_alt.schema_name, rec_alt.table_name;
    END IF;
  END LOOP;


  current_level := 1;
  has_changes := true;
  
  WHILE has_changes AND current_level < max_recursion_depth LOOP
    has_changes := false;
    current_level := current_level + 1;
    
    IF clock_timestamp() - global_start_time > timeout_threshold THEN
      RAISE NOTICE 'TIMEOUT: Tempo máximo de execução atingido durante mapeamento hierárquico';
      EXIT;
    END IF;
    

    INSERT INTO tmp_views (view_schema, view_name, view_level)
    SELECT DISTINCT
      dep_vs.nspname AS view_schema,
      dep_v.relname AS view_name,
      current_level AS view_level
    FROM tmp_views base_views
    JOIN pg_class base_v ON base_v.relname = base_views.view_name
    JOIN pg_namespace base_vs ON base_vs.oid = base_v.relnamespace 
      AND base_vs.nspname = base_views.view_schema
    JOIN pg_depend d ON d.refobjid = base_v.oid
    JOIN pg_rewrite r ON r.oid = d.objid
    JOIN pg_class dep_v ON dep_v.oid = r.ev_class AND dep_v.relkind = 'v'
    JOIN pg_namespace dep_vs ON dep_vs.oid = dep_v.relnamespace
    WHERE base_views.view_level = current_level - 1
      AND base_v.relkind = 'v'
      AND NOT EXISTS (
        SELECT 1 FROM tmp_views 
        WHERE view_schema = dep_vs.nspname AND view_name = dep_v.relname
      );

    GET DIAGNOSTICS row_count = ROW_COUNT;
    IF row_count > 0 THEN
      has_changes := true;
      RAISE NOTICE 'Nível %: encontradas % views dependentes', current_level, row_count;
    END IF;
  END LOOP;

  step_time := clock_timestamp();
  RAISE NOTICE 'Total de views mapeadas: % (níveis: 1 a %)', 
               (SELECT count(*) FROM tmp_views), 
               (SELECT COALESCE(max(view_level), 0) FROM tmp_views);
  RAISE NOTICE 'Tempo de mapeamento views: %', (step_time - start_time);
  RAISE NOTICE '--------------------------------------------------';

  start_time := clock_timestamp();
  RAISE NOTICE 'Iniciando mapeamento de funções dependentes...';

  FOR rec_alt IN SELECT * FROM tmp_to_alter LOOP
    IF clock_timestamp() - global_start_time > timeout_threshold THEN
      RAISE NOTICE 'TIMEOUT: Tempo máximo de execução atingido';
      EXIT;
    END IF;

    INSERT INTO tmp_funcs (func_schema, func_name, func_signature, func_oid, dependency_level)
    SELECT DISTINCT
      ns.nspname,
      p.proname,
      pg_get_function_identity_arguments(p.oid),
      p.oid,
      1
    FROM pg_class t
    JOIN pg_namespace ts ON ts.oid = t.relnamespace
    JOIN pg_depend d ON d.refobjid = t.oid
    JOIN pg_proc p ON p.oid = d.objid
    JOIN pg_namespace ns ON ns.oid = p.pronamespace
    WHERE ts.nspname = rec_alt.schema_name
      AND t.relname = rec_alt.table_name
      AND d.deptype = 'n'
      AND NOT EXISTS (
        SELECT 1 FROM tmp_funcs 
        WHERE func_oid = p.oid
      );

    GET DIAGNOSTICS row_count = ROW_COUNT;
    IF row_count > 0 THEN
      RAISE NOTICE 'Encontradas % funções dependentes da tabela %.%', 
                   row_count, rec_alt.schema_name, rec_alt.table_name;
    END IF;
  END LOOP;

  FOR rec_view IN SELECT * FROM tmp_views ORDER BY view_level LOOP
    IF clock_timestamp() - global_start_time > timeout_threshold THEN
      RAISE NOTICE 'TIMEOUT: Tempo máximo de execução atingido';
      EXIT;
    END IF;

    INSERT INTO tmp_funcs (func_schema, func_name, func_signature, func_oid, dependency_level)
    SELECT DISTINCT
      ns.nspname,
      p.proname,
      pg_get_function_identity_arguments(p.oid),
      p.oid,
      rec_view.view_level + 1
    FROM pg_class v
    JOIN pg_namespace vs ON vs.oid = v.relnamespace
    JOIN pg_depend d ON d.refobjid = v.oid
    JOIN pg_proc p ON p.oid = d.objid
    JOIN pg_namespace ns ON ns.oid = p.pronamespace
    WHERE vs.nspname = rec_view.view_schema
      AND v.relname = rec_view.view_name
      AND v.relkind = 'v'
      AND d.deptype = 'n'
      AND NOT EXISTS (
        SELECT 1 FROM tmp_funcs 
        WHERE func_oid = p.oid
      );

    GET DIAGNOSTICS row_count = ROW_COUNT;
    IF row_count > 0 THEN
      RAISE NOTICE 'Encontradas % funções dependentes da view %.% (nível %)', 
                   row_count, rec_view.view_schema, rec_view.view_name, rec_view.view_level;
    END IF;
  END LOOP;

  step_time := clock_timestamp();
  RAISE NOTICE 'Total de funções mapeadas: %', (SELECT count(*) FROM tmp_funcs);
  RAISE NOTICE 'Tempo de mapeamento funções: %', (step_time - start_time);
  RAISE NOTICE '--------------------------------------------------';

  start_time := clock_timestamp();
  RAISE NOTICE 'Iniciando mapeamento de triggers de usuário...';

  FOR rec_alt IN SELECT * FROM tmp_to_alter LOOP
    IF clock_timestamp() - global_start_time > timeout_threshold THEN
      RAISE NOTICE 'TIMEOUT: Tempo máximo de execução atingido';
      EXIT;
    END IF;

    INSERT INTO tmp_triggers (
      trig_schema, trig_table, trig_name, trig_oid, 
      trig_enabled, trig_timing, trig_events, trig_orientation,
      is_constraint, is_deferrable, is_deferred, constraint_name,
      should_skip
    )
    SELECT DISTINCT
      ns.nspname,
      c.relname,
      t.tgname,
      t.oid,
      t.tgenabled,
      CASE t.tgtype & 66
        WHEN 2 THEN 'BEFORE'::char
        WHEN 64 THEN 'INSTEAD OF'::char
        ELSE 'AFTER'::char
      END,
      array_to_string(
        ARRAY(
          SELECT unnest(
            CASE 
              WHEN t.tgtype & 4 <> 0 THEN ARRAY['INSERT']
              ELSE ARRAY[]::text[]
            END ||
            CASE 
              WHEN t.tgtype & 8 <> 0 THEN ARRAY['DELETE'] 
              ELSE ARRAY[]::text[]
            END ||
            CASE 
              WHEN t.tgtype & 16 <> 0 THEN ARRAY['UPDATE'] 
              ELSE ARRAY[]::text[]
            END ||
            CASE 
              WHEN t.tgtype & 32 <> 0 THEN ARRAY['TRUNCATE'] 
              ELSE ARRAY[]::text[]
            END
          )
        ), 
        ' OR '
      ),
      CASE t.tgtype & 1
        WHEN 1 THEN 'ROW'::char
        ELSE 'STATEMENT'::char
      END,
      t.tgisinternal,
      t.tgdeferrable,
      t.tginitdeferred,
      con.conname,
      CASE 
        WHEN t.tgname LIKE 'RI_ConstraintTrigger_%' THEN true
        WHEN t.tgisinternal THEN true
        ELSE false
      END
    FROM pg_class c
    JOIN pg_namespace ns ON ns.oid = c.relnamespace
    JOIN pg_trigger t ON t.tgrelid = c.oid
    LEFT JOIN pg_constraint con ON con.oid = t.tgconstraint
    WHERE ns.nspname = rec_alt.schema_name
      AND c.relname = rec_alt.table_name
      AND NOT t.tgisinternal 
      AND t.tgname NOT LIKE 'RI_ConstraintTrigger_%' 
      AND NOT EXISTS (
        SELECT 1 FROM tmp_triggers 
        WHERE trig_oid = t.oid
      );

    GET DIAGNOSTICS row_count = ROW_COUNT;
    IF row_count > 0 THEN
      RAISE NOTICE 'Encontrados % triggers de usuário na tabela %.%', 
                   row_count, rec_alt.schema_name, rec_alt.table_name;
    END IF;
  END LOOP;

  step_time := clock_timestamp();
  RAISE NOTICE 'Total de triggers de usuário mapeados: %', 
               (SELECT count(*) FROM tmp_triggers WHERE should_skip = false);
  RAISE NOTICE 'Tempo de mapeamento triggers: %', (step_time - start_time);
  RAISE NOTICE '--------------------------------------------------';

  start_time := clock_timestamp();
  RAISE NOTICE 'Coletando metadados das views...';

  FOR rec_view IN SELECT * FROM tmp_views WHERE view_sql IS NULL ORDER BY view_level LOOP
    IF clock_timestamp() - global_start_time > timeout_threshold THEN
      RAISE NOTICE 'TIMEOUT: Tempo máximo de execução atingido durante coleta';
      EXIT;
    END IF;

    BEGIN
      SELECT 
        pg_get_viewdef(c.oid),
        pg_get_userbyid(c.relowner)
      INTO rec_view.view_sql, rec_view.view_owner
      FROM pg_class c
      JOIN pg_namespace n ON n.oid = c.relnamespace
      WHERE n.nspname = rec_view.view_schema 
        AND c.relname = rec_view.view_name
        AND c.relkind = 'v';

      IF FOUND THEN

        SELECT ARRAY(
          SELECT format('GRANT %s ON %I.%I TO %I',
                       acl_data.privilege_type,
                       rec_view.view_schema,
                       rec_view.view_name,
                       CASE 
                         WHEN acl_data.grantee = 0 THEN 'public'
                         ELSE COALESCE(pg_get_userbyid(acl_data.grantee), 'public')
                       END)
          FROM (
            SELECT 
              (aclexplode(c2.relacl)).*
            FROM pg_class c2
            JOIN pg_namespace n2 ON n2.oid = c2.relnamespace
            WHERE n2.nspname = rec_view.view_schema 
              AND c2.relname = rec_view.view_name
              AND c2.relacl IS NOT NULL
          ) acl_data
          WHERE acl_data.privilege_type IS NOT NULL 
            AND (
              acl_data.grantee = 0 OR 
              pg_get_userbyid(acl_data.grantee) IS NOT NULL
            )
        ) INTO rec_view.grant_stmts;

        UPDATE tmp_views 
        SET view_sql = rec_view.view_sql,
            view_owner = rec_view.view_owner,
            grant_stmts = COALESCE(rec_view.grant_stmts, ARRAY[]::text[])
        WHERE view_schema = rec_view.view_schema 
          AND view_name = rec_view.view_name;
      END IF;
      
    EXCEPTION WHEN OTHERS THEN
      RAISE NOTICE 'Erro ao coletar metadados de %.%: %', 
                  rec_view.view_schema, rec_view.view_name, SQLERRM;
    END;
  END LOOP;

  step_time := clock_timestamp();
  RAISE NOTICE 'Metadados de views coletados: %/% views', 
               (SELECT count(*) FROM tmp_views WHERE view_sql IS NOT NULL),
               (SELECT count(*) FROM tmp_views);
  RAISE NOTICE 'Tempo de coleta views: %', (step_time - start_time);
  RAISE NOTICE '--------------------------------------------------';

  start_time := clock_timestamp();
  RAISE NOTICE 'Coletando metadados das funções...';

  FOR rec_fun IN SELECT * FROM tmp_funcs WHERE func_sql IS NULL ORDER BY dependency_level DESC LOOP
    IF clock_timestamp() - global_start_time > timeout_threshold THEN
      RAISE NOTICE 'TIMEOUT: Tempo máximo de execução atingido durante coleta';
      EXIT;
    END IF;

    BEGIN
      SELECT 
        pg_get_functiondef(p.oid),
        pg_get_userbyid(p.proowner),
        l.lanname,
        p.provolatile,
        pg_get_function_result(p.oid),
        CASE WHEN p.prosecdef THEN 'd' ELSE 'i' END
      INTO rec_fun.func_sql, rec_fun.func_owner, rec_fun.func_language,
           rec_fun.func_volatility, rec_fun.func_returns, rec_fun.func_security
      FROM pg_proc p
      JOIN pg_language l ON l.oid = p.prolang
      WHERE p.oid = rec_fun.func_oid;

      IF FOUND THEN

        SELECT ARRAY(
          SELECT format('GRANT %s ON FUNCTION %I.%I(%s) TO %I',
                       acl_data.privilege_type,
                       rec_fun.func_schema,
                       rec_fun.func_name,
                       rec_fun.func_signature,
                       CASE 
                         WHEN acl_data.grantee = 0 THEN 'public'
                         ELSE COALESCE(pg_get_userbyid(acl_data.grantee), 'public')
                       END)
          FROM (
            SELECT 
              (aclexplode(p2.proacl)).*
            FROM pg_proc p2
            WHERE p2.oid = rec_fun.func_oid
              AND p2.proacl IS NOT NULL
          ) acl_data
          WHERE acl_data.privilege_type IS NOT NULL 
            AND (
              acl_data.grantee = 0 OR 
              pg_get_userbyid(acl_data.grantee) IS NOT NULL
            )
        ) INTO rec_fun.grant_stmts;

        UPDATE tmp_funcs 
        SET func_sql = rec_fun.func_sql,
            func_owner = rec_fun.func_owner,
            func_language = rec_fun.func_language,
            func_volatility = rec_fun.func_volatility,
            func_returns = rec_fun.func_returns,
            func_security = rec_fun.func_security,
            grant_stmts = COALESCE(rec_fun.grant_stmts, ARRAY[]::text[])
        WHERE func_oid = rec_fun.func_oid;
      END IF;
      
    EXCEPTION WHEN OTHERS THEN
      RAISE NOTICE 'Erro ao coletar metadados de %.%(%s): %', 
                  rec_fun.func_schema, rec_fun.func_name, rec_fun.func_signature, SQLERRM;
    END;
  END LOOP;

  step_time := clock_timestamp();
  RAISE NOTICE 'Metadados de funções coletados: %/% funções', 
               (SELECT count(*) FROM tmp_funcs WHERE func_sql IS NOT NULL),
               (SELECT count(*) FROM tmp_funcs);
  RAISE NOTICE 'Tempo de coleta funções: %', (step_time - start_time);
  RAISE NOTICE '--------------------------------------------------';

  start_time := clock_timestamp();
  RAISE NOTICE 'Coletando metadados dos triggers...';

  FOR rec_trig IN SELECT * FROM tmp_triggers WHERE trig_sql IS NULL AND should_skip = false ORDER BY trig_schema, trig_table, trig_name LOOP
    IF clock_timestamp() - global_start_time > timeout_threshold THEN
      RAISE NOTICE 'TIMEOUT: Tempo máximo de execução atingido durante coleta';
      EXIT;
    END IF;

    BEGIN
      SELECT 
        pg_get_triggerdef(t.oid),
        pg_get_userbyid(c.relowner),
        COALESCE(pg_get_expr(t.tgqual, t.tgrelid), ''),
        pn.nspname,
        p.proname
      INTO rec_trig.trig_sql, rec_trig.trig_owner, rec_trig.trig_when_clause,
           rec_trig.trig_function_schema, rec_trig.trig_function_name
      FROM pg_trigger t
      JOIN pg_class c ON c.oid = t.tgrelid
      JOIN pg_proc p ON p.oid = t.tgfoid
      JOIN pg_namespace pn ON pn.oid = p.pronamespace
      WHERE t.oid = rec_trig.trig_oid;

      IF FOUND THEN
        UPDATE tmp_triggers 
        SET trig_sql = rec_trig.trig_sql,
            trig_owner = rec_trig.trig_owner,
            trig_when_clause = rec_trig.trig_when_clause,
            trig_function_schema = rec_trig.trig_function_schema,
            trig_function_name = rec_trig.trig_function_name
        WHERE trig_oid = rec_trig.trig_oid;
      END IF;
      
    EXCEPTION WHEN OTHERS THEN
      RAISE NOTICE 'Erro ao coletar metadados do trigger %.%.%: %', 
                  rec_trig.trig_schema, rec_trig.trig_table, rec_trig.trig_name, SQLERRM;
    END;
  END LOOP;

  step_time := clock_timestamp();
  RAISE NOTICE 'Metadados de triggers coletados: %/% triggers', 
               (SELECT count(*) FROM tmp_triggers WHERE trig_sql IS NOT NULL),
               (SELECT count(*) FROM tmp_triggers WHERE should_skip = false);
  RAISE NOTICE 'Tempo de coleta triggers: %', (step_time - start_time);
  RAISE NOTICE '--------------------------------------------------';

  start_time := clock_timestamp();
  RAISE NOTICE 'Iniciando remoção de constraints...';

  row_count := 0;

  FOR rec_const IN 
    SELECT const_schema, const_table, const_name, const_type
    FROM tmp_constraints 
    WHERE const_sql IS NOT NULL
    ORDER BY 
      CASE const_type 
        WHEN 'c' THEN 1  
        WHEN 'u' THEN 2  
        WHEN 'f' THEN 3  
        WHEN 'p' THEN 4  
        ELSE 5
      END,
      const_schema, const_table, const_name
  LOOP
    IF clock_timestamp() - global_start_time > timeout_threshold THEN
      RAISE NOTICE 'TIMEOUT: Tempo máximo de execução atingido durante remoção';
      EXIT;
    END IF;

    RAISE NOTICE 'Removendo constraint %.%.% (tipo: %)', 
                 rec_const.const_schema, rec_const.const_table, 
                 rec_const.const_name, rec_const.const_type;
    
    BEGIN
      EXECUTE format('ALTER TABLE %I.%I DROP CONSTRAINT IF EXISTS %I', 
                    rec_const.const_schema, rec_const.const_table, rec_const.const_name);
      row_count := row_count + 1;
    EXCEPTION WHEN OTHERS THEN
      RAISE NOTICE 'Erro ao remover constraint %.%.%: %', 
                  rec_const.const_schema, rec_const.const_table, rec_const.const_name, SQLERRM;
    END;
  END LOOP;

  step_time := clock_timestamp();
  RAISE NOTICE 'Constraints removidas: %', row_count;
  RAISE NOTICE 'Tempo de remoção constraints: %', (step_time - start_time);
  RAISE NOTICE '--------------------------------------------------';

  start_time := clock_timestamp();
  RAISE NOTICE 'Iniciando remoção de triggers de usuário...';

  row_count := 0;
  FOR rec_trig IN 
    SELECT trig_schema, trig_table, trig_name
    FROM tmp_triggers 
    WHERE should_skip = false
    ORDER BY trig_schema, trig_table, trig_name
  LOOP
    IF clock_timestamp() - global_start_time > timeout_threshold THEN
      RAISE NOTICE 'TIMEOUT: Tempo máximo de execução atingido durante remoção';
      EXIT;
    END IF;

    RAISE NOTICE 'Removendo trigger de usuário %.%.%', 
                 rec_trig.trig_schema, rec_trig.trig_table, rec_trig.trig_name;
    
    BEGIN
      EXECUTE format('DROP TRIGGER IF EXISTS %I ON %I.%I', 
                    rec_trig.trig_name, rec_trig.trig_schema, rec_trig.trig_table);
      row_count := row_count + 1;
    EXCEPTION WHEN OTHERS THEN
      RAISE NOTICE 'Erro ao remover trigger %.%.%: %', 
                  rec_trig.trig_schema, rec_trig.trig_table, rec_trig.trig_name, SQLERRM;
    END;
  END LOOP;

  step_time := clock_timestamp();
  RAISE NOTICE 'Triggers de usuário removidos: %', row_count;
  RAISE NOTICE 'Tempo de remoção triggers: %', (step_time - start_time);
  RAISE NOTICE '--------------------------------------------------';

  start_time := clock_timestamp();
  RAISE NOTICE 'Iniciando remoção de funções...';

  row_count := 0;
  FOR rec_fun IN 
    SELECT func_schema, func_name, func_signature, dependency_level 
    FROM tmp_funcs 
    ORDER BY dependency_level DESC, func_schema, func_name
  LOOP
    IF clock_timestamp() - global_start_time > timeout_threshold THEN
      RAISE NOTICE 'TIMEOUT: Tempo máximo de execução atingido durante remoção';
      EXIT;
    END IF;

    RAISE NOTICE 'Removendo função %.%(%s) - nível %', 
                 rec_fun.func_schema, rec_fun.func_name, rec_fun.func_signature, rec_fun.dependency_level;
    
    BEGIN
      EXECUTE format('DROP FUNCTION IF EXISTS %I.%I(%s) CASCADE', 
                    rec_fun.func_schema, rec_fun.func_name, rec_fun.func_signature);
      row_count := row_count + 1;
    EXCEPTION WHEN OTHERS THEN
      RAISE NOTICE 'Erro ao remover função %.%(%s): %', 
                  rec_fun.func_schema, rec_fun.func_name, rec_fun.func_signature, SQLERRM;
    END;
  END LOOP;

  step_time := clock_timestamp();
  RAISE NOTICE 'Funções removidas: %', row_count;
  RAISE NOTICE 'Tempo de remoção funções: %', (step_time - start_time);
  RAISE NOTICE '--------------------------------------------------';

  start_time := clock_timestamp();
  RAISE NOTICE 'Iniciando remoção de views...';

  row_count := 0;
  FOR rec_view IN 
    SELECT view_schema, view_name, view_level 
    FROM tmp_views 
    ORDER BY view_level DESC, view_schema, view_name
  LOOP
    IF clock_timestamp() - global_start_time > timeout_threshold THEN
      RAISE NOTICE 'TIMEOUT: Tempo máximo de execução atingido durante remoção';
      EXIT;
    END IF;

    RAISE NOTICE 'Removendo view %.% (nível %)', 
                 rec_view.view_schema, rec_view.view_name, rec_view.view_level;
    
    BEGIN
      EXECUTE format('DROP VIEW IF EXISTS %I.%I CASCADE', 
                    rec_view.view_schema, rec_view.view_name);
      row_count := row_count + 1;
    EXCEPTION WHEN OTHERS THEN
      RAISE NOTICE 'Erro ao remover view %.%: %', 
                  rec_view.view_schema, rec_view.view_name, SQLERRM;
    END;
  END LOOP;

  step_time := clock_timestamp();
  RAISE NOTICE 'Views removidas: %', row_count;
  RAISE NOTICE 'Tempo de remoção views: %', (step_time - start_time);
  RAISE NOTICE '--------------------------------------------------';

  start_time := clock_timestamp();
  RAISE NOTICE 'Iniciando alteração das colunas...';

  row_count := 0;
  FOR rec_alt IN SELECT * FROM tmp_to_alter LOOP
    IF clock_timestamp() - global_start_time > timeout_threshold THEN
      RAISE NOTICE 'TIMEOUT: Tempo máximo de execução atingido durante alteração';
      EXIT;
    END IF;

    RAISE NOTICE 'Alterando %.%.% para varchar(%)', 
                rec_alt.schema_name, rec_alt.table_name, rec_alt.column_name, rec_alt.new_len;
    
    BEGIN
      EXECUTE format(
        'ALTER TABLE %I.%I ALTER COLUMN %I TYPE varchar(%s)',
        rec_alt.schema_name, rec_alt.table_name, rec_alt.column_name, rec_alt.new_len);
      row_count := row_count + 1;
    EXCEPTION WHEN OTHERS THEN
      RAISE NOTICE 'Erro ao alterar %.%.%: %', 
                  rec_alt.schema_name, rec_alt.table_name, rec_alt.column_name, SQLERRM;
    END;
  END LOOP;

  step_time := clock_timestamp();
  RAISE NOTICE 'Colunas alteradas: %', row_count;
  RAISE NOTICE 'Tempo de alteração: %', (step_time - start_time);
  RAISE NOTICE '--------------------------------------------------';

  start_time := clock_timestamp();
  RAISE NOTICE 'Iniciando recriação de views...';

  row_count := 0;
  FOR rec_view IN 
    SELECT view_schema, view_name, view_sql, view_owner, grant_stmts, view_level
    FROM tmp_views 
    WHERE view_sql IS NOT NULL
    ORDER BY view_level ASC, view_schema, view_name
  LOOP
    IF clock_timestamp() - global_start_time > timeout_threshold THEN
      RAISE NOTICE 'TIMEOUT: Tempo máximo de execução atingido durante recriação';
      EXIT;
    END IF;

    RAISE NOTICE 'Recriando view %.% (nível %)', 
                 rec_view.view_schema, rec_view.view_name, rec_view.view_level;
    
    BEGIN
      EXECUTE format('CREATE VIEW %I.%I AS %s', 
                    rec_view.view_schema, rec_view.view_name, rec_view.view_sql);
      
      IF rec_view.view_owner IS NOT NULL THEN
        EXECUTE format('ALTER VIEW %I.%I OWNER TO %I', 
                      rec_view.view_schema, rec_view.view_name, rec_view.view_owner);
      END IF;
      

      IF rec_view.grant_stmts IS NOT NULL AND array_length(rec_view.grant_stmts, 1) > 0 THEN
        FOR i IN 1..array_length(rec_view.grant_stmts, 1) LOOP
          BEGIN

            IF rec_view.grant_stmts[i] IS NOT NULL 
               AND length(trim(rec_view.grant_stmts[i])) > 0 THEN
              EXECUTE rec_view.grant_stmts[i];
            END IF;
          EXCEPTION WHEN OTHERS THEN
            RAISE NOTICE 'Erro ao aplicar grant para view %.%: % (comando: %)', 
                        rec_view.view_schema, rec_view.view_name, SQLERRM, rec_view.grant_stmts[i];
          END;
        END LOOP;
      END IF;
      
      row_count := row_count + 1;
    EXCEPTION WHEN OTHERS THEN
      RAISE NOTICE 'Erro ao recriar view %.%: %', 
                  rec_view.view_schema, rec_view.view_name, SQLERRM;
    END;
  END LOOP;

  step_time := clock_timestamp();
  RAISE NOTICE 'Views recriadas: %', row_count;
  RAISE NOTICE 'Tempo de recriação views: %', (step_time - start_time);
  RAISE NOTICE '--------------------------------------------------';

  start_time := clock_timestamp();
  RAISE NOTICE 'Iniciando recriação de funções...';

  row_count := 0;
  FOR rec_fun IN 
    SELECT func_schema, func_name, func_signature, func_sql, func_owner, grant_stmts, dependency_level
    FROM tmp_funcs 
    WHERE func_sql IS NOT NULL
    ORDER BY dependency_level ASC, func_schema, func_name
  LOOP
    IF clock_timestamp() - global_start_time > timeout_threshold THEN
      RAISE NOTICE 'TIMEOUT: Tempo máximo de execução atingido durante recriação';
      EXIT;
    END IF;

    RAISE NOTICE 'Recriando função %.%(%s) - nível %', 
                 rec_fun.func_schema, rec_fun.func_name, rec_fun.func_signature, rec_fun.dependency_level;
    
    BEGIN
      EXECUTE rec_fun.func_sql;
      
      IF rec_fun.func_owner IS NOT NULL THEN
        EXECUTE format('ALTER FUNCTION %I.%I(%s) OWNER TO %I', 
                      rec_fun.func_schema, rec_fun.func_name, rec_fun.func_signature, rec_fun.func_owner);
      END IF;
      

      IF rec_fun.grant_stmts IS NOT NULL AND array_length(rec_fun.grant_stmts, 1) > 0 THEN
        FOR i IN 1..array_length(rec_fun.grant_stmts, 1) LOOP
          BEGIN

            IF rec_fun.grant_stmts[i] IS NOT NULL 
               AND length(trim(rec_fun.grant_stmts[i])) > 0 THEN
              EXECUTE rec_fun.grant_stmts[i];
            END IF;
          EXCEPTION WHEN OTHERS THEN
            RAISE NOTICE 'Erro ao aplicar grant para função %.%(%s): % (comando: %)', 
                        rec_fun.func_schema, rec_fun.func_name, rec_fun.func_signature, SQLERRM, rec_fun.grant_stmts[i];
          END;
        END LOOP;
      END IF;
      
      row_count := row_count + 1;
    EXCEPTION WHEN OTHERS THEN
      RAISE NOTICE 'Erro ao recriar função %.%(%s): %', 
                  rec_fun.func_schema, rec_fun.func_name, rec_fun.func_signature, SQLERRM;
    END;
  END LOOP;

  step_time := clock_timestamp();
  RAISE NOTICE 'Funções recriadas: %', row_count;
  RAISE NOTICE 'Tempo de recriação funções: %', (step_time - start_time);
  RAISE NOTICE '--------------------------------------------------';

  start_time := clock_timestamp();
  RAISE NOTICE 'Iniciando recriação de triggers...';

  row_count := 0;
  FOR rec_trig IN 
    SELECT trig_schema, trig_table, trig_name, trig_sql, trig_owner, should_skip
    FROM tmp_triggers 
    WHERE trig_sql IS NOT NULL AND should_skip = false
    ORDER BY trig_schema, trig_table, trig_name
  LOOP
    IF clock_timestamp() - global_start_time > timeout_threshold THEN
      RAISE NOTICE 'TIMEOUT: Tempo máximo de execução atingido durante recriação';
      EXIT;
    END IF;

    RAISE NOTICE 'Recriando trigger %.%.%', 
                 rec_trig.trig_schema, rec_trig.trig_table, rec_trig.trig_name;
    
    BEGIN
      EXECUTE rec_trig.trig_sql;
      row_count := row_count + 1;
    EXCEPTION WHEN OTHERS THEN
      RAISE NOTICE 'Erro ao recriar trigger %.%.%: %', 
                  rec_trig.trig_schema, rec_trig.trig_table, rec_trig.trig_name, SQLERRM;
    END;
  END LOOP;

  step_time := clock_timestamp();
  RAISE NOTICE 'Triggers recriados: %', row_count;
  RAISE NOTICE 'Tempo de recriação triggers: %', (step_time - start_time);
  RAISE NOTICE '--------------------------------------------------';

  start_time := clock_timestamp();
  RAISE NOTICE 'Iniciando recriação de constraints...';

  row_count := 0;

  FOR rec_const IN 
    SELECT const_schema, const_table, const_name, const_type, const_sql
    FROM tmp_constraints 
    WHERE const_sql IS NOT NULL
    ORDER BY 
      CASE const_type 
        WHEN 'p' THEN 1  
        WHEN 'u' THEN 2  
        WHEN 'f' THEN 3  
        WHEN 'c' THEN 4  
        ELSE 5
      END,
      const_schema, const_table, const_name
  LOOP
    IF clock_timestamp() - global_start_time > timeout_threshold THEN
      RAISE NOTICE 'TIMEOUT: Tempo máximo de execução atingido durante recriação';
      EXIT;
    END IF;

    RAISE NOTICE 'Recriando constraint %.%.% (tipo: %)', 
                 rec_const.const_schema, rec_const.const_table, 
                 rec_const.const_name, rec_const.const_type;
    
    BEGIN
      EXECUTE format('ALTER TABLE %I.%I ADD CONSTRAINT %I %s', 
                    rec_const.const_schema, rec_const.const_table, 
                    rec_const.const_name, rec_const.const_sql);
      row_count := row_count + 1;
    EXCEPTION WHEN OTHERS THEN
      RAISE NOTICE 'Erro ao recriar constraint %.%.%: %', 
                  rec_const.const_schema, rec_const.const_table, rec_const.const_name, SQLERRM;
    END;
  END LOOP;

  step_time := clock_timestamp();
  RAISE NOTICE 'Constraints recriadas: %', row_count;
  RAISE NOTICE 'Tempo de recriação constraints: %', (step_time - start_time);
  RAISE NOTICE '--------------------------------------------------';

  RAISE NOTICE '==================================================================';
  RAISE NOTICE 'RELATÓRIO FINAL';
  RAISE NOTICE 'Tempo total: %', (clock_timestamp() - global_start_time);
  RAISE NOTICE 'Colunas processadas: %/%', 
               (SELECT count(*) FROM tmp_to_alter), array_length(campos, 1);
  RAISE NOTICE 'Constraints processadas: %', 
               (SELECT count(*) FROM tmp_constraints);
  RAISE NOTICE 'Views processadas: % (níveis: 1 a %)', 
               (SELECT count(*) FROM tmp_views),
               (SELECT COALESCE(max(view_level), 0) FROM tmp_views);
  RAISE NOTICE 'Funções processadas: %', 
               (SELECT count(*) FROM tmp_funcs);
  RAISE NOTICE 'Triggers de usuário processados: %', 
               (SELECT count(*) FROM tmp_triggers WHERE should_skip = false);
  RAISE NOTICE 'Constraints com metadados: %/%',
               (SELECT count(*) FROM tmp_constraints WHERE const_sql IS NOT NULL),
               (SELECT count(*) FROM tmp_constraints);
  RAISE NOTICE 'Views com metadados: %/%',
               (SELECT count(*) FROM tmp_views WHERE view_sql IS NOT NULL),
               (SELECT count(*) FROM tmp_views);
  RAISE NOTICE 'Funções com metadados: %/%',
               (SELECT count(*) FROM tmp_funcs WHERE func_sql IS NOT NULL),
               (SELECT count(*) FROM tmp_funcs);
  RAISE NOTICE 'Triggers com metadados: %/%',
               (SELECT count(*) FROM tmp_triggers WHERE trig_sql IS NOT NULL),
               (SELECT count(*) FROM tmp_triggers WHERE should_skip = false);
  RAISE NOTICE '==================================================================';

EXCEPTION WHEN OTHERS THEN
  RAISE NOTICE 'ERRO FATAL: %', SQLERRM;
  RAISE NOTICE 'SQLSTATE: %', SQLSTATE;
  RAISE;
END;
$$ LANGUAGE plpgsql;