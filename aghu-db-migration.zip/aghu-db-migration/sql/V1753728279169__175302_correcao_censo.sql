DO $$

DECLARE

v_exists_table BOOLEAN;

v_exists_column BOOLEAN;

v_is_not_null BOOLEAN;

v_column_type TEXT;

v_character_max_length INTEGER;

BEGIN

SELECT EXISTS (

SELECT 1 FROM information_schema.tables

WHERE table_schema = 'agh' AND table_name = 'ain_calculo_paciente_dia'

) INTO v_exists_table;



IF NOT v_exists_table THEN

RAISE NOTICE '❌ Tabela agh.ain_calculo_paciente_dia não existe.';

RETURN;

END IF;



SELECT EXISTS (

SELECT 1 FROM information_schema.columns

WHERE table_schema = 'agh' AND table_name = 'ain_calculo_paciente_dia'

AND column_name = 'ind_pac_pediatrico'

) INTO v_exists_column;



IF NOT v_exists_column THEN

RAISE NOTICE '❌ Coluna ind_pac_pediatrico não existe na tabela agh.ain_calculo_paciente_dia.';

RETURN;

END IF;



SELECT data_type, character_maximum_length

FROM information_schema.columns

WHERE table_schema = 'agh' AND table_name = 'ain_calculo_paciente_dia'

AND column_name = 'ind_pac_pediatrico'

INTO v_column_type, v_character_max_length;



IF v_column_type != 'character varying' OR v_character_max_length != 2 THEN

RAISE NOTICE '❌ Tipo ou tamanho da coluna ind_pac_pediatrico está incorreto. Esperado: VARCHAR(2). Encontrado: %(%).',

v_column_type, v_character_max_length;

RETURN;

ELSE

RAISE NOTICE '✅ Tipo e tamanho da coluna estão corretos: VARCHAR(2).';

END IF;



SELECT NOT is_nullable::BOOLEAN

FROM information_schema.columns

WHERE table_schema = 'agh' AND table_name = 'ain_calculo_paciente_dia'

AND column_name = 'ind_pac_pediatrico'

INTO v_is_not_null;



IF v_is_not_null THEN

EXECUTE 'ALTER TABLE agh.ain_calculo_paciente_dia ALTER COLUMN ind_pac_pediatrico DROP NOT NULL';

RAISE NOTICE '✅ Restrição NOT NULL removida da coluna ind_pac_pediatrico.';

ELSE

RAISE NOTICE 'ℹ️ Coluna ind_pac_pediatrico já está como NULLABLE.';

END IF;

END $$;
