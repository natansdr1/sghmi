do $$
declare
begin
IF NOT EXISTS (SELECT 1 FROM agh.agh_parametros WHERE nome = 'P_REGRA_ESTORNO_NOTA') THEN
raise info 'Inserindo registro na tabela ''agh.agh_parametros''';
insert into agh.agh_parametros(seq, sis_sigla, nome, mantem_historico, criado_em, criado_por,
                               alterado_em, alterado_por, vlr_data, vlr_numerico, vlr_texto, descricao, rotina_consistencia,
                               "version", vlr_data_padrao, vlr_numerico_padrao, vlr_texto_padrao, exemplo_uso, tipo_dado) values
    (nextval('agh.agh_psi_sq1'), 'SCE', 'P_REGRA_ESTORNO_NOTA', 'S', now(), 'AGHU', null, null, null, null, 'S',
     'S - indica se o estorno será realizado conforme as regras de negócio.
N - estorno será realizado sem as regras de negócio.',
     null, 0, null, null, null, null, 'N');
raise info 'Registro inserido com sucesso na tabela ''agh.agh_parametros''';
end if;
end $$ language plpgsql;