--Inclusão de novo campo no Manter Documentos assinados (Solicitação Assinatura_digital)
do $$
declare
s varchar(100) := '';
begin
    if not exists(select null
        from information_schema.columns
        where table_name = 'agh_documentos_certificados' and column_name = 'ind_impressao_automatica' and table_schema = 'agh') then
alter table agh.agh_documentos_certificados add column ind_impressao_automatica character varying(1) default 'S'::character varying;
end if;

select a.data_type
into s
from information_schema.columns a
where a.table_schema = 'agh' and a.table_name = 'agh_documentos' and a.column_name = 'entidade_alvo';
if(s = 'bigint') then
        raise notice 'Não foi necessário alterar a coluna agh.agh_documentos.entidade_alvo';
else begin
            if exists(select null from information_schema.tables a where a.table_schema = 'db_migration' and a.table_name = 'v_afa_prcr_disp_mdtos_painel') then
drop view db_migration.v_afa_prcr_disp_mdtos_painel;
end if;
alter table agh.agh_documentos alter column entidade_alvo type bigint;
CREATE or replace VIEW db_migration.v_afa_prcr_disp_mdtos_painel(atd_seq, seq, dt_referencia, dthr_inicio, dthr_fim, atd_seq_local, prontuario, lto_lto_id, qrt_numero, unf_seq, trp_seq, codigo, nome, apa_atd_seq, apa_seq, seqp, countsolic, countdisp, countconf, countenv, counttriado, countocorr, unf_descricao, configprescmed, dataprescmed, configprescmedassinada, esta_assinada, clinica_codigo) AS
SELECT x.atd_seq, x.seq, x.dt_referencia, x.dthr_inicio, x.dthr_fim, x.atd_seq_local, x.prontuario, x.lto_lto_id, x.qrt_numero, x.unf_seq,
       x.trp_seq, x.codigo, x.nome, x.apa_atd_seq, x.apa_seq, x.seqp, x.countsolic, x.countdisp, x.countconf, x.countenv, x.counttriado, x.countocorr,
       (((((COALESCE(unf.andar, ''::character varying))::text || ' '::text) || (COALESCE(unf.ind_ala, ''::character varying))::text) || ' - '::text) || (COALESCE(unf.descricao, ''::character varying))::text) AS unf_descricao,
                    CASE
                        WHEN (
                        CASE
                            WHEN (((atd.ind_pac_atendimento)::text = 'S'::text) AND (cuf.unf_seq IS NOT NULL)) THEN 'false'::text
                            ELSE 'true'::text
                        END = 'true'::text) THEN ''::text
                        WHEN (NOT (( SELECT count(*) AS count
FROM agh.mpm_prescricao_medicas pm
WHERE ((((pm.atd_seq = atd.seq) AND (pm.ser_matricula_valida IS NOT NULL)) AND (pm.ser_vin_codigo_valida IS NOT NULL)) AND (pm.dthr_fim > now()))) > 0)) THEN 'PRESCRICAO_NAO_REALIZADA'::text
    WHEN (NOT (( SELECT count(*) AS count
FROM agh.mpm_prescricao_medicas pm
WHERE (((((pm.atd_seq = atd.seq) AND (pm.ser_matricula_valida IS NOT NULL)) AND (pm.ser_vin_codigo_valida IS NOT NULL)) AND (pm.dthr_inicio > now())) AND (to_char(unf.hrio_validade_pme, 'HH24:mi'::text) = to_char(pm.dthr_inicio, 'HH24:mi'::text)))) > 0)) THEN 'PRESCRICAO_VENCE_NO_DIA'::text
    ELSE 'PRESCRICAO_VENCE_NO_DIA_SEGUINTE'::text
END AS configprescmed,
                    CASE
                        WHEN (
                        CASE
                            WHEN (((atd.ind_pac_atendimento)::text = 'S'::text) AND (cuf.unf_seq IS NOT NULL)) THEN 'false'::text
                            ELSE 'true'::text
                        END = 'true'::text) THEN NULL::timestamp without time zone
                        WHEN (NOT (( SELECT count(*) AS count
                           FROM agh.mpm_prescricao_medicas pm
                          WHERE ((((pm.atd_seq = atd.seq) AND (pm.ser_matricula_valida IS NOT NULL)) AND (pm.ser_vin_codigo_valida IS NOT NULL)) AND (pm.dthr_fim > now()))) > 0)) THEN NULL::timestamp without time zone
                        ELSE ( SELECT max(pm.dthr_inicio) AS dthr_inicio
                           FROM agh.mpm_prescricao_medicas pm
                          WHERE ((((pm.atd_seq = atd.seq) AND (pm.ser_matricula_valida IS NOT NULL)) AND (pm.ser_vin_codigo_valida IS NOT NULL)) AND (to_char(unf.hrio_validade_pme, 'HH24:mi'::text) = to_char(pm.dthr_inicio, 'HH24:mi'::text))))
END AS dataprescmed,
                    CASE
                        WHEN ((( SELECT docv.situacao
                           FROM (agh.agh_documentos doc
                             JOIN agh.agh_versoes_documentos docv ON ((doc.seq = docv.dok_seq)))
                          WHERE (doc.entidade_alvo = x.seq)))::text = 'A'::text) THEN 'ASSINADO'::text
                        ELSE ''::text
END AS configprescmedassinada,
                    CASE
                        WHEN (( SELECT count(docs.pac_codigo) AS count
                           FROM agh.v_agh_versoes_documentos docs
                          WHERE ((((docs.dov_situacao)::text = 'A'::text) AND ((docs.dok_tipo)::text = 'PM'::text)) AND (docs.pac_codigo = atd.pac_codigo))) > 0) THEN 'ASSINADO'::text
                        ELSE ''::text
END AS esta_assinada,
                clinicas.codigo AS clinica_codigo
               FROM ((((agh.v_afa_prcr_disp_mdtos x
                 JOIN agh.agh_atendimentos atd ON ((atd.seq = x.atd_seq)))
                 LEFT JOIN agh.agh_unidades_funcionais unf ON ((atd.unf_seq = unf.seq)))
                 LEFT JOIN agh.agh_caract_unid_funcionais cuf ON (((cuf.unf_seq = atd.unf_seq) AND ((cuf.caracteristica)::text = 'Pme Informatizada'::text))))
                 LEFT JOIN agh.agh_clinicas clinicas ON ((unf.clc_codigo = clinicas.codigo)));
            raise notice 'Coluna agh.agh_documentos.entidade_alvo alterada com sucesso.';
exception
            when others then
                raise notice 'Erro na inserção do registro';
                raise info 'Error Name:%', sqlerrm;
                raise info 'Error State:%', sqlstate;
                CREATE or replace VIEW db_migration.v_afa_prcr_disp_mdtos_painel (atd_seq, seq, dt_referencia, dthr_inicio, dthr_fim, atd_seq_local, prontuario, lto_lto_id, qrt_numero, unf_seq, trp_seq, codigo, nome, apa_atd_seq, apa_seq, seqp, countsolic, countdisp, countconf, countenv, counttriado, countocorr, unf_descricao, configprescmed, dataprescmed, configprescmedassinada, esta_assinada, clinica_codigo) AS
SELECT x.atd_seq, x.seq, x.dt_referencia, x.dthr_inicio, x.dthr_fim, x.atd_seq_local, x.prontuario, x.lto_lto_id, x.qrt_numero, x.unf_seq,
       x.trp_seq, x.codigo, x.nome, x.apa_atd_seq, x.apa_seq, x.seqp, x.countsolic, x.countdisp, x.countconf, x.countenv, x.counttriado, x.countocorr,
       (((((COALESCE(unf.andar, ''::character varying))::text || ' '::text) || (COALESCE(unf.ind_ala, ''::character varying))::text) || ' - '::text) || (COALESCE(unf.descricao, ''::character varying))::text) AS unf_descricao,
                        CASE
                            WHEN (
                            CASE
                                WHEN (((atd.ind_pac_atendimento)::text = 'S'::text) AND (cuf.unf_seq IS NOT NULL)) THEN 'false'::text
                                ELSE 'true'::text
                            END = 'true'::text) THEN ''::text
                            WHEN (NOT (( SELECT count(*) AS count
FROM agh.mpm_prescricao_medicas pm
WHERE ((((pm.atd_seq = atd.seq) AND (pm.ser_matricula_valida IS NOT NULL)) AND (pm.ser_vin_codigo_valida IS NOT NULL)) AND (pm.dthr_fim > now()))) > 0)) THEN 'PRESCRICAO_NAO_REALIZADA'::text
    WHEN (NOT (( SELECT count(*) AS count
FROM agh.mpm_prescricao_medicas pm
WHERE (((((pm.atd_seq = atd.seq) AND (pm.ser_matricula_valida IS NOT NULL)) AND (pm.ser_vin_codigo_valida IS NOT NULL)) AND (pm.dthr_inicio > now())) AND (to_char(unf.hrio_validade_pme, 'HH24:mi'::text) = to_char(pm.dthr_inicio, 'HH24:mi'::text)))) > 0)) THEN 'PRESCRICAO_VENCE_NO_DIA'::text
    ELSE 'PRESCRICAO_VENCE_NO_DIA_SEGUINTE'::text
END AS configprescmed,
                        CASE
                            WHEN (
                            CASE
                                WHEN (((atd.ind_pac_atendimento)::text = 'S'::text) AND (cuf.unf_seq IS NOT NULL)) THEN 'false'::text
                                ELSE 'true'::text
                            END = 'true'::text) THEN NULL::timestamp without time zone
                            WHEN (NOT (( SELECT count(*) AS count
                               FROM agh.mpm_prescricao_medicas pm
                              WHERE ((((pm.atd_seq = atd.seq) AND (pm.ser_matricula_valida IS NOT NULL)) AND (pm.ser_vin_codigo_valida IS NOT NULL)) AND (pm.dthr_fim > now()))) > 0)) THEN NULL::timestamp without time zone
                            ELSE ( SELECT max(pm.dthr_inicio) AS dthr_inicio
                               FROM agh.mpm_prescricao_medicas pm
                              WHERE ((((pm.atd_seq = atd.seq) AND (pm.ser_matricula_valida IS NOT NULL)) AND (pm.ser_vin_codigo_valida IS NOT NULL)) AND (to_char(unf.hrio_validade_pme, 'HH24:mi'::text) = to_char(pm.dthr_inicio, 'HH24:mi'::text))))
END AS dataprescmed,
                        CASE
                            WHEN ((( SELECT docv.situacao
                               FROM (agh.agh_documentos doc
                                 JOIN agh.agh_versoes_documentos docv ON ((doc.seq = docv.dok_seq)))
                              WHERE (doc.entidade_alvo = x.seq)))::text = 'A'::text) THEN 'ASSINADO'::text
                            ELSE ''::text
END AS configprescmedassinada,
                        CASE
                            WHEN (( SELECT count(docs.pac_codigo) AS count
                               FROM agh.v_agh_versoes_documentos docs
                              WHERE ((((docs.dov_situacao)::text = 'A'::text) AND ((docs.dok_tipo)::text = 'PM'::text)) AND (docs.pac_codigo = atd.pac_codigo))) > 0) THEN 'ASSINADO'::text
                            ELSE ''::text
END AS esta_assinada,
                    clinicas.codigo AS clinica_codigo
                   FROM ((((agh.v_afa_prcr_disp_mdtos x
                     JOIN agh.agh_atendimentos atd ON ((atd.seq = x.atd_seq)))
                     LEFT JOIN agh.agh_unidades_funcionais unf ON ((atd.unf_seq = unf.seq)))
                     LEFT JOIN agh.agh_caract_unid_funcionais cuf ON (((cuf.unf_seq = atd.unf_seq) AND ((cuf.caracteristica)::text = 'Pme Informatizada'::text))))
                     LEFT JOIN agh.agh_clinicas clinicas ON ((unf.clc_codigo = clinicas.codigo)));
end;
end if;

    if exists(select null from information_schema.tables a where a.table_schema = 'agh' and a.table_name = 'agh_documentos')
        and not exists(select null
            from information_schema.columns
            where table_name = 'agh_documentos' and column_name = 'entidade_alvo' and table_schema ilike 'agh') then
alter table agh.agh_documentos add entidade_alvo int;
comment on column agh.agh_documentos.entidade_alvo is 'Coluna que guardar a seq com base no tipo informado pelo usuário no cadastro de Documentos assinados.';
create unique index agh_documentos_entidade_alvo_uindex on agh.agh_documentos (entidade_alvo, tipo);
end if;
end $$;
