DO
$$
BEGIN

IF
NOT EXISTS (
        SELECT 1
        FROM information_schema.columns
        WHERE table_schema = 'agh'
        AND table_name = 'sco_materiais_almoxarifados_entrada'
    ) THEN

create table agh.sco_materiais_almoxarifados_entrada
(
    materiais_codigo  INTEGER  NOT NULL,
    almoxarifados_seq SMALLINT NOT NULL,
    CONSTRAINT sco_materiais_almoxarifados_pkey PRIMARY KEY (materiais_codigo, almoxarifados_seq),
    CONSTRAINT sco_materiais_almoxarifados_fk1 FOREIGN KEY (materiais_codigo) REFERENCES agh.sco_materiais (codigo) MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION,
    CONSTRAINT sco_materiais_almoxarifados_fk2 FOREIGN KEY (almoxarifados_seq) REFERENCES agh.sce_almoxarifados (seq) MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION
);

INSERT INTO agh.sco_materiais_almoxarifados_entrada (materiais_codigo, almoxarifados_seq)
SELECT codigo, alm_seq
FROM agh.sco_materiais
where alm_seq is not null;

END IF;

IF
NOT EXISTS (
        select 1 from information_schema.columns
        where table_schema = 'agh'
        AND table_name = 'sce_item_nrs'
        AND column_name = 'alm_entrada_seq') then

ALTER TABLE agh.sce_item_nrs
    ADD COLUMN alm_entrada_seq smallint
        constraint sce_item_nrs_alm_entrada_fk references agh.sce_almoxarifados;

UPDATE agh.sce_item_nrs
SET alm_entrada_seq=subquery.alm_seq
    FROM (
        SELECT item.nrs_seq, item.iaf_afn_numero, item.iaf_numero, m.codigo, m.alm_seq
        FROM agh.sce_item_nrs item
        INNER JOIN agh.sco_materiais m on item.mat_codigo = m.codigo
    ) AS subquery
WHERE agh.sce_item_nrs.nrs_seq=subquery.nrs_seq
and agh.sce_item_nrs.iaf_afn_numero=subquery.iaf_afn_numero
and agh.sce_item_nrs.iaf_numero=subquery.iaf_numero
and agh.sce_item_nrs.mat_codigo=subquery.codigo;

END IF;

END $$;