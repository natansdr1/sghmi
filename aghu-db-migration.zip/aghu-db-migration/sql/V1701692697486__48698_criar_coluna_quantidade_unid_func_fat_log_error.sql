DO $$
BEGIN

    IF NOT EXISTS(
            SELECT 1
            FROM information_schema.columns
            WHERE table_schema = 'agh'
                AND table_name = 'fat_log_errors'
                AND column_name = 'qtd'
        ) THEN
        ALTER TABLE agh.fat_log_errors ADD COLUMN qtd int4 NULL;
        COMMENT ON COLUMN agh.fat_log_errors.qtd IS 'Quantidade de procedimentos além da permitida pela tabela SIGTAP.';
        RAISE NOTICE 'Criação da Coluna: QTD, na Tabela: agh.fat_log_error #48698';

    END IF;

    IF not exists(select null from agh.fat_mensagens_log fiph where fiph.codigo = 1000) then
        INSERT INTO agh.fat_mensagens_log(erro, modulo, situacao, ind_secretario, "version", codigo)
        VALUES('QUANTIDADE EXCEDENTE', 'AMB', 'NAOCOBR', 'I', 1, 1000);
        RAISE NOTICE 'Inserindo motivo na Tabela: agh.fat_log_error #48698';

    END IF;

END $$