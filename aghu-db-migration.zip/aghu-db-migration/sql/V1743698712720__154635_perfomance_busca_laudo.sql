do
$$
begin

IF not EXISTS (select 1 from pg_indexes ix where ix.schemaname = 'agh' and tablename = 'lws_com_amostras' and indexname = 'lws_com_amostras_i_1') THEN
  CREATE INDEX lws_com_amostras_i_1 ON agh.lws_com_amostras USING btree (solicitacao NULLS FIRST) tablespace tblspc_idx;
   RAISE NOTICE 'Indice agh.lws_com_amostras.lws_com_amostras_i_1 criado com sucesso.';
else
   RAISE NOTICE 'Indice já existe agh.lws_com_amostras.lws_com_amostras_i_1 nada foi feito.'; 
END IF;

IF not EXISTS (select 1 from pg_indexes ix where ix.schemaname = 'agh' and tablename = 'lws_com_amostras' and indexname = 'lws_com_amostras_i_2') THEN
  CREATE INDEX lws_com_amostras_i_2 ON agh.lws_com_amostras USING btree (DATA_HORA_COLETA  NULLS FIRST) tablespace tblspc_idx;
   RAISE NOTICE 'Indice agh.lws_com_amostras.lws_com_amostras_i_2 criado com sucesso.';
else
   RAISE NOTICE 'Indice já existe agh.lws_com_amostras.lws_com_amostras_i_2 nada foi feito.'; 
END IF;

IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'agh' and table_name = 'lws_com_amostras') then
   RAISE NOTICE 'Analisando agh.lws_com_amostras';
   analyze agh.lws_com_amostras;
   RAISE NOTICE 'agh.lws_com_amostras analisado';
end if;

 
IF not EXISTS (select 1 from pg_indexes ix where ix.schemaname = 'agh' and tablename = 'lws_com_solicitacao_exames' and indexname = 'lws_com_solicitacao_exames_i_1') THEN
  CREATE INDEX lws_com_solicitacao_exames_i_1 ON agh.lws_com_solicitacao_exames USING btree (solicitacao NULLS FIRST) tablespace tblspc_idx;
   RAISE NOTICE 'Indice agh.lws_com_solicitacao_exames.lws_com_solicitacao_exames_i_1 criado com sucesso.';
else
   RAISE NOTICE 'Indice já existe agh.lws_com_solicitacao_exames.lws_com_solicitacao_exames_i_1 nada foi feito.'; 
END IF;

IF not EXISTS (select 1 from pg_indexes ix where ix.schemaname = 'agh' and tablename = 'lws_com_solicitacao_exames' and indexname = 'lws_com_solicitacao_exames_i_2') THEN
  CREATE INDEX lws_com_solicitacao_exames_i_2 ON agh.lws_com_solicitacao_exames USING btree (profissional_liberacao NULLS FIRST) tablespace tblspc_idx;
   RAISE NOTICE 'Indice agh.lws_com_solicitacao_exames.lws_com_solicitacao_exames_i_2 criado com sucesso.';
else
   RAISE NOTICE 'Indice já existe agh.lws_com_solicitacao_exames.lws_com_solicitacao_exames_i_2 nada foi feito.';
end if;

IF not EXISTS (select 1 from pg_indexes ix where ix.schemaname = 'agh' and tablename = 'lws_com_solicitacao_exames' and indexname = 'lws_com_solicitacao_exames_i_3') THEN
CREATE INDEX lws_com_solicitacao_exames_i_3 ON agh.lws_com_solicitacao_exames ((CASE WHEN substring(profissional_liberacao::text, 4) ~ '^[0-9]+$' THEN (substring(profissional_liberacao::text, 4))::integer ELSE NULL END)) tablespace tblspc_idx;
   RAISE NOTICE 'Indice agh.lws_com_solicitacao_exames.lws_com_solicitacao_exames_i_3 criado com sucesso.';
else
   RAISE NOTICE 'Indice já existe agh.lws_com_solicitacao_exames.lws_com_solicitacao_exames_i_3 nada foi feito.';
end if;

IF not EXISTS (select 1 from pg_indexes ix where ix.schemaname = 'agh' and tablename = 'lws_com_solicitacao_exames' and indexname = 'lws_com_solicitacao_exames_i_4') THEN
   CREATE INDEX lws_com_solicitacao_exames_i_4 ON agh.lws_com_solicitacao_exames ((CASE WHEN substring(profissional_liberacao::text, 1, 3) ~ '^[0-9]+$' THEN (substring(profissional_liberacao::text, 1, 3))::smallint ELSE NULL END)) tablespace tblspc_idx;
   RAISE NOTICE 'Indice agh.lws_com_solicitacao_exames.lws_com_solicitacao_exames_i_4 criado com sucesso.';
else
   RAISE NOTICE 'Indice já existe agh.lws_com_solicitacao_exames.lws_com_solicitacao_exames_i_4 nada foi feito.';
end if;

IF not EXISTS (select 1 from pg_indexes ix where ix.schemaname = 'agh' and tablename = 'lws_com_resultados' and indexname = 'lws_com_resultados_i_1') THEN
  CREATE INDEX lws_com_resultados_i_1 ON agh.lws_com_resultados USING btree (profissional_digitacao NULLS FIRST) tablespace tblspc_idx;
   RAISE NOTICE 'Indice agh.lws_com_resultados.lws_com_resultados_i_1 criado com sucesso.';
else
   RAISE NOTICE 'Indice já existe agh.lws_com_resultados.lws_com_resultados_i_1 nada foi feito.';
END IF;

IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'agh' and table_name = 'lws_com_solicitacao_exames') then
   RAISE NOTICE 'Analisando agh.lws_com_solicitacao_exames';
   analyze agh.lws_com_solicitacao_exames;
   RAISE NOTICE 'agh.lws_com_solicitacao_exames analisado';
end if;

IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'agh' and table_name = 'lws_com_resultados') then
   RAISE NOTICE 'Analisando agh.lws_com_resultados';
   analyze agh.lws_com_resultados;
   RAISE NOTICE 'agh.lws_com_resultados analisado';
end if;

end $$; 