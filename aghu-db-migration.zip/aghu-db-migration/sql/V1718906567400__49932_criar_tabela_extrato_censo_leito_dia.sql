do $$
begin
      if not exists(select null from information_schema.sequences where sequence_schema = 'agh' and sequence_name = 'ain_extrato_censo_leito_dia_seq_sq1') then begin
create sequence agh.ain_extrato_censo_leito_dia_seq_sq1 increment by 1 minvalue 1 maxvalue 9223372036854775807 start with 1 no cycle;
raise info 'sequence ''ain_extrato_censo_leito_dia_seq_sq1'' criada com sucesso.';
exception
            when others then
            raise notice 'Erro na criação da sequence agh.ain_extrato_censo_leito_dia_seq_sq1 - % %', sqlerrm, sqlstate;
end;
else raise notice 'Sequence agh.ain_extrato_censo_leito_dia_seq_sq1 já existia.';
end if;
    if not exists(select 1 from information_schema.tables where table_schema = 'agh' and table_name = 'ain_extrato_censo_leito_dia') then begin
    create table agh.ain_extrato_censo_leito_dia(
        seq int8 not null default nextval('agh.ain_extrato_censo_leito_dia_seq_sq1'::regclass),
        dthr_extracao timestamp NOT NULL,
        lto_lto_id varchar(14) not null,
        criado_em timestamp NOT NULL,
        dthr_lancamento timestamp NOT NULL,
        tml_codigo int2 not null,
        grupo_mvto_leito varchar(2) not null,
        mvto_leito_descricao varchar(60) not null,
        ind_situacao varchar(1) not null,
        tpclsfcclto_seq int2 null,
        tplto_seq int2 null,
        tplto_descricao varchar(60) null,
        esp_seq int2, -- not null
        tuf_seq int2 not null,
        unf_seq int2 not null,
        clc_codigo int2 not null,
        constraint ain_extrato_censo_leito_dia_pk primary key(seq)
);

GRANT ALL ON TABLE agh.ain_extrato_censo_leito_dia TO acesso_completo;
GRANT SELECT ON TABLE agh.ain_extrato_censo_leito_dia TO acesso_leitura;

alter table agh.ain_extrato_censo_leito_dia
    add constraint lto_lto_id foreign key (lto_lto_id) references agh.ain_leitos(lto_id),
    add constraint tml_codigo foreign key (tml_codigo) references agh.ain_tipos_mvto_leito(codigo),
    add constraint tpclsfcclto_seq foreign key (tpclsfcclto_seq) references agh.ain_classificacao_leitos(seq),
    add constraint tplto_seq foreign key (tplto_seq) references agh.ain_tipos_leitos(seq),
    add constraint esp_seq foreign key (esp_seq) references agh.agh_especialidades(seq),
    add constraint unf_seq foreign key (unf_seq) references agh.agh_unidades_funcionais(seq);

    raise notice 'Tabela ain_extrato_censo_leito_dia criada';
    raise notice 'CONSTRAINT lto_lto_id criada';
    raise notice 'CONSTRAINT tml_codigo criada';
    raise notice 'CONSTRAINT clsfcclto_seq criada';
    raise notice 'CONSTRAINT tplto_seq criada';
    raise notice 'CONSTRAINT esp_seq criada';
    raise notice 'CONSTRAINT unf_seq criada';


    comment on table agh.ain_extrato_censo_leito_dia is 'Essa tabela armazenara diariamente os dados relativos a movimentação dos leitos';
    comment on column agh.ain_extrato_censo_leito_dia.seq IS 'Chave primaria';
    comment on column agh.ain_extrato_censo_leito_dia.dthr_extracao is 'Armazena a data que foi feito a extração dos dados do extrato leito';
    comment on column agh.ain_extrato_censo_leito_dia.lto_lto_id is 'Armazena o id do leito';
    comment on column agh.ain_extrato_censo_leito_dia.criado_em is 'Armazena a data que em que foi feito a movimentação do leitoo';
    comment on column agh.ain_extrato_censo_leito_dia.dthr_lancamento is 'Armazena a data que foi feito o lançamento do leito';
    comment on column agh.ain_extrato_censo_leito_dia.tml_codigo is 'Armazena a data que foi feito a extração dos dados do extrato leito';
    comment on column agh.ain_extrato_censo_leito_dia.grupo_mvto_leito is 'Armazena o identicador do movimento leito';
    comment on column agh.ain_extrato_censo_leito_dia.mvto_leito_descricao is 'Armazena a descrição do movimento leito';
    comment on column agh.ain_extrato_censo_leito_dia.ind_situacao is 'Armazena a indicação da situação do leito';
    comment on column agh.ain_extrato_censo_leito_dia.tpclsfcclto_seq is 'Armazena o tipo de classificacao do leito';
    comment on column agh.ain_extrato_censo_leito_dia.tplto_seq is 'Armazena o id do tipo de leito';
    comment on column agh.ain_extrato_censo_leito_dia.tplto_descricao is 'Armazena o descrição do tipo de leito';
    comment on column agh.ain_extrato_censo_leito_dia.esp_seq is 'Armazena o id da especialidade';
    comment on column agh.ain_extrato_censo_leito_dia.tuf_seq is 'Armazena o id do tipo da unidade funcional';
    comment on column agh.ain_extrato_censo_leito_dia.unf_seq is 'Armazena o id da unidade funcional';
    comment on column agh.ain_extrato_censo_leito_dia.clc_codigo is 'Armazena o id da clinica';
exception
    when others then
      raise notice 'Erro na criação da tabela ''agh.ain_extrato_censo_leito_dia'' - % %', sqlerrm, sqlstate;
end;
else raise info 'Tabela agh.ain_extrato_censo_leito_dia já existia';
            --end;
end if;

end $$;