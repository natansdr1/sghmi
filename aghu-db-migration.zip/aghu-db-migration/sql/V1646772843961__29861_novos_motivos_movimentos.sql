do $body$
declare
var_tmv_seq agh.sce_motivo_movimentos.tmv_seq%type := null;
 var_tmv_complemento agh.sce_motivo_movimentos.tmv_complemento%type;
 var_descricao agh.sce_motivo_movimentos.descricao%type;
 n integer := 1;
 qt_registros_inseridos decimal(5) := 0;
 qt_registros_atualizados decimal(5) := 0;
 data_values varchar[] := array[
 ('29'), ('4'), ('GANHOS COM INVENTÁRIO'),
 ('29'), ('4'), ('PERDAS COM INVENTÁRIO'),
 ('29'), ('4'), ('PERMUTAS CONCEDIDAS'),
 ('29'), ('4'), ('PERDAS POR VALIDADE'),
 ('29'), ('4'), ('PERDAS INVOLUNTÁRIAS'),
 ('29'), ('4'), ('DOAÇÕES E TRANSFERÊNCIAS CONCEDIDAS'),
 ('29'), ('4'), ('OUTROS TIPOS DE SAÍDAS'),
 ('30'), ('3'), ('GANHOS COM INVENTÁRIO'),
 ('30'), ('3'), ('PERDAS COM INVENTÁRIO'),
 ('30'), ('3'), ('PERMUTAS CONCEDIDAS'),
 ('30'), ('3'), ('PERDAS POR VALIDADE'),
 ('30'), ('3'), ('PERDAS INVOLUNTÁRIAS'),
 ('30'), ('3'), ('DOAÇÕES E TRANSFERÊNCIAS CONCEDIDAS'),
 ('30'), ('3'), ('OUTROS TIPOS DE SAÍDAS')
 ];
 min_numero integer;
begin
for i in 1 .. array_upper(data_values, 1) / 3 loop
 var_tmv_seq := (data_values[n])::integer;
 var_tmv_complemento := (data_values[n + 1])::integer;
 var_descricao := data_values[n + 2];
select min(a.numero)
from agh.sce_motivo_movimentos a
where a.tmv_seq = var_tmv_seq and a.tmv_complemento = var_tmv_complemento and lower(trim(a.descricao)) = lower(trim(var_descricao))
group by a.tmv_seq, a.tmv_complemento, a.descricao
    into min_numero;
if(not exists(select 1 from agh.sce_motivo_movimentos a
 where a.tmv_seq = var_tmv_seq and a.tmv_complemento = var_tmv_complemento and a.numero = min_numero)) then
 insert into agh.sce_motivo_movimentos values (var_tmv_seq, var_tmv_complemento,
 (select coalesce(max(numero) + 1, 1) from agh.sce_motivo_movimentos where tmv_seq = var_tmv_seq and tmv_complemento = var_tmv_complemento),
 var_descricao, 'A', 0);
 qt_registros_inseridos := qt_registros_inseridos + 1;
 elsif (exists(select 1 from agh.sce_motivo_movimentos a
 where a.tmv_seq = var_tmv_seq and a.tmv_complemento = var_tmv_complemento and a.numero = min_numero and a.ind_situacao = 'I'
 and lower(trim(a.descricao)) = lower(trim(var_descricao)))) then
update agh.sce_motivo_movimentos set ind_situacao = 'A', descricao = var_descricao
where tmv_seq = var_tmv_seq and tmv_complemento = var_tmv_complemento and numero = min_numero;
qt_registros_atualizados := qt_registros_atualizados + 1;
end if;
 n := n + 3;
end loop;
 raise info 'Número de registros inseridos na tabela agh.sce_motivo_movimentos: %', qt_registros_inseridos::varchar;
 raise info 'Número de registros atualizados na tabela agh.sce_motivo_movimentos: %', qt_registros_atualizados::varchar;
exception
 when others then
 raise info 'Erro na inserção ou atualizaão de dados na tabela agh.sce_motivo_movimentos. Error State: %, Error Name:%', sqlstate, sqlerrm;
end $body$;