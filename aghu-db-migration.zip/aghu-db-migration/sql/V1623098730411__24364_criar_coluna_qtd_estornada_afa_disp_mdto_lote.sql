DO $$
BEGIN

	IF NOT EXISTS (
		SELECT
		FROM information_schema.columns
		WHERE table_schema = 'agh'
		AND table_name = 'afa_disp_mdto_lote'
		AND column_name = 'qtd_estornada'
	) THEN
ALTER TABLE agh.afa_disp_mdto_lote ADD COLUMN qtd_estornada integer;
COMMENT ON COLUMN agh.afa_disp_mdto_lote.qtd_estornada IS 'Guardar a qtd estornada por lote na dispensaçao';
	RAISE NOTICE 'EXECUTADO ALTERAÇÃO: #24364 - Novas colunas agh.afa_disp_mdto_lote';
END IF;

END $$