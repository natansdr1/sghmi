DO $$
begin
	RAISE NOTICE 'INICIO criação coluna AGH.MBC_PROC_ESP_POR_CIRURGIAS.ind_lado_cirurgia';

    IF NOT EXISTS(
            SELECT 1
            FROM information_schema.columns
            WHERE table_schema = 'agh'
                AND table_name = 'mbc_proc_esp_por_cirurgias'
                AND column_name = 'ind_lado_cirurgia'
        ) then
        RAISE NOTICE '  CRIANDO coluna AGH.MBC_PROC_ESP_POR_CIRURGIAS.ind_lado_cirurgia foi criada com SUCESSO';
        ALTER TABLE agh.MBC_PROC_ESP_POR_CIRURGIAS ADD COLUMN ind_lado_cirurgia varchar(1);
        COMMENT ON COLUMN AGH.MBC_PROC_ESP_POR_CIRURGIAS.ind_lado_cirurgia IS 'Indica a lateralidade do procedimento.';
        RAISE NOTICE '  CRIADO coluna AGH.MBC_PROC_ESP_POR_CIRURGIAS.ind_lado_cirurgia foi criada com SUCESSO';
    END IF;
   
   RAISE NOTICE 'FIM criação coluna AGH.MBC_PROC_ESP_POR_CIRURGIAS.ind_lado_cirurgia';
END $$