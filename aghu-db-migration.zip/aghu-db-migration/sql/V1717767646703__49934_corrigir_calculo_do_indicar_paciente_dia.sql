do $$
    begin
        if not exists(select null from information_schema.sequences where sequence_schema = 'agh' and sequence_name = 'ain_calculo_paciente_seq_sq1') then begin
    create sequence agh.ain_calculo_paciente_seq_sq1 increment by 1 minvalue 1 maxvalue 9223372036854775807 start with 1 no cycle;
    raise info 'sequence ''agh.ain_calculo_paciente_seq_sq1'' criada com sucesso.';
    exception
                when others then
                raise notice 'Erro na criação da sequence agh.ain_calculo_paciente_seq_sq1 - % %', sqlerrm, sqlstate;
    end;
    else raise notice 'Sequence agh.ain_calculo_paciente_seq_sq1 já existia.';
    end if;
        if not exists(select 1 from information_schema.tables where table_schema = 'agh' and table_name = 'ain_calculo_paciente_dia') then begin
        create table agh.ain_calculo_paciente_dia(
               seq int8 not null default nextval('agh.ain_calculo_paciente_seq_sq1'::regclass),
               dthr_extracao timestamp NOT NULL,
               int_seq int4 not null,
               pac_codigo int4 not null,
               prontuario int4 not null,
               esp_seq int2 not null,
               ind_pac_pediatrico varchar(2) not null,
               unf_seq varchar(2) not null,
               lto_lto_id varchar(14) null,
               tmi_seq int2 not null,
               constraint ain_calculo_paciente_pk primary key(seq)
        );
        CREATE UNIQUE INDEX ain_calculo_paciente_dia_pk_idx ON agh.ain_calculo_paciente_dia USING btree (seq);
		
        GRANT ALL ON TABLE agh.ain_calculo_paciente_dia TO acesso_completo;
        GRANT SELECT ON TABLE agh.ain_calculo_paciente_dia TO acesso_leitura;
        
    alter table agh.ain_calculo_paciente_dia
        add constraint int_seq foreign key (int_seq) references agh.ain_internacoes(seq);
        raise notice 'Tabela agh.ain_calculo_paciente_dia criada';
            raise notice 'CONSTRAINT int_seq criada';
            comment on table agh.ain_calculo_paciente_dia is 'Essa tabela armazenara diariamente os dados relativos a movimentação dos pacientes';
            comment on column agh.ain_calculo_paciente_dia.seq IS 'Chave primaria';
            comment on column agh.ain_calculo_paciente_dia.dthr_extracao is 'Armazena a data que foi feito a extração da movimentação dos pacientes';
            comment on column agh.ain_calculo_paciente_dia.int_seq is 'Armazena o id da internação';
            comment on column agh.ain_calculo_paciente_dia.pac_codigo is 'Armazena o código do paciente';
            comment on column agh.ain_calculo_paciente_dia.prontuario is 'Armazena o prontuário do paciente';
            comment on column agh.ain_calculo_paciente_dia.esp_seq is 'Armazena o id da especialidade';
            comment on column agh.ain_calculo_paciente_dia.ind_pac_pediatrico is 'Campo que identifica se o paciente é pediatrico ou não';
            comment on column agh.ain_calculo_paciente_dia.unf_seq is 'Armazena o id da unidade funcional';
            comment on column agh.ain_calculo_paciente_dia.lto_lto_id is 'Armazena o id do leito';
            comment on column agh.ain_calculo_paciente_dia.tmi_seq is 'Armazena o tipo de movimentação da internação';
    exception
            when others then
                raise notice 'Erro na criação da tabela ''agh.ain_calculo_paciente_dia'' - % %', sqlerrm, sqlstate;
    end;
    else raise info 'Tabela agh.ain_calculo_paciente_dia já existia';
        --end;
    end if;

    if not exists(select 1 from information_schema.table_constraints where constraint_schema = 'agh' and constraint_name = 'int_seq') then
       alter table agh.ain_calculo_paciente_dia add constraint int_seq foreign key(int_seq) references agh.ain_internacoes(seq);
    end if;
    
end $$;