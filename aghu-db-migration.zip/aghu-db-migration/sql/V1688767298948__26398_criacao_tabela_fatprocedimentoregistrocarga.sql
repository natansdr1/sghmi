DO $$
BEGIN

	if not exists (
			select 1 from information_schema.tables
			where table_schema = 'agh' and table_name = 'fat_procedimentos_registro_carga') then
		
		CREATE TABLE agh.fat_procedimentos_registro_carga (
			cod_procedimento int8 NULL,
			cod_registro varchar(2) NOT NULL,
			iph_pho_seq int2 NOT NULL,
			iph_seq int4 NOT null,
			CONSTRAINT fat_proced_registro_carga_pkey PRIMARY KEY (iph_pho_seq, iph_seq, cod_registro)
		);
		CREATE INDEX rproc_reg_fk_i ON agh.fat_procedimentos_registro_carga USING btree (cod_registro);
		
		
		ALTER TABLE agh.fat_procedimentos_registro_carga ADD CONSTRAINT fat_rproc_iph_fk 
			FOREIGN KEY (iph_pho_seq,iph_seq) REFERENCES agh.fat_itens_proced_hospitalar(pho_seq,seq);
		ALTER TABLE agh.fat_procedimentos_registro_carga ADD CONSTRAINT rproc_reg_fk 
			FOREIGN KEY (cod_registro) REFERENCES agh.fat_registros(codigo);
		
		comment on table agh.fat_procedimentos_registro_carga is 'tabela criada para armazenar a ultima carga do SIGTAP vinculado a fat_registro';
		comment on column agh.fat_procedimentos_registro_carga.cod_procedimento is 'codigo do procedimento';
		comment on column agh.fat_procedimentos_registro_carga.cod_registro is 'fk oriundo fat_registros.codigo';
		comment on column agh.fat_procedimentos_registro_carga.iph_pho_seq is 'fk oriundo fat_itens_proced_hospitalar.iph_pho_seq';
		comment on column agh.fat_procedimentos_registro_carga.iph_seq is 'fk oriundo fat_itens_proced_hospitalar.iph_seq';

		GRANT INSERT, SELECT, UPDATE, DELETE ON TABLE agh.fat_procedimentos_registro_carga TO acesso_completo;
		GRANT SELECT ON TABLE agh.fat_procedimentos_registro_carga TO acesso_leitura;

	end if;
end; $$