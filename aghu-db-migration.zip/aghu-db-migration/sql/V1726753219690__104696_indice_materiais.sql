do
$$
begin   
IF not EXISTS (select 1 from pg_indexes ix where ix.schemaname = 'agh' and tablename = 'sce_movimento_materiais' and indexname = 'sce_movimento_materiais_i_3') THEN
  CREATE INDEX sce_movimento_materiais_i_3 ON agh.sce_movimento_materiais USING btree (extract('day' from dt_competencia)) tablespace tblspc_idx;
   RAISE NOTICE 'Indice agh.sce_movimento_materiais.sce_movimento_materiais_i_3 criado com sucesso.';
else
   RAISE NOTICE 'Indice já existe agh.sce_movimento_materiais.sce_movimento_materiais_i_3 nada foi feito.';	
END IF;
end;
$$
LANGUAGE plpgsql;