DO $$
BEGIN

	if exists (
			select 1 from information_schema.tables
			where table_schema = 'agh' and table_name = 'fat_procedimentos_registro_carga') then
			
		grant insert, select, update, delete on agh.fat_procedimentos_registro_carga to acesso_completo;
		grant select on agh.fat_procedimentos_registro_carga to acesso_leitura;
		grant insert, select, update, delete on agh.fat_procedimentos_registro_carga to escrita_integra;
	end if;
end; $$