DO $$
BEGIN

if not exists (
			select 1 from information_schema.columns
			where table_schema = 'agh' and table_name = 'ael_solicitacao_exames' and column_name = 'agh_cid_solicitacao_seq') then begin
alter table agh.ael_solicitacao_exames add agh_cid_solicitacao_seq integer null;
raise notice 'Coluna agh_cid_solicitacao_seq integer criada na tabela agh.ael_solicitacao_exames';
alter table agh.ael_solicitacao_exames add constraint ael_soe_agh_cid_fk foreign key (agh_cid_solicitacao_seq)
references agh.agh_cids (seq) match SIMPLE on update no action on delete no action;
raise notice 'Foreign key ael_soe_agh_cid_fk criada na tabela agh.ael_solicitacao_exames.';

update agh.ael_solicitacao_exames set agh_cid_solicitacao_seq = 1 where agh_cid_solicitacao_seq is null;
raise notice 'Coluna agh_cid_solicitacao_seq na tabela agh.ael_solicitacao_exames setada para valor 1.';

alter table agh.ael_solicitacao_exames alter column agh_cid_solicitacao_seq set not null;
raise notice 'Coluna agh_cid_solicitacao_seq na tabela agh.ael_solicitacao_exames setada para not null.';

exception
			when others then
				raise info 'Error Name:%', sqlerrm;
				raise info 'Error State:%', sqlstate;
end;
end if;

if not exists (
			select 1 from information_schema.columns
			where table_schema = 'agh' and table_name = 'ael_solicitacao_exames' and column_name = 'agh_cid_laudo_seq') then begin
alter table agh.ael_solicitacao_exames add agh_cid_laudo_seq integer null;
raise notice 'Coluna agh_cid_laudo_seq integer criada na tabela agh.ael_solicitacao_exames';
alter table agh.ael_solicitacao_exames add constraint ael_soe_agh_cid_laudo_fk foreign key (agh_cid_laudo_seq)
references agh.agh_cids (seq) match SIMPLE on update no action on delete no action;
raise notice 'Foreign key ael_soe_agh_cid_laudo_fk criada na tabela agh.ael_solicitacao_exames.';
exception
			when others then
				raise info 'Error Name:%', sqlerrm;
				raise info 'Error State:%', sqlstate;
end;
end if;

if not exists (
			select 1 from information_schema.columns
			where table_schema = 'agh' and table_name = 'ael_solicitacao_exames' and column_name = 'imprimir_cid_diagnostica') then begin
alter table agh.ael_solicitacao_exames add imprimir_cid_diagnostica character varying(1) COLLATE pg_catalog."default" null;
raise notice 'Coluna imprimir_cid_diagnostica character varying(1) criada na tabela agh.ael_solicitacao_exames';
exception
			when others then
				raise info 'Error Name:%', sqlerrm;
				raise info 'Error State:%', sqlstate;
end;
end if;

END $$