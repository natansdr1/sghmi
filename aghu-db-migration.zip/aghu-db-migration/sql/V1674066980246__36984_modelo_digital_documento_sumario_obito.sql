do $$
begin
	raise notice 'Iniciando execução do script.';
begin
INSERT INTO agh.agh_documentos_certificados (seq, nome, dthr_edicao, identificador, tipo, ind_situacao, version, ind_impressao_automatica) VALUES (nextval('agh.AGH_DCE_SQ1'), '/thymeleaf/documento_sumario_obito.html', now(), 'ATD_SEQ', 'SUM_OBT', 'I', 0, 'N');
exception
		when others then
		raise notice 'Registro já existe. Ignorando.';
end;
	raise notice 'Fim da execução do script.';
end $$;
