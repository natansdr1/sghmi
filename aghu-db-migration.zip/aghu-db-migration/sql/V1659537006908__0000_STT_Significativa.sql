do
$do$
declare
nome_coluna varchar(128) := null;
	tipo_coluna varchar(50) := null; 
	tamanho_coluna decimal(5) := null;
begin
	raise notice 'Iniciando a execução do script.';
	if not exists (
			select 1 from information_schema.columns a where a.table_schema = 'agh' and a.table_name = 'aac_grade_agendamen_consultas'
				and a.column_name = 'ind_stt') then begin
alter table agh.aac_grade_agendamen_consultas add ind_stt char(1) not null default 'N';
raise notice 'Coluna ind_stt criada na tabela agh.aac_grade_agendamen_consultas com sucesso.';
exception
				when others then 
					raise notice 'Erro na criação da coluna ind_stt criada na tabela agh.aac_grade_agendamen_consultas.';
					raise info 'Error Name:%', sqlerrm;
					raise info 'Error State:%', sqlstate;
end;
else
select a.column_name, a.data_type, a.character_maximum_length
into nome_coluna, tipo_coluna, tamanho_coluna
from information_schema.columns a
where a.table_schema = 'agh' and a.table_name = 'aac_grade_agendamen_consultas' and a.column_name = 'ind_stt';
if(nome_coluna is not null and (tipo_coluna != 'character' or tamanho_coluna != 1)) then begin
alter table agh.aac_grade_agendamen_consultas alter column ind_stt type char(1);
alter table agh.aac_grade_agendamen_consultas alter column ind_stt set default 'N';
alter table agh.aac_grade_agendamen_consultas alter column ind_stt set not null;
raise notice 'A coluna ind_stt da tabela aac_grade_agendamen_consultas já existia e foi alterada.';
exception
				when others then
					raise info 'Error Name:%', sqlerrm;
					raise info 'Error State:%', sqlstate;
end;
end if;
end if;

	if not exists (select 1 from information_schema.sequences where sequence_schema = 'agh' and sequence_name = 'aac_stt_sq1') then
create sequence agh.aac_stt_sq1 increment 1 minvalue 1 maxvalue 9223372036854775807 start 1 cache 1;
end if;

create table if not exists agh.aac_stt (
    id int4 default nextval('agh.aac_stt_sq1') primary key,
    numero_consulta int not null,
    id_stt varchar(255) not null,
    data_criacao timestamptz not null,
    token_paciente text not null,
    token_atendente text not null
    );

if not exists (
			select 1 from information_schema.columns
			where table_schema = 'agh' and table_name = 'aac_consultas' and column_name = 'id_stt') then begin
alter table agh.aac_consultas add id_stt int4 null;
raise notice 'Coluna id_stt int 4 criada na tabela agh.aac_consultas';
alter table agh.aac_consultas add constraint aac_consultas_stt_fk foreign key(id_stt) references agh.aac_stt(id) on delete cascade;
raise notice 'Foreign key aac_consultas_stt_fk criada na tabela agh.aac_consultas.';
exception
			when others then
				raise info 'Error Name:%', sqlerrm;
				raise info 'Error State:%', sqlstate;
end;
end if;

begin
		grant all on agh.aac_stt to ugen_aghu;
		grant all on sequence agh.aac_stt_sq1 to ugen_aghu;
		--Grants sugeridos pelo Diego
		grant all on schema agh to acesso_completo;
		grant all privileges on all tables in schema agh to acesso_completo;
		grant all privileges on all sequences in schema agh to acesso_completo;
		grant all on schema casca to acesso_completo;
		grant all privileges on all tables in schema casca to acesso_completo;
		grant all privileges on all sequences in schema casca to acesso_completo;
		raise notice 'Grants concedidos na tabela agh.aac_stt para o usuário ugen_aghu';
		raise notice 'Grants concedidos na sequence agh.aac_stt_sq1 para o usuário ugen_aghu';
exception
		when others then
			raise info 'Error Name:%', sqlerrm;
			raise info 'Error State:%', sqlstate;
end;
		
	raise notice 'Fim da execução do script.';
end
$do$
