DO $$
BEGIN

    IF not exists(SELECT null
    FROM information_schema.columns
    WHERE table_name = 'agh_versoes_documentos' and column_name = 'hash_signature' and table_schema = 'agh') then
        ALTER TABLE agh.agh_versoes_documentos add hash_signature varchar(512);
    END IF;

END $$