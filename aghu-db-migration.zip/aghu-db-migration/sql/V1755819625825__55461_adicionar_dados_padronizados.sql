DO $$
BEGIN

    -- Verifica se a coluna 'padronizado' existe
    IF NOT EXISTS (
            SELECT 1 FROM information_schema.columns
            WHERE table_schema = 'agh'
              AND table_name = 'mbc_motivo_cancelamentos'
              AND column_name = 'padronizado'
        ) THEN
            ALTER TABLE agh.mbc_motivo_cancelamentos ADD COLUMN padronizado varchar(1) DEFAULT 'N';
    END IF;

    -- Ajusta a sequence para continuar a partir do maior ID existente
    PERFORM setval('AGH.MBC_MTC_SQ1',(SELECT COALESCE(MAX(seq), 0) FROM AGH.mbc_motivo_cancelamentos) + 1,false);

    -- Paciente Não Compareceu
    IF NOT EXISTS (SELECT 1 FROM agh.mbc_motivo_cancelamentos mc WHERE mc.descricao = 'Paciente Não Compareceu') THEN
        BEGIN

            INSERT INTO agh.mbc_motivo_cancelamentos(seq, ser_matricula, ser_vin_codigo, descricao, situacao, criado_em,
                                                     ind_erro_agend, ind_dest_sr, tipo, "version", padronizado)
                VALUES (nextval('AGH.MBC_MTC_SQ1'), 9999999, 955, 'Paciente Não Compareceu', 'I', now(), 'N', 'S', 'P', 0, 'S');
                RAISE NOTICE 'Insert com descrição "Paciente Não Compareceu" realizado com sucesso.';
            EXCEPTION
            WHEN OTHERS THEN
                RAISE NOTICE 'Erro no insert com descrição "Paciente": %', SQLERRM;
            END;
        ELSE
                RAISE NOTICE 'Registro com descrição "Paciente" já existe. Nenhum insert foi realizado.';
    END IF;

    -- Condições Clínicas desfavoráveis
    IF NOT EXISTS (SELECT 1 FROM agh.mbc_motivo_cancelamentos mc WHERE mc.descricao = 'Condições Clínicas desfavoráveis') THEN
        BEGIN

            INSERT INTO agh.mbc_motivo_cancelamentos(seq, ser_matricula, ser_vin_codigo, descricao, situacao, criado_em,
                                                     ind_erro_agend, ind_dest_sr, tipo, "version", padronizado)
                VALUES (nextval('AGH.MBC_MTC_SQ1'), 9999999, 955, 'Condições Clínicas desfavoráveis', 'I', now(), 'N', 'S', 'P', 0, 'S');
                RAISE NOTICE 'Insert com descrição "Condições Clínicas desfavoráveis" realizado com sucesso.';
            EXCEPTION
            WHEN OTHERS THEN
                RAISE NOTICE 'Erro no insert com descrição "Condições Clínicas desfavoráveis": %', SQLERRM;
        END;
    ELSE
                RAISE NOTICE 'Registro com descrição "Condições Clínicas desfavoráveis" já existe. Nenhum insert foi realizado.';
    END IF;

    -- Cirurgia Recusada
    IF NOT EXISTS (SELECT 1 FROM agh.mbc_motivo_cancelamentos mc WHERE mc.descricao = 'Cirurgia Recusada') THEN
        BEGIN

            INSERT INTO agh.mbc_motivo_cancelamentos(seq, ser_matricula, ser_vin_codigo, descricao, situacao, criado_em,
                                                     ind_erro_agend, ind_dest_sr, tipo, "version", padronizado)
            VALUES (nextval('AGH.MBC_MTC_SQ1'), 9999999, 955, 'Cirurgia Recusada', 'I', now(), 'N', 'S', 'P', 0, 'S');
            RAISE NOTICE 'Insert com descrição "Cirurgia Recusada" realizado com sucesso.';
            EXCEPTION
            WHEN OTHERS THEN
                RAISE NOTICE 'Erro no insert com descrição "Cirurgia Recusada": %', SQLERRM;
        END;
    ELSE
                RAISE NOTICE 'Registro com descrição "Cirurgia Recusada" já existe. Nenhum insert foi realizado.';
    END IF;

    -- Óbito
    IF NOT EXISTS (SELECT 1 FROM agh.mbc_motivo_cancelamentos mc WHERE mc.descricao = 'Óbito') THEN
        BEGIN

            INSERT INTO agh.mbc_motivo_cancelamentos(seq, ser_matricula, ser_vin_codigo, descricao, situacao, criado_em,
                                                     ind_erro_agend, ind_dest_sr, tipo, "version", padronizado)
            VALUES (nextval('AGH.MBC_MTC_SQ1'), 9999999, 955, 'Óbito', 'I', now(), 'N', 'S', 'P', 0, 'S');
            RAISE NOTICE 'Insert com descrição "Óbito" realizado com sucesso.';
            EXCEPTION
            WHEN OTHERS THEN
                RAISE NOTICE 'Erro no insert com descrição "Óbito": %', SQLERRM;
        END;
    ELSE
                RAISE NOTICE 'Registro com descrição "Óbito" já existe. Nenhum insert foi realizado.';
    END IF;

    -- Problemas de Programação Cirúrgica
    IF NOT EXISTS (SELECT 1 FROM agh.mbc_motivo_cancelamentos mc WHERE mc.descricao = 'Problemas de Programação Cirúrgica') THEN
        BEGIN

            INSERT INTO agh.mbc_motivo_cancelamentos(seq, ser_matricula, ser_vin_codigo, descricao, situacao, criado_em,
                                                     ind_erro_agend, ind_dest_sr, tipo, "version", padronizado)
            VALUES (nextval('AGH.MBC_MTC_SQ1'), 9999999, 955, 'Problemas de Programação Cirúrgica', 'I', now(), 'N', 'S','T', 0, 'S');
            RAISE NOTICE 'Insert com descrição "Problemas de Programação Cirúrgica" realizado com sucesso.';
            EXCEPTION
            WHEN OTHERS THEN
                RAISE NOTICE 'Erro no insert com descrição "Problemas de Programação Cirúrgica": %', SQLERRM;
        END;
    ELSE
                RAISE NOTICE 'Registro com descrição "Problemas de Programação Cirúrgica" já existe. Nenhum insert foi realizado.';
    END IF;

    -- Mudança de Conduta Clínica
    IF NOT EXISTS (SELECT 1 FROM agh.mbc_motivo_cancelamentos mc WHERE mc.descricao = 'Mudança de Conduta Clínica') THEN
        BEGIN

            INSERT INTO agh.mbc_motivo_cancelamentos(seq, ser_matricula, ser_vin_codigo, descricao, situacao, criado_em,
                                                     ind_erro_agend, ind_dest_sr, tipo, "version", padronizado)
            VALUES (nextval('AGH.MBC_MTC_SQ1'), 9999999, 955, 'Mudança de Conduta Clínica', 'I', now(), 'N', 'S','T', 0, 'S');
            RAISE NOTICE 'Insert com descrição "Mudança de Conduta Clínica" realizado com sucesso.';
            EXCEPTION WHEN OTHERS THEN
               RAISE NOTICE 'Erro no insert com descrição "Mudança de Conduta Clínica": %', SQLERRM;
        END;
    ELSE
            RAISE NOTICE 'Registro com descrição "Mudança de Conduta Clínica" já existe. Nenhum insert foi realizado.';
    END IF;

    -- Documentação Clínica Inadequada
    IF NOT EXISTS (SELECT 1 FROM agh.mbc_motivo_cancelamentos mc WHERE mc.descricao = 'Documentação Clínica Inadequada') THEN
        BEGIN

            INSERT INTO agh.mbc_motivo_cancelamentos(seq, ser_matricula, ser_vin_codigo, descricao, situacao, criado_em,
                                                     ind_erro_agend, ind_dest_sr, tipo, "version", padronizado)
            VALUES (nextval('AGH.MBC_MTC_SQ1'), 9999999, 955, 'Documentação Clínica Inadequada', 'I', now(), 'N', 'S','T', 0, 'S');
            RAISE NOTICE 'Insert com descrição "Documentação Clínica Inadequada" realizado com sucesso.';
            EXCEPTION WHEN OTHERS THEN
              RAISE NOTICE 'Erro no insert com descrição "Documentação Clínica Inadequada": %', SQLERRM;
        END;
    ELSE
            RAISE NOTICE 'Registro com descrição "Documentação Clínica Inadequada" já existe. Nenhum insert foi realizado.';
    END IF;

    -- Falha nas Ações Pré-operatórias
    IF NOT EXISTS (SELECT 1 FROM agh.mbc_motivo_cancelamentos mc WHERE mc.descricao = 'Falha nas Ações Pré-operatórias') THEN
        BEGIN

            INSERT INTO agh.mbc_motivo_cancelamentos(seq, ser_matricula, ser_vin_codigo, descricao, situacao, criado_em,
                                                     ind_erro_agend, ind_dest_sr, tipo, "version", padronizado)
            VALUES (nextval('AGH.MBC_MTC_SQ1'), 9999999, 955, 'Falha nas Ações Pré-operatórias', 'I', now(), 'N', 'S','T', 0, 'S');
            RAISE NOTICE 'Insert com descrição "Falha nas Ações Pré-operatórias" realizado com sucesso.';
            EXCEPTION WHEN OTHERS THEN
               RAISE NOTICE 'Erro no insert com descrição "Falha nas Ações Pré-operatórias": %', SQLERRM;
        END;
    ELSE
            RAISE NOTICE 'Registro com descrição "Falha nas Ações Pré-operatórias" já existe. Nenhum insert foi realizado.';
    END IF;

    -- Leito Pós-operatório Indisponível
    IF NOT EXISTS (SELECT 1 FROM agh.mbc_motivo_cancelamentos mc WHERE mc.descricao = 'Leito Pós-operatório Indisponível') THEN
        BEGIN

            INSERT INTO agh.mbc_motivo_cancelamentos(seq, ser_matricula, ser_vin_codigo, descricao, situacao, criado_em,
                                                     ind_erro_agend, ind_dest_sr, tipo, "version", padronizado)
            VALUES (nextval('AGH.MBC_MTC_SQ1'), 9999999, 955, 'Leito Pós-operatório Indisponível', 'I', now(), 'N', 'S','T', 0, 'S');
            RAISE NOTICE 'Insert com descrição "Leito Pós-operatório Indisponível" realizado com sucesso.';
            EXCEPTION WHEN OTHERS THEN
               RAISE NOTICE 'Erro no insert com descrição "Leito Pós-operatório Indisponível": %', SQLERRM;
        END;
    ELSE
            RAISE NOTICE 'Registro com descrição "Leito Pós-operatório Indisponível" já existe. Nenhum insert foi realizado.';
    END IF;

    -- Problemas na Sala Operatória
    IF NOT EXISTS (SELECT 1 FROM agh.mbc_motivo_cancelamentos mc WHERE mc.descricao = 'Problemas na Sala Operatória') THEN
        BEGIN

            INSERT INTO agh.mbc_motivo_cancelamentos(seq, ser_matricula, ser_vin_codigo, descricao, situacao, criado_em,
                                                     ind_erro_agend, ind_dest_sr, tipo, "version", padronizado)
            VALUES (nextval('AGH.MBC_MTC_SQ1'), 9999999, 955, 'Problemas na Sala Operatória', 'I', now(), 'N', 'S','T', 0, 'S');
            RAISE NOTICE 'Insert com descrição "Problemas na Sala Operatória" realizado com sucesso.';
            EXCEPTION WHEN OTHERS THEN
             RAISE NOTICE 'Erro no insert com descrição "Problemas na Sala Operatória": %', SQLERRM;
        END;
    ELSE
            RAISE NOTICE 'Registro com descrição "Problemas na Sala Operatória" já existe. Nenhum insert foi realizado.';
    END IF;

    -- Falta de Pessoal de Enfermagem
    IF NOT EXISTS (SELECT 1 FROM agh.mbc_motivo_cancelamentos mc WHERE mc.descricao = 'Falta de Pessoal de Enfermagem') THEN
        BEGIN

            INSERT INTO agh.mbc_motivo_cancelamentos(seq, ser_matricula, ser_vin_codigo, descricao, situacao, criado_em,
                                                     ind_erro_agend, ind_dest_sr, tipo, "version", padronizado)
            VALUES (nextval('AGH.MBC_MTC_SQ1'), 9999999, 955, 'Falta de Pessoal de Enfermagem', 'I', now(), 'N', 'S','F', 0, 'S');
            RAISE NOTICE 'Insert com descrição "Falta de Pessoal de Enfermagem" realizado com sucesso.';
            EXCEPTION WHEN OTHERS THEN
              RAISE NOTICE 'Erro no insert com descrição "Falta de Pessoal de Enfermagem": %', SQLERRM;
        END;
    ELSE
            RAISE NOTICE 'Registro com descrição "Falta de Pessoal de Enfermagem" já existe. Nenhum insert foi realizado.';
    END IF;

    -- Falta de Anestesista
    IF NOT EXISTS (SELECT 1 FROM agh.mbc_motivo_cancelamentos mc WHERE mc.descricao = 'Falta de Anestesista') THEN
        BEGIN

            INSERT INTO agh.mbc_motivo_cancelamentos(seq, ser_matricula, ser_vin_codigo, descricao, situacao, criado_em,
                                                     ind_erro_agend, ind_dest_sr, tipo, "version", padronizado)
            VALUES (nextval('AGH.MBC_MTC_SQ1'), 9999999, 955, 'Falta de Anestesista', 'I', now(), 'N', 'S','F', 0, 'S');
            RAISE NOTICE 'Insert com descrição "Falta de Anestesista" realizado com sucesso.';
            EXCEPTION WHEN OTHERS THEN
               RAISE NOTICE 'Erro no insert com descrição "Falta de Anestesista": %', SQLERRM;
        END;
    ELSE
            RAISE NOTICE 'Registro com descrição "Falta de Anestesista" já existe. Nenhum insert foi realizado.';
    END IF;

    -- Falta de Cirurgião
    IF NOT EXISTS (SELECT 1 FROM agh.mbc_motivo_cancelamentos mc WHERE mc.descricao = 'Falta de Cirurgião') THEN
        BEGIN

            INSERT INTO agh.mbc_motivo_cancelamentos(seq, ser_matricula, ser_vin_codigo, descricao, situacao, criado_em,
                                                     ind_erro_agend, ind_dest_sr, tipo, "version", padronizado)
            VALUES (nextval('AGH.MBC_MTC_SQ1'), 9999999, 955, 'Falta de Cirurgião', 'I', now(), 'N', 'S','F', 0, 'S');
            RAISE NOTICE 'Insert com descrição "Falta de Cirurgião" realizado com sucesso.';
            EXCEPTION WHEN OTHERS THEN
              RAISE NOTICE 'Erro no insert com descrição "Falta de Cirurgião": %', SQLERRM;
        END;
    ELSE
            RAISE NOTICE 'Registro com descrição "Falta de Cirurgião" já existe. Nenhum insert foi realizado.';
    END IF;

    -- Falta de Instrumentador
    IF NOT EXISTS (SELECT 1 FROM agh.mbc_motivo_cancelamentos mc WHERE mc.descricao = 'Falta de Instrumentador') THEN
        BEGIN

            INSERT INTO agh.mbc_motivo_cancelamentos(seq, ser_matricula, ser_vin_codigo, descricao, situacao, criado_em,
                                                     ind_erro_agend, ind_dest_sr, tipo, "version", padronizado)
            VALUES (nextval('AGH.MBC_MTC_SQ1'), 9999999, 955, 'Falta de Instrumentador', 'I', now(), 'N', 'S','F', 0, 'S');
            RAISE NOTICE 'Insert com descrição "Falta de Instrumentador" realizado com sucesso.';
            EXCEPTION WHEN OTHERS THEN
              RAISE NOTICE 'Erro no insert com descrição "Falta de Instrumentador": %', SQLERRM;
        END;
    ELSE
            RAISE NOTICE 'Registro com descrição "Falta de Instrumentador" já existe. Nenhum insert foi realizado.';
    END IF;

    -- Falta de Outros Profissionais
    IF NOT EXISTS (SELECT 1 FROM agh.mbc_motivo_cancelamentos mc WHERE mc.descricao = 'Falta de Outros Profissionais') THEN
        BEGIN

            INSERT INTO agh.mbc_motivo_cancelamentos(seq, ser_matricula, ser_vin_codigo, descricao, situacao, criado_em,
                                                     ind_erro_agend, ind_dest_sr, tipo, "version", padronizado)
            VALUES (nextval('AGH.MBC_MTC_SQ1'), 9999999, 955, 'Falta de Outros Profissionais', 'I', now(), 'N', 'S','F', 0, 'S');
            RAISE NOTICE 'Insert com descrição "Falta de Outros Profissionais" realizado com sucesso.';
            EXCEPTION WHEN OTHERS THEN
              RAISE NOTICE 'Erro no insert com descrição "Falta de Outros Profissionais": %', SQLERRM;
        END;
    ELSE
            RAISE NOTICE 'Registro com descrição "Falta de Outros Profissionais" já existe. Nenhum insert foi realizado.';
    END IF;

    -- Falta de Medicamentos
    IF NOT EXISTS (SELECT 1 FROM agh.mbc_motivo_cancelamentos mc WHERE mc.descricao = 'Falta de Medicamentos') THEN
        BEGIN

            INSERT INTO agh.mbc_motivo_cancelamentos(seq, ser_matricula, ser_vin_codigo, descricao, situacao, criado_em,
                                                     ind_erro_agend, ind_dest_sr, tipo, "version", padronizado)
            VALUES (nextval('AGH.MBC_MTC_SQ1'), 9999999, 955, 'Falta de Medicamentos', 'I', now(), 'N', 'S','M', 0, 'S');
            RAISE NOTICE 'Insert com descrição "Falta de Medicamentos" realizado com sucesso.';
            EXCEPTION WHEN OTHERS THEN
              RAISE NOTICE 'Erro no insert com descrição "Falta de Medicamentos": %', SQLERRM;
        END;
    ELSE
            RAISE NOTICE 'Registro com descrição "Falta de Medicamentos" já existe. Nenhum insert foi realizado.';
    END IF;

    -- Falta de Material de Consumo
    IF NOT EXISTS (SELECT 1 FROM agh.mbc_motivo_cancelamentos mc WHERE mc.descricao = 'Falta de Material de Consumo') THEN
        BEGIN

            INSERT INTO agh.mbc_motivo_cancelamentos(seq, ser_matricula, ser_vin_codigo, descricao, situacao, criado_em,
                                                     ind_erro_agend, ind_dest_sr, tipo, "version", padronizado)
            VALUES (nextval('AGH.MBC_MTC_SQ1'), 9999999, 955, 'Falta de Material de Consumo', 'I', now(), 'N', 'S','M', 0, 'S');
            RAISE NOTICE 'Insert com descrição "Falta de Material de Consumo" realizado com sucesso.';
            EXCEPTION WHEN OTHERS THEN
              RAISE NOTICE 'Erro no insert com descrição "Falta de Material de Consumo": %', SQLERRM;
        END;
    ELSE
            RAISE NOTICE 'Registro com descrição "Falta de Material de Consumo" já existe. Nenhum insert foi realizado.';
    END IF;

    -- Problemas Com Equipamentos
    IF NOT EXISTS (SELECT 1 FROM agh.mbc_motivo_cancelamentos mc WHERE mc.descricao = 'Problemas Com Equipamentos') THEN
        BEGIN

            INSERT INTO agh.mbc_motivo_cancelamentos(seq, ser_matricula, ser_vin_codigo, descricao, situacao, criado_em,
                                                     ind_erro_agend, ind_dest_sr, tipo, "version", padronizado)
            VALUES (nextval('AGH.MBC_MTC_SQ1'), 9999999, 955, 'Problemas Com Equipamentos', 'I', now(), 'N', 'S','M', 0, 'S');
            RAISE NOTICE 'Insert com descrição "Problemas Com Equipamentos" realizado com sucesso.';
            EXCEPTION WHEN OTHERS THEN
                RAISE NOTICE 'Erro no insert com descrição "Problemas Com Equipamentos": %', SQLERRM;
        END;
    ELSE
            RAISE NOTICE 'Registro com descrição "Problemas Com Equipamentos" já existe. Nenhum insert foi realizado.';
    END IF;

    -- Falta de Hemoderivados, tecidos ou órgãos
    IF NOT EXISTS (SELECT 1 FROM agh.mbc_motivo_cancelamentos mc WHERE mc.descricao = 'Falta de Hemoderivados, tecidos ou órgãos') THEN
        BEGIN

            INSERT INTO agh.mbc_motivo_cancelamentos(seq, ser_matricula, ser_vin_codigo, descricao, situacao, criado_em,
                                                     ind_erro_agend, ind_dest_sr, tipo, "version", padronizado)
            VALUES (nextval('AGH.MBC_MTC_SQ1'), 9999999, 955, 'Falta de Hemoderivados, tecidos ou órgãos', 'I', now(), 'N', 'S','M', 0, 'S');
            RAISE NOTICE 'Insert com descrição "Falta de Hemoderivados, tecidos ou órgãos" realizado com sucesso.';
            EXCEPTION WHEN OTHERS THEN
               RAISE NOTICE 'Erro no insert com descrição "Falta de Hemoderivados, tecidos ou órgãos": %', SQLERRM;
        END;
    ELSE
            RAISE NOTICE 'Registro com descrição "Falta de Hemoderivados, tecidos ou órgãos" já existe. Nenhum insert foi realizado.';
    END IF;

    -- Falta de OPME
    IF NOT EXISTS (SELECT 1 FROM agh.mbc_motivo_cancelamentos mc WHERE mc.descricao = 'Falta de OPME') THEN
        BEGIN

            INSERT INTO agh.mbc_motivo_cancelamentos(seq, ser_matricula, ser_vin_codigo, descricao, situacao, criado_em,
                                                     ind_erro_agend, ind_dest_sr, tipo, "version", padronizado)
            VALUES (nextval('AGH.MBC_MTC_SQ1'), 9999999, 955, 'Falta de OPME', 'I', now(), 'N', 'S','M', 0, 'S');
            RAISE NOTICE 'Insert com descrição "Falta de OPME" realizado com sucesso.';
            EXCEPTION WHEN OTHERS THEN
               RAISE NOTICE 'Erro no insert com descrição "Falta de OPME": %', SQLERRM;
        END;
    ELSE
            RAISE NOTICE 'Registro com descrição "Falta de OPME" já existe. Nenhum insert foi realizado.';
    END IF;

    -- Falta de Rouparia
    IF NOT EXISTS (SELECT 1 FROM agh.mbc_motivo_cancelamentos mc WHERE mc.descricao = 'Falta de Rouparia') THEN
        BEGIN

            INSERT INTO agh.mbc_motivo_cancelamentos(seq, ser_matricula, ser_vin_codigo, descricao, situacao, criado_em,
                                                     ind_erro_agend, ind_dest_sr, tipo, "version", padronizado)
            VALUES (nextval('AGH.MBC_MTC_SQ1'), 9999999, 955, 'Falta de Rouparia', 'I', now(), 'N', 'S','M', 0, 'S');
            RAISE NOTICE 'Insert com descrição "Falta de Rouparia" realizado com sucesso.';
            EXCEPTION WHEN OTHERS THEN
                RAISE NOTICE 'Erro no insert com descrição "Falta de Rouparia": %', SQLERRM;
        END;
    ELSE
            RAISE NOTICE 'Registro com descrição "Falta de Rouparia" já existe. Nenhum insert foi realizado.';
    END IF;

    -- Falta de Instrumental
    IF NOT EXISTS (SELECT 1 FROM agh.mbc_motivo_cancelamentos mc WHERE mc.descricao = 'Falta de Instrumental') THEN
        BEGIN

            INSERT INTO agh.mbc_motivo_cancelamentos(seq, ser_matricula, ser_vin_codigo, descricao, situacao, criado_em,
                                                     ind_erro_agend, ind_dest_sr, tipo, "version", padronizado)
            VALUES (nextval('AGH.MBC_MTC_SQ1'), 9999999, 955, 'Falta de Instrumental', 'I', now(), 'N', 'S','M', 0, 'S');
            RAISE NOTICE 'Insert com descrição "Falta de Instrumental" realizado com sucesso.';
            EXCEPTION WHEN OTHERS THEN
                RAISE NOTICE 'Erro no insert com descrição "Falta de Instrumental": %', SQLERRM;
        END;
    ELSE
            RAISE NOTICE 'Registro com descrição "Falta de Instrumental" já existe. Nenhum insert foi realizado.';
    END IF;

END
$$;


