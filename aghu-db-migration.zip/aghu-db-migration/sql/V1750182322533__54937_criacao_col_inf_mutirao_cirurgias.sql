DO $$
BEGIN

if not exists (
   select 1 from information_schema.columns
   where table_schema = 'agh' and table_name = 'mbc_cirurgias' and column_name = 'ind_mutirao') then begin
alter table agh.mbc_cirurgias add column ind_mutirao varchar(1), add constraint mbc_crg_ck25 check (ind_mutirao in ('S', 'N'));
raise notice 'Coluna ind_mutirao criada na tabela agh.mbc_cirurgias';
exception
   when others then
    raise info 'Error Name:%', sqlerrm;
    raise info 'Error State:%', sqlstate;
end;
else
  raise notice 'Coluna ind_mutirao já existente na tabela agh.mbc_cirurgias. Nada Feito';
end if;

if not exists (
   select 1 from information_schema.columns
   where table_schema = 'agh' and table_name = 'mbc_agendas' and column_name = 'ind_mutirao') then begin
alter table agh.mbc_agendas add column ind_mutirao varchar(1), add constraint mbc_age_ck25 check (ind_mutirao in ('S', 'N'));
raise notice 'Coluna ind_mutirao criada na tabela agh.mbc_agendas';
exception
   when others then
    raise info 'Error Name:%', sqlerrm;
    raise info 'Error State:%', sqlstate;
end;
else
  raise notice 'Coluna ind_mutirao já existente na tabela agh.mbc_agendas. Nada Feito';
end if;

END $$