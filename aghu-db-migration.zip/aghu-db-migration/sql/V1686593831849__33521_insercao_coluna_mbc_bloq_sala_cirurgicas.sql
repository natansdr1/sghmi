DO $$
BEGIN

    IF NOT EXISTS(
            SELECT 1
            FROM information_schema.columns
            WHERE table_schema = 'agh'
                AND table_name = 'mbc_bloq_sala_cirurgicas'
                AND column_name = 'pre_esp_seq'
        ) THEN
    alter table agh.mbc_bloq_sala_cirurgicas add pre_esp_seq integer;
    END IF;

END $$