DO $$
BEGIN

    IF NOT EXISTS(
            SELECT 1
            FROM information_schema.columns
            WHERE table_schema = 'agh'
                AND table_name = 'mbc_agenda_procedimentos'
                AND column_name = 'proc_principal'
        ) THEN
        ALTER TABLE agh.mbc_agenda_procedimentos ADD COLUMN proc_principal bool NULL;
        COMMENT ON COLUMN agh.mbc_agenda_procedimentos.proc_principal IS 'Indica se é prodecimento principal ou não.';
        RAISE NOTICE 'Criação da Coluna: PROC_PRINCIPAL, na Tabela: agh.mbc_agenda_procedimentos #16988';
    END IF;

    IF NOT EXISTS(
            SELECT 1
            FROM information_schema.columns
            WHERE table_schema = 'agh'
                AND table_name = 'mbc_agenda_procedimentos'
                AND column_name = 'dpt_seq'
        ) THEN
        ALTER TABLE agh.mbc_agenda_procedimentos ADD COLUMN dpt_seq int4 NULL;
        COMMENT ON COLUMN agh.mbc_agenda_procedimentos.dpt_seq IS 'Referencia para tabela: agh.pdt_proc_diag_teraps';
        RAISE NOTICE 'Criação da Coluna: dpt_seq, na Tabela: agh.mbc_agenda_procedimentos #16988';
    END IF;
 

	if not exists (
			select 1 from information_schema.table_constraints tc    
			where tc.constraint_name = 'mbc_agenda_proced_dpt_seq_fk' 
			and tc.table_name='mbc_agenda_procedimentos' and tc.table_schema = 'agh') then begin

	alter table agh.mbc_agenda_procedimentos add CONSTRAINT mbc_agenda_proced_dpt_seq_fk 
	FOREIGN KEY (dpt_seq) REFERENCES agh.pdt_proc_diag_teraps(seq) 
	ON DELETE RESTRICT ON UPDATE RESTRICT DEFERRABLE;

	raise notice 'Foreign key mbc_agenda_proced_dpt_seq_fk criada na tabela agh.mbc_agenda_procedimentos.';

	CREATE INDEX mbc_agenda_proced_dpt_seq_fk_i
    ON agh.mbc_agenda_procedimentos USING btree
    (dpt_seq ASC NULLS LAST)
    TABLESPACE tblspc_idx;

	raise notice 'Indice mbc_agenda_proced_dpt_seq_fk_i criado na tabela agh.mbc_agenda_procedimentos.';

	exception
				when others then
					raise info 'Error Name:%', sqlerrm;
					raise info 'Error State:%', sqlstate;
	end;
	end if;
 
END $$