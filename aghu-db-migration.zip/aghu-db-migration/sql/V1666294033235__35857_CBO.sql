do
$do$
declare
record_count decimal(15);
begin
select count(1) into record_count from agh.fat_cbos where codigo = '000000';
if(record_count > 0) then
begin
update agh.fat_cbos set dt_fim = null where codigo = '000000';
raise notice 'Registro atualizado com sucesso';
exception
            when others then
                raise notice 'Erro na atualização do registro';
                   raise info 'Error Name:%', sqlerrm;
                raise info 'Error State:%', sqlstate;
end;
else
begin
insert into agh.fat_cbos (codigo, descricao, "version", seq, dt_inicio, dt_fim) values
    ('000000', 'NÃO SE APLICA', 0, nextval('agh.fat_cbo_seq'), '2019-08-20 00:00:00.000', null);
raise notice 'Registro inserido com sucesso';
exception
            when others then
                raise notice 'Erro na inserção do registro';
                raise info 'Error Name:%', sqlerrm;
                raise info 'Error State:%', sqlstate;
end;
end if;
end
$do$