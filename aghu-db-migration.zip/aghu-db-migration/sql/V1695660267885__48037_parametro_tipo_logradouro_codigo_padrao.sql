do $$
begin
	-- se p_definir_tipo_logradouro existir, atualiza para p_tipo_logradouro_cep_generico
    if exists(select 1 from agh.agh_parametros p where p.nome = 'P_DEFINIR_TIPO_LOGRADOURO') then
    	update agh.agh_parametros set 
    		nome = 'P_TIPO_LOGRADOURO_CEP_GENERICO',
            vlr_numerico = 81,
            descricao = 'Parâmetro responsável por apresentar no arquivo do faturamento, o código de logradouro “081”, correspondente ao logradouro do tipo “Rua”, caso seja identificado que no cadastro do paciente, foi informado um CEP genérico, ou seja, um CEP que não está vinculado a um logradouro. Tal situação pode ocorrer, quando o município de endereço do paciente, não possuir um CEP diferenciado para cada logradouro, então, utiliza-se o CEP dito genérico, seguido do sufixo “-000”',
            vlr_numerico_padrao = null,
            sis_sigla = 'FAT'
        where nome = 'P_DEFINIR_TIPO_LOGRADOURO';
        -- Caso contrário, insere um novo registro com P_TIPO_LOGRADOURO_CEP_GENERICO
        else if(not exists(select null from agh.agh_parametros where nome = 'P_TIPO_LOGRADOURO_CEP_GENERICO')) then
            insert into agh.agh_parametros(seq, sis_sigla, nome, mantem_historico, criado_em, criado_por, vlr_numerico, descricao, version, tipo_dado)
            values(nextval('agh.agh_psi_sq1'), 'FAT', 'P_TIPO_LOGRADOURO_CEP_GENERICO', 'S', '2023-09-27 11:11:24.004', 'AGHU', 81, 'Parâmetro responsável por apresentar no arquivo do faturamento, o código de logradouro “081”, correspondente ao logradouro do tipo “Rua”, caso seja identificado que no cadastro do paciente, foi informado um CEP genérico, ou seja, um CEP que não está vinculado a um logradouro. Tal situação pode ocorrer, quando o município de endereço do paciente, não possuir um CEP diferenciado para cada logradouro, então, utiliza-se o CEP dito genérico, seguido do sufixo “-000”', 1, 'N');
		end if;           
	end if;
end $$;
