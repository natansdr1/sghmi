do
$$


begin
    
 	raise notice 'Nada feito.';

exception
when others then
          raise notice 'OCORREU UM ERRO: %',sqlerrm;	
END;
$$