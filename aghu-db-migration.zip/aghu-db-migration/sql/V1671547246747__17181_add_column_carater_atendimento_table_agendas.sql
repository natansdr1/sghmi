DO
$$
    BEGIN

        IF NOT EXISTS(
                SELECT 1
                FROM information_schema.columns
                WHERE table_schema = 'agh'
                  AND table_name = 'mbc_agendas'
                  AND column_name = 'carater_atendimento'
            ) THEN
            ALTER TABLE agh.mbc_agendas
                ADD COLUMN carater_atendimento varchar(3);
            COMMENT ON COLUMN agh.mbc_agendas.carater_atendimento IS 'Indica o carater de atendimento podendo ser Eletiva, Urgência ou Emergência.';
            RAISE NOTICE 'EXECUTADO ALTERAÇÃO: #17181 - [Módulo Cirurgias/PDT] - Ajustes no Portal de Planejamento de Cirurgias/PDT';
        END IF;

    END
$$