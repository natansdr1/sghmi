DO $$
BEGIN

--Aumenta quantidade de caracteres pois existem nomes com mais de 100 caracteres
alter table agh.agh_documentos_certificados alter column nome type varchar(200) using nome::varchar(200);

--Remove check constraints
ALTER TABLE AGH.AGH_DOCUMENTOS_CERTIFICADOS DROP CONSTRAINT IF EXISTS agh_dce_ck1;
ALTER TABLE AGH.AGH_DOCUMENTOS DROP CONSTRAINT IF EXISTS agh_dok_ck1;

--Insere novo tipo de documento
IF not exists(select null from AGH.AGH_DOCUMENTOS_CERTIFICADOS where nome = 'br/gov/mec/aghu/prescricaoenfermagem/report/ItensPrescricaoEnfermagemConfirmadosPaisagem.jasper') then
    insert into AGH.AGH_DOCUMENTOS_CERTIFICADOS(seq, nome, dthr_edicao, identificador, tipo, ind_situacao, version, ind_impressao_automatica)
    values (nextval('AGH.AGH_DCE_SQ1'), 'br/gov/mec/aghu/prescricaoenfermagem/report/ItensPrescricaoEnfermagemConfirmadosPaisagem.jasper', now(), 'ATD_SEQ', 'PEN', 'A', 1, 'S');
END IF;

--Insere novo tipo de documento
IF not exists(select null from AGH.AGH_DOCUMENTOS_CERTIFICADOS where nome = 'br/gov/mec/aghu/prescricaoenfermagem/report/ItensPrescricaoEnfermagemConfirmados.jasper') then
    insert into AGH.AGH_DOCUMENTOS_CERTIFICADOS(seq, nome, dthr_edicao, identificador, tipo, ind_situacao, version, ind_impressao_automatica)
    values (nextval('AGH.AGH_DCE_SQ1'), 'br/gov/mec/aghu/prescricaoenfermagem/report/ItensPrescricaoEnfermagemConfirmados.jasper', now(), 'ATD_SEQ', 'PEN', 'A', 1, 'S');
END IF;

END $$