DO $$
    BEGIN

        if not exists(select 1
                       from information_schema.columns
                       where table_schema = 'agh'
                         and table_name = 'mbc_agendas'
                         and column_name = 'cid_seq'
                       ) then
                alter table agh.mbc_agendas
                    add cid_seq integer null;
                raise notice 'Coluna cid_seq integer criada na tabela agh.mbc_agendas';
                alter table agh.mbc_agendas
                    add constraint mbc_agp_agh_cid_fk1 foreign key (cid_seq)
                        references agh.agh_cids (seq) match SIMPLE on update no action on delete no action;
                raise notice 'Foreign key mbc_agp_agh_cid_fk1 criada na tabela agh.mbc_agendas.';
        end if;
END $$