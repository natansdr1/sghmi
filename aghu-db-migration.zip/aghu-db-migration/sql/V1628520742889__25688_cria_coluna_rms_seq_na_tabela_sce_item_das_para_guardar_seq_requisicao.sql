DO $$
BEGIN

	IF NOT EXISTS (
		SELECT
		FROM information_schema.columns
		WHERE table_schema = 'agh'
		AND table_name = 'sce_item_das'
		AND column_name = 'rms_seq'
	) THEN
ALTER TABLE agh.sce_item_das ADD COLUMN rms_seq bigint;
COMMENT ON COLUMN agh.sce_item_das.rms_seq IS 'Guardar o seq da requisiçao para ter referencia na devolução por lote quando a requisição de materiais já estiver efetivada e for feito o estorno';
	RAISE NOTICE 'EXECUTADO ALTERAÇÃO: #25688 - Novas coluna agh.sce_item_das';
END IF;

END $$