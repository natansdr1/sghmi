do
$do$
    declare
        record_count decimal(15);
    begin
        select count(1) into record_count from agh.fat_cbos where codigo = '000000';
        if (record_count > 0) then
            begin
                update agh.fat_cbos set dt_fim = null where codigo = '000000';
                raise notice 'Registro atualizado com sucesso';
            exception
                when others then raise notice 'Erro na atualização do registro';
                raise info 'Error Name:%', sqlerrm;
                raise info 'Error State:%', sqlstate;
            end;
        end if;
    end
$do$