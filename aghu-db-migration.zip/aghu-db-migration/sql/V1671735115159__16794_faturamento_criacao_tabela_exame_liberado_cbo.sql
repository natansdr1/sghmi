DO $$
BEGIN

if not exists (
			select 1 from information_schema.tables
			where table_schema = 'agh' and table_name = 'fat_exame_liberado_cbo') then begin
			
			
			
CREATE TABLE agh.fat_exame_liberado_cbo
(
    soe_seq integer NOT NULL,
    ise_seqp smallint NOT NULL,
	iph_pho_seq smallint NOT NULL,
    iph_seq integer NOT NULL,
	fat_cbos_liberacao_exame_seq integer NOT NULL,
	
    
    CONSTRAINT fat_exame_liberado_cbo_pkey PRIMARY KEY (soe_seq, ise_seqp, iph_pho_seq, iph_seq)
        USING INDEX TABLESPACE tblspc_idx,
    CONSTRAINT fat_elc_item_solicitacao_exames_fk FOREIGN KEY (soe_seq, ise_seqp)
        REFERENCES agh.ael_item_solicitacao_exames (soe_seq, seqp) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fat_elc_itens_proced_hospitalar_fk FOREIGN KEY (iph_pho_seq, iph_seq)
        REFERENCES agh.fat_itens_proced_hospitalar (pho_seq, seq) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
	CONSTRAINT fat_elc_fat_cbos_liberacao_exame_fk FOREIGN KEY (fat_cbos_liberacao_exame_seq)
        REFERENCES agh.fat_cbos (seq) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;
raise notice 'Tabela agh.fat_exame_liberado_cbo criada';

ALTER TABLE agh.fat_exame_liberado_cbo OWNER to postgres;
raise notice 'Tabela agh.fat_exame_liberado_cbo alterada o OWNER para postgres';

GRANT ALL ON TABLE agh.fat_exame_liberado_cbo TO acesso_completo;
raise notice 'Tabela agh.fat_exame_liberado_cbo GRANT ALL para acesso_completo';

GRANT ALL ON TABLE agh.fat_exame_liberado_cbo TO postgres;
raise notice 'Tabela agh.fat_exame_liberado_cbo GRANT ALL para postgres';

GRANT SELECT ON TABLE agh.fat_exame_liberado_cbo TO acesso_leitura;
raise notice 'Tabela agh.fat_exame_liberado_cbo GRANT SELECT para acesso_leitura';

CREATE INDEX fat_elc_fat_cbos_liberacao_exame_fk_i
    ON agh.fat_exame_liberado_cbo USING btree
    (fat_cbos_liberacao_exame_seq ASC NULLS LAST)
    TABLESPACE tblspc_idx;			
raise notice 'Tabela agh.fat_exame_liberado_cbo CREATE INDEX fat_elc_fat_cbos_liberacao_exame_fk_i';			
			
exception
			when others then
				raise info 'Error Name:%', sqlerrm;
				raise info 'Error State:%', sqlstate;
end;
end if;

END $$