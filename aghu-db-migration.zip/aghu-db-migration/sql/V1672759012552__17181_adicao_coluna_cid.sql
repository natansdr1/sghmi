DO $$
BEGIN

if not exists (
			select 1 from information_schema.columns
			where table_schema = 'agh' and table_name = 'mbc_agenda_procedimentos' and column_name = 'cid_seq') then begin
alter table agh.mbc_agenda_procedimentos add cid_seq integer null;
raise notice 'Coluna cid_seq integer criada na tabela agh.mbc_agenda_procedimentos';
alter table agh.mbc_agenda_procedimentos add constraint mbc_agp_agh_cid_fk foreign key (cid_seq)
    references agh.agh_cids (seq) match SIMPLE on update no action on delete no action;
raise notice 'Foreign key mbc_agp_agh_cid_fk criada na tabela agh.mbc_agenda_procedimentos.';
exception
			when others then
				raise info 'Error Name:%', sqlerrm;
				raise info 'Error State:%', sqlstate;
end;
end if;

END $$