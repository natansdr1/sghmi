DO $$
BEGIN

	IF NOT EXISTS (
		SELECT
		FROM information_schema.columns
		WHERE table_schema = 'agh'
		AND table_name = 'agh_versoes_documentos'
		AND column_name = 'assinado_em'
	) THEN
ALTER TABLE agh.agh_versoes_documentos ADD COLUMN assinado_em timestamp ;
COMMENT ON COLUMN agh.agh_versoes_documentos.assinado_em IS 'Armazenar data da assinatura';
	RAISE NOTICE 'EXECUTADO ALTERAÇÃO: #24498 - Novas colunas agh.agh_versoes_documentos';
END IF;

END $$