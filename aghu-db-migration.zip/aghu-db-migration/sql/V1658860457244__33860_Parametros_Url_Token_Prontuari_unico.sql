DO $$
begin

if not exists (select COUNT (*) from agh.agh_nodos_pol where nome = 'prontuarioUnificadoEbserh' and descricao = 'Prontuário Unificado EBSERH') then
	INSERT INTO agh.agh_nodos_pol (seq, nome, descricao, status, ordem, icone, alterado_em, alterado_por, "version")
	VALUES((select max(seq) + 1 from agh.AGH_NODOS_POL), 'prontuarioUnificadoEbserh', 'Prontuário Unificado EBSERH', 'A', 23, '/images/icons/pastas.png', '2022-06-15 11:29:14.740', 'aghu', 0);
end if;

INSERT INTO agh.agh_parametros( seq, sis_sigla, nome, mantem_historico, criado_em, criado_por, alterado_em, alterado_por, vlr_data, vlr_numerico,
                                vlr_texto, descricao, rotina_consistencia, version, vlr_data_padrao, vlr_numerico_padrao, vlr_texto_padrao, exemplo_uso, tipo_dado)
SELECT
    (select nextval('agh.agh_psi_sq1'))
     ,'AGH'
     ,'P_URL_INTEROPERABILIDADE'
     ,'S'
     ,now()
     ,'AGHU'
     ,null
     ,null
     ,NULL
     ,null
     ,null
     ,'Parâmetro P_URL_INTEROPERABILIDADE não configurado'
     ,null
     ,0
     ,null
     ,null
     ,NULL
     ,null
     ,'T'
    WHERE
			NOT EXISTS (SELECT 1 FROM agh.agh_parametros WHERE nome = 'P_URL_INTEROPERABILIDADE' AND sis_sigla = 'AGH');

INSERT INTO agh.agh_parametros( seq, sis_sigla, nome, mantem_historico, criado_em, criado_por, alterado_em, alterado_por, vlr_data, vlr_numerico,
                                vlr_texto, descricao, rotina_consistencia, version, vlr_data_padrao, vlr_numerico_padrao, vlr_texto_padrao, exemplo_uso, tipo_dado)
SELECT
    (select nextval('agh.agh_psi_sq1'))
     ,'AGH'
     ,'P_TOKEN_INTEROPERABILIDADE'
     ,'S'
     ,now()
     ,'AGHU'
     ,null
     ,null
     ,NULL
     ,null
     ,null
     ,'Parâmetro P_TOKEN_INTEROPERABILIDADE não configurado'
     ,null
     ,0
     ,null
     ,null
     ,NULL
     ,null
     ,'T'
    WHERE
			NOT EXISTS (SELECT 1 FROM agh.agh_parametros WHERE nome = 'P_TOKEN_INTEROPERABILIDADE' AND sis_sigla = 'AGH');
end $$