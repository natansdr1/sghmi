DO $$
BEGIN

    IF NOT EXISTS(
            SELECT 1
            FROM information_schema.columns
            WHERE table_schema = 'agh'
                AND table_name = 'mbc_agenda_procedimentos'
                AND column_name = 'lado_cirurgia'
        ) THEN
        ALTER TABLE agh.mbc_agenda_procedimentos ADD COLUMN lado_cirurgia varchar(1);
        COMMENT ON COLUMN agh.mbc_agenda_procedimentos.lado_cirurgia IS 'Lado da Cirurgia.';
        RAISE NOTICE 'Criação da Coluna: LADO_CIRURGIA, na Tabela: agh.mbc_agenda_procedimentos #16988';
    END IF;

    IF NOT EXISTS(
            SELECT 1
            FROM information_schema.columns
            WHERE table_schema = 'agh'
                AND table_name = 'mbc_agenda_procedimentos'
                AND column_name = 'ind_contaminacao'
        ) THEN
        ALTER TABLE agh.mbc_agenda_procedimentos ADD COLUMN ind_contaminacao varchar(1);
        COMMENT ON COLUMN agh.mbc_agenda_procedimentos.ind_contaminacao IS 'Indicador de Contaminação.';
        RAISE NOTICE 'Criação da Coluna: IND_CONTAMINACAO, na Tabela: agh.mbc_agenda_procedimentos #16988';
    END IF;

    IF NOT EXISTS(
            SELECT 1
            FROM information_schema.columns
            WHERE table_schema = 'agh'
                AND table_name = 'mbc_agenda_procedimentos'
                AND column_name = 'complemento'
        ) THEN
        ALTER TABLE agh.mbc_agenda_procedimentos ADD COLUMN complemento varchar(500);
        COMMENT ON COLUMN agh.mbc_agenda_procedimentos.complemento IS 'Complemento do Procedimento.';
        RAISE NOTICE 'Criação da Coluna: complemento, na Tabela: agh.mbc_agenda_procedimentos #16988';
    END IF;

END $$