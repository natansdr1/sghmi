do
$$
DECLARE
   qtd_linhas_afetadas INTEGER;
   tabela_existe BOOLEAN;
begin
	SELECT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'agh' and table_name = 'agh_tipos_unidade_funcional') INTO tabela_existe;
	IF tabela_existe THEN
		UPDATE agh.agh_tipos_unidade_funcional
		SET descricao = 'Unidade Virtual'
		WHERE upper(descricao) = upper('rn virtual');
		GET DIAGNOSTICS qtd_linhas_afetadas = ROW_COUNT;
		RAISE NOTICE 'Número de linhas atualizadas: [%]', qtd_linhas_afetadas;
	ELSE
		RAISE NOTICE 'Número de linhas atualizadas: (0)';
	END IF;
end;
$$