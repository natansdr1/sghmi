DO $$
    DECLARE
        data_atualizacao TIMESTAMP := (SELECT installed_on FROM db_migration.flyway_schema_history WHERE "version" = '1670445724762');
        z00_cid INT := (SELECT seq FROM agh.agh_cids WHERE codigo = 'Z00');
        qtd_linhas_afetadas INT;
    BEGIN
        UPDATE agh.ael_solicitacao_exames
        SET agh_cid_solicitacao_seq = z00_cid
        WHERE agh_cid_solicitacao_seq = 1
        AND criado_em < data_atualizacao;
        GET DIAGNOSTICS qtd_linhas_afetadas = ROW_COUNT;
        RAISE NOTICE 'Atualizadas % solicitações de exames', qtd_linhas_afetadas;
    END;
    $$
;
