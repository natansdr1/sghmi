DO $$
BEGIN
    IF EXISTS (
        SELECT 1 
        FROM information_schema.tables 
        WHERE table_schema = 'agh' 
        AND table_name = 'sce_documento_fiscal_entradas'
    ) THEN
        BEGIN
        ALTER TABLE agh.sce_documento_fiscal_entradas
            ADD COLUMN autorizacao_fornecimento_externo VARCHAR(12);
        RAISE NOTICE 'Coluna adicionada com sucesso.';
        EXCEPTION
            WHEN others THEN
                RAISE WARNING 'Falha ao adicionar a coluna: %', SQLERRM;
        END;
    ELSE
        RAISE NOTICE 'Tabela não existe.';
    END IF;
END $$;