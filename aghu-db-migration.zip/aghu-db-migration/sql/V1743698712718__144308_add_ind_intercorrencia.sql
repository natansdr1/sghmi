DO $$
BEGIN
  RAISE INFO 'Validando presença da coluna "ind_intercorrencia" na tabela "agh.pdt_dados_descs_jn"';

  IF NOT EXISTS (
    SELECT 1
    FROM information_schema.columns c
    WHERE c.table_name = 'pdt_dados_descs_jn'
    AND c.table_schema = 'agh'
    AND c.column_name = 'ind_intercorrencia'
  ) THEN
      ALTER TABLE agh.pdt_dados_descs_jn
      ADD COLUMN ind_intercorrencia VARCHAR(1);
      RAISE INFO 'Inserida a coluna "ind_intercorrencia" na tabela "agh.pdt_dados_descs_jn"';
  ELSE
      RAISE INFO 'Coluna "ind_intercorrencia" da tabela "agh.pdt_dados_descs_jn" já existe! Nada foi feito.';
  END IF;
END;
$$;