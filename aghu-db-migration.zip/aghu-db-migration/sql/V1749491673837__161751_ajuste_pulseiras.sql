DO
$$
begin

    IF NOT EXISTS ( SELECT 1 FROM agh.agh_parametros parametro WHERE parametro.nome LIKE '%P_INICIO_LINHA_TEXTO_PULSEIRA_NEO%') THEN
        BEGIN
            INSERT INTO agh.agh_parametros(seq, sis_sigla, nome, mantem_historico, criado_em, criado_por,alterado_em, alterado_por, vlr_data, vlr_numerico, vlr_texto, descricao, rotina_consistencia, "version", vlr_data_padrao, vlr_numerico_padrao, vlr_texto_padrao, exemplo_uso, tipo_dado)
            VALUES (nextval('agh.agh_psi_sq1'), 'AIP', 'P_INICIO_LINHA_TEXTO_PULSEIRA_NEO', 'N', '2025-03-04 15:18:30.345', 'INTERFACEAMENTO DDE0', NULL, NULL, NULL, 200,'N','Posição inicial horizontal do texto no layout da pulseira neonatal. Se o valor de texto for "N", será usado o valor padrão. Se for "S", usa o valor numérico informado', NULL, 0, NULL, NULL, NULL, NULL, 'T');
            RAISE NOTICE 'Insert com descrição "P_INICIO_LINHA_TEXTO_PULSEIRA_NEO" realizado com sucesso.';

        EXCEPTION
            WHEN OTHERS THEN
              RAISE NOTICE 'Erro no insert com descrição "P_INICIO_LINHA_TEXTO_PULSEIRA_NEO": %', SQLERRM;
        END;
    ELSE
        RAISE NOTICE 'Registro com descrição "P_INICIO_LINHA_TEXTO_PULSEIRA_NEO" já existe. Nenhum insert foi realizado.';
    END IF;

    IF NOT EXISTS ( SELECT 1 FROM agh.agh_parametros parametro WHERE parametro.nome LIKE '%P_INICIO_LINHA_TEXTO_PULSEIRA_INFANTIL%') THEN
        BEGIN
            INSERT INTO agh.agh_parametros(seq, sis_sigla, nome, mantem_historico, criado_em, criado_por, alterado_em, alterado_por, vlr_data, vlr_numerico, vlr_texto, descricao, rotina_consistencia, "version", vlr_data_padrao, vlr_numerico_padrao, vlr_texto_padrao, exemplo_uso, tipo_dado)
            VALUES(nextval('agh.agh_psi_sq1'), 'AIP', 'P_INICIO_LINHA_TEXTO_PULSEIRA_INFANTIL', 'N', '2025-03-05 13:20:36.013', 'INTERFACEAMENTO DDE0', NULL, NULL, NULL, 200, 'N', 'Posição inicial horizontal do texto no layout da pulseira infantil. Se o valor de texto for "N", será usado o valor padrão. Se for "S", usa o valor numérico informado', NULL, 0, NULL, NULL, NULL, NULL, 'T');
            RAISE NOTICE 'Insert com descrição "P_INICIO_TEXTO_PULSEIRA_NEO" realizado com sucesso.';

        EXCEPTION
            WHEN OTHERS THEN
              RAISE NOTICE 'Erro no insert com descrição "P_INICIO_LINHA_TEXTO_PULSEIRA_INFANTIL": %', SQLERRM;
        END;
    ELSE
        RAISE NOTICE 'Registro com descrição "P_INICIO_LINHA_TEXTO_PULSEIRA_INFANTIL" já existe. Nenhum insert foi realizado.';
    END IF;


    IF NOT EXISTS ( SELECT 1 FROM agh.agh_parametros parametro WHERE parametro.nome LIKE '%P_INICIO_LINHA_TEXTO_PULSEIRA_ADULTO%') THEN
        BEGIN
            INSERT INTO agh.agh_parametros(seq, sis_sigla, nome, mantem_historico, criado_em, criado_por, alterado_em, alterado_por, vlr_data, vlr_numerico, vlr_texto, descricao, rotina_consistencia, "version", vlr_data_padrao, vlr_numerico_padrao, vlr_texto_padrao, exemplo_uso, tipo_dado)
            VALUES(nextval('agh.agh_psi_sq1'), 'AIP', 'P_INICIO_LINHA_TEXTO_PULSEIRA_ADULTO', 'N', '2025-03-05 13:21:08.104', 'INTERFACEAMENTO DDE0', NULL, NULL, NULL, 200, 'N', 'Posição inicial horizontal do texto no layout da pulseira adulta. Se o valor de texto for "N", será usado o valor padrão. Se for "S", usa o valor numérico informado', NULL, 0, NULL, NULL, NULL, NULL, 'T');
            RAISE NOTICE 'Insert com descrição "P_INICIO_LINHA_TEXTO_PULSEIRA_ADULTO" realizado com sucesso.';
        EXCEPTION
            WHEN OTHERS THEN
              RAISE NOTICE 'Erro no insert com descrição "P_INICIO_LINHA_TEXTO_PULSEIRA_ADULTO": %', SQLERRM;
        END;
    ELSE
        RAISE NOTICE 'Registro com descrição "P_INICIO_LINHA_TEXTO_PULSEIRA_ADULTO" já existe. Nenhum insert foi realizado.';
    END IF;


    IF NOT EXISTS ( SELECT 1 FROM agh.agh_parametros parametro WHERE parametro.nome LIKE '%P_ESPACAMENTO_LINHA_PULSEIRA_NEO%') THEN
        BEGIN
            INSERT INTO agh.agh_parametros(seq, sis_sigla, nome, mantem_historico, criado_em, criado_por, alterado_em, alterado_por, vlr_data, vlr_numerico, vlr_texto, descricao, rotina_consistencia, "version", vlr_data_padrao, vlr_numerico_padrao, vlr_texto_padrao, exemplo_uso, tipo_dado)
            VALUES(nextval('agh.agh_psi_sq1'), 'AIP', 'P_ESPACAMENTO_LINHA_PULSEIRA_NEO', 'N', '2025-03-04 15:19:39.985', 'INTERFACEAMENTO DDE0', NULL, NULL, NULL, 35,'N','Define o espaçamento entre linhas no layout da pulseira neo. Se o valor de texto for "N", será usado o padrão. Se for "S", usa o valor numérico informado', NULL, 0, NULL, NULL, NULL, NULL, 'T');
            RAISE NOTICE 'Insert com descrição "P_ESPACAMENTO_LINHA_PULSEIRA_NEO" realizado com sucesso.';

        EXCEPTION
            WHEN OTHERS THEN
              RAISE NOTICE 'Erro no insert com descrição "P_ESPACAMENTO_LINHA_PULSEIRA_NEO": %', SQLERRM;
        END;
    ELSE
        RAISE NOTICE 'Registro com descrição "P_ESPACAMENTO_LINHA_PULSEIRA_NEO" já existe. Nenhum insert foi realizado.';
    END IF;


    IF NOT EXISTS ( SELECT 1 FROM agh.agh_parametros parametro WHERE parametro.nome LIKE '%P_ESPACAMENTO_LINHA_PULSEIRA_INFANTIL%') THEN
        BEGIN
            INSERT INTO agh.agh_parametros(seq, sis_sigla, nome, mantem_historico, criado_em, criado_por, alterado_em, alterado_por, vlr_data, vlr_numerico, vlr_texto, descricao, rotina_consistencia, "version", vlr_data_padrao, vlr_numerico_padrao, vlr_texto_padrao, exemplo_uso, tipo_dado)
            VALUES(nextval('agh.agh_psi_sq1'), 'AIP', 'P_ESPACAMENTO_LINHA_PULSEIRA_INFANTIL', 'N', '2025-03-05 13:31:26.703', 'INTERFACEAMENTO DDE0', NULL, NULL, NULL, 50, 'N', 'Define o espaçamento entre linhas no layout da pulseira infantil. Se o valor de texto for "N", será usado o padrão. Se for "S", usa o valor numérico informado', NULL, 0, NULL, NULL, NULL, NULL, 'T');
            RAISE NOTICE 'Insert com descrição "P_ESPACAMENTO_LINHA_PULSEIRA_INFANTIL" realizado com sucesso.';
        EXCEPTION
            WHEN OTHERS THEN
              RAISE NOTICE 'Erro no insert com descrição "P_ESPACAMENTO_LINHA_PULSEIRA_INFANTIL": %', SQLERRM;
        END;
    ELSE
        RAISE NOTICE 'Registro com descrição "P_ESPACAMENTO_LINHA_PULSEIRA_INFANTIL" já existe. Nenhum insert foi realizado.';
    END IF;


    IF NOT EXISTS ( SELECT 1 FROM agh.agh_parametros parametro WHERE parametro.nome LIKE '%P_ESPACAMENTO_LINHA_PULSEIRA_ADULTO%') THEN
        BEGIN

            INSERT INTO agh.agh_parametros(seq, sis_sigla, nome, mantem_historico, criado_em, criado_por, alterado_em, alterado_por, vlr_data, vlr_numerico, vlr_texto, descricao, rotina_consistencia, "version", vlr_data_padrao, vlr_numerico_padrao, vlr_texto_padrao, exemplo_uso, tipo_dado)
            VALUES(nextval('agh.agh_psi_sq1'), 'AIP', 'P_ESPACAMENTO_LINHA_PULSEIRA_ADULTO', 'N', '2025-03-05 13:32:04.248', 'INTERFACEAMENTO DDE0', '2025-04-08 15:02:42.500', 'INTERFACEAMENTO DDE0', NULL, 40, 'N', 'Define o espaçamento entre linhas no layout da pulseira adulta. Se o valor de texto for "N", será usado o padrão. Se for "S", usa o valor numérico informado', NULL, 0, NULL, NULL, NULL, NULL, 'T');
            RAISE NOTICE 'Insert com descrição "P_ESPACAMENTO_LINHA_PULSEIRA_ADULTO" realizado com sucesso.';

        EXCEPTION
            WHEN OTHERS THEN
              RAISE NOTICE 'Erro no insert com descrição "P_ESPACAMENTO_LINHA_PULSEIRA_ADULTO": %', SQLERRM;
        END;
    ELSE
        RAISE NOTICE 'Registro com descrição "P_ESPACAMENTO_LINHA_PULSEIRA_ADULTO" já existe. Nenhum insert foi realizado.';
    END IF;


    IF NOT EXISTS ( SELECT 1 FROM agh.agh_parametros parametro WHERE parametro.nome LIKE '%P_TAMANHO_TEXTO_PULSEIRA_NEO%') THEN
        BEGIN
            INSERT INTO agh.agh_parametros(seq, sis_sigla, nome, mantem_historico, criado_em, criado_por, alterado_em, alterado_por, vlr_data, vlr_numerico, vlr_texto, descricao, rotina_consistencia, "version", vlr_data_padrao, vlr_numerico_padrao, vlr_texto_padrao, exemplo_uso, tipo_dado)
            VALUES(nextval('agh.agh_psi_sq1'), 'AIP', 'P_TAMANHO_TEXTO_PULSEIRA_NEO', 'N', '2025-03-06 09:34:49.851', 'INTERFACEAMENTO DDE0', '2025-03-22 00:29:13.521', 'INTERFACEAMENTO DDE0', NULL, 25, 'N','Define o tamanho da fonte do texto no layout da pulseira neonatal. Se o valor de texto for "N", será usado o padrão. Se for "S", usa o valor numérico informado.', NULL, 0, NULL, NULL, NULL, NULL, 'T');
            RAISE NOTICE 'Insert com descrição "P_TAMANHO_TEXTO_PULSEIRA_NEO" realizado com sucesso.';
        EXCEPTION
            WHEN OTHERS THEN
              RAISE NOTICE 'Erro no insert com descrição "P_TAMANHO_TEXTO_PULSEIRA_NEO": %', SQLERRM;
        END;
    ELSE
            RAISE NOTICE 'Registro com descrição "P_TAMANHO_TEXTO_PULSEIRA_NEO" já existe. Nenhum insert foi realizado.';
    END IF;

    IF NOT EXISTS ( SELECT 1 FROM agh.agh_parametros parametro WHERE parametro.nome LIKE '%P_TAMANHO_TEXTO_PULSEIRA_INFANTIL%') THEN
        BEGIN

        INSERT INTO agh.agh_parametros(seq, sis_sigla, nome, mantem_historico, criado_em, criado_por, alterado_em, alterado_por, vlr_data, vlr_numerico, vlr_texto, descricao, rotina_consistencia, "version", vlr_data_padrao, vlr_numerico_padrao, vlr_texto_padrao, exemplo_uso, tipo_dado)
        VALUES(nextval('agh.agh_psi_sq1'), 'AIP', 'P_TAMANHO_TEXTO_PULSEIRA_INFANTIL', 'N', '2025-03-06 09:35:26.315', 'INTERFACEAMENTO DDE0', NULL, NULL, NULL, 30, 'N', 'Define o tamanho da fonte do texto no layout da pulseira infantil. Se o valor de texto for "N", será usado o padrão. Se for "S", usa o valor numérico informado.', NULL, 0, NULL, NULL, NULL, NULL, 'T');
        RAISE NOTICE 'Insert com descrição "P_TAMANHO_TEXTO_PULSEIRA_INFANTIL" realizado com sucesso.';

        EXCEPTION
            WHEN OTHERS THEN
              RAISE NOTICE 'Erro no insert com descrição "P_TAMANHO_TEXTO_PULSEIRA_INFANTIL": %', SQLERRM;
        END;
    ELSE
            RAISE NOTICE 'Registro com descrição "P_TAMANHO_TEXTO_PULSEIRA_INFANTIL" já existe. Nenhum insert foi realizado.';
    END IF;


    IF NOT EXISTS ( SELECT 1 FROM agh.agh_parametros parametro WHERE parametro.nome LIKE '%P_TAMANHO_TEXTO_PULSEIRA_ADULTO%') THEN
        BEGIN

            INSERT INTO agh.agh_parametros(seq, sis_sigla, nome, mantem_historico, criado_em, criado_por, alterado_em, alterado_por, vlr_data, vlr_numerico, vlr_texto, descricao, rotina_consistencia, "version", vlr_data_padrao, vlr_numerico_padrao, vlr_texto_padrao, exemplo_uso, tipo_dado)
            VALUES(nextval('agh.agh_psi_sq1'), 'AIP', 'P_TAMANHO_TEXTO_PULSEIRA_ADULTO', 'N', '2025-03-06 09:36:12.754', 'INTERFACEAMENTO DDE0', NULL, NULL, NULL, 30, 'N', 'Define o tamanho da fonte do texto no layout da pulseira adulta. Se o valor de texto for "N", será usado o padrão. Se for "S", usa o valor numérico informado.', NULL, 0, NULL, NULL, NULL, NULL, 'T');
            RAISE NOTICE 'Insert com descrição "P_TAMANHO_TEXTO_PULSEIRA_ADULTO" realizado com sucesso.';

        EXCEPTION
            WHEN OTHERS THEN
              RAISE NOTICE 'Erro no insert com descrição "P_TAMANHO_TEXTO_PULSEIRA_ADULTO": %', SQLERRM;
        END;
    ELSE
        RAISE NOTICE 'Registro com descrição "P_TAMANHO_TEXTO_PULSEIRA_ADULTO" já existe. Nenhum insert foi realizado.';
    END IF;


    IF NOT EXISTS ( SELECT 1 FROM agh.agh_parametros parametro WHERE parametro.nome LIKE '%P_INICIO_COLUNA_PULSEIRA_NEO%') THEN
        BEGIN

        INSERT INTO agh.agh_parametros(seq, sis_sigla, nome, mantem_historico, criado_em, criado_por, alterado_em, alterado_por, vlr_data, vlr_numerico, vlr_texto, descricao, rotina_consistencia, "version", vlr_data_padrao, vlr_numerico_padrao, vlr_texto_padrao, exemplo_uso, tipo_dado)
        VALUES(nextval('agh.agh_psi_sq1'), 'AIP', 'P_INICIO_COLUNA_PULSEIRA_NEO', 'N', '2025-03-07 10:28:18.543', 'INTERFACEAMENTO DDE0', '2025-04-01 17:00:53.241', 'INTERFACEAMENTO DDE0', NULL, 140, 'N', 'Define a posição inicial da coluna (vertical) no layout da pulseira infantil. Se o valor de texto for "N", será usado o valor padrão. Se for "S", usa o valor informado.', NULL, 0, NULL, NULL, NULL, NULL, 'T');
        RAISE NOTICE 'Insert com descrição "P_INICIO_COLUNA_PULSEIRA_NEO" realizado com sucesso.';

        EXCEPTION
            WHEN OTHERS THEN
              RAISE NOTICE 'Erro no insert com descrição "P_INICIO_COLUNA_PULSEIRA_NEO": %', SQLERRM;
        END;
    ELSE
        RAISE NOTICE 'Registro com descrição "P_INICIO_COLUNA_PULSEIRA_NEO" já existe. Nenhum insert foi realizado.';
    END IF;


    IF NOT EXISTS ( SELECT 1 FROM agh.agh_parametros parametro WHERE parametro.nome LIKE '%P_INICIO_COLUNA_PULSEIRA_INFANTIL%') THEN
        BEGIN

            INSERT INTO agh.agh_parametros(seq, sis_sigla, nome, mantem_historico, criado_em, criado_por, alterado_em, alterado_por, vlr_data, vlr_numerico, vlr_texto, descricao, rotina_consistencia, "version", vlr_data_padrao, vlr_numerico_padrao, vlr_texto_padrao, exemplo_uso, tipo_dado)
            VALUES(nextval('agh.agh_psi_sq1'), 'AIP', 'P_INICIO_COLUNA_PULSEIRA_INFANTIL', 'N', '2025-03-07 10:29:35.323', 'INTERFACEAMENTO DDE0', NULL, NULL, NULL, 145, 'N', 'Define a posição inicial da coluna (vertical) no layout da pulseira neonatal. Se o valor de texto for "N", será usado o valor padrão. Se for "S", usa o valor informado.', NULL, 0, NULL, NULL, NULL, NULL, 'T');
            RAISE NOTICE 'Insert com descrição "P_INICIO_COLUNA_PULSEIRA_INFANTIL" realizado com sucesso.';

        EXCEPTION
            WHEN OTHERS THEN
              RAISE NOTICE 'Erro no insert com descrição "P_INICIO_COLUNA_PULSEIRA_INFANTIL": %', SQLERRM;
        END;
    ELSE
        RAISE NOTICE 'Registro com descrição "P_INICIO_COLUNA_PULSEIRA_INFANTIL" já existe. Nenhum insert foi realizado.';
    END IF;

    IF NOT EXISTS ( SELECT 1 FROM agh.agh_parametros parametro WHERE parametro.nome LIKE '%P_INICIO_COLUNA_PULSEIRA_ADULTO%') THEN
        BEGIN

            INSERT INTO agh.agh_parametros(seq, sis_sigla, nome, mantem_historico, criado_em, criado_por, alterado_em, alterado_por, vlr_data, vlr_numerico, vlr_texto, descricao, rotina_consistencia, "version", vlr_data_padrao, vlr_numerico_padrao, vlr_texto_padrao, exemplo_uso, tipo_dado)
            VALUES(nextval('agh.agh_psi_sq1'), 'AIP', 'P_INICIO_COLUNA_PULSEIRA_ADULTO', 'N', '2025-03-07 10:30:52.613', 'INTERFACEAMENTO DDE0', NULL, NULL, NULL, 150, 'N', 'Define a posição inicial da coluna (vertical) no layout da pulseira adulta. Se o valor de texto for "N", será usado o valor padrão. Se for "S", usa o valor informado.', NULL, 0, NULL, NULL, NULL, NULL, 'T');

            RAISE NOTICE 'Insert com descrição "P_INICIO_COLUNA_PULSEIRA_ADULTO" realizado com sucesso.';

        EXCEPTION
                    WHEN OTHERS THEN
                      RAISE NOTICE 'Erro no insert com descrição "P_INICIO_COLUNA_PULSEIRA_ADULTO": %', SQLERRM;
        END;
    ELSE
            RAISE NOTICE 'Registro com descrição "P_INICIO_COLUNA_PULSEIRA_ADULTO" já existe. Nenhum insert foi realizado.';
    END IF;



    IF NOT EXISTS ( SELECT 1 FROM agh.agh_parametros parametro WHERE parametro.nome LIKE '%P_INVERSAO_180_GRAUS_POI_PULSEIRA_NEO%') THEN
        BEGIN

            INSERT INTO agh.agh_parametros(seq, sis_sigla, nome, mantem_historico, criado_em, criado_por, alterado_em, alterado_por, vlr_data, vlr_numerico, vlr_texto, descricao, rotina_consistencia, "version", vlr_data_padrao, vlr_numerico_padrao, vlr_texto_padrao, exemplo_uso, tipo_dado)
            VALUES(nextval('agh.agh_psi_sq1'), 'AIP', 'P_INVERSAO_180_GRAUS_POI_PULSEIRA_NEO', 'N', '2025-04-04 14:43:49.000', 'AGHU', '2025-04-04 14:54:12.000', 'AGHU', NULL, NULL, 'N', 'Inversão de 180 graus no layout da pulseira neonatal (POI).', NULL, 0, NULL, NULL, NULL, NULL, 'T');
            RAISE NOTICE 'Insert com descrição "P_INVERSAO_PULSEIRA_180_GRAUS_POI_NEO" realizado com sucesso.';

        EXCEPTION
                    WHEN OTHERS THEN
                      RAISE NOTICE 'Erro no insert com descrição "P_INVERSAO_180_GRAUS_POI_PULSEIRA_NEO": %', SQLERRM;
        END;
    ELSE
            RAISE NOTICE 'Registro com descrição "P_INVERSAO_180_GRAUS_POI_PULSEIRA_NEO" já existe. Nenhum insert foi realizado.';
    END IF;


    IF NOT EXISTS ( SELECT 1 FROM agh.agh_parametros parametro WHERE parametro.nome LIKE '%P_INVERSAO_180_GRAUS_POI_PULSEIRA_INFANTIL%') THEN
        BEGIN

            INSERT INTO agh.agh_parametros(seq, sis_sigla, nome, mantem_historico, criado_em, criado_por, alterado_em, alterado_por, vlr_data, vlr_numerico, vlr_texto, descricao, rotina_consistencia, "version", vlr_data_padrao, vlr_numerico_padrao, vlr_texto_padrao, exemplo_uso, tipo_dado)
            VALUES(nextval('agh.agh_psi_sq1'), 'AIP', 'P_INVERSAO_180_GRAUS_POI_PULSEIRA_INFANTIL', 'N', '2025-04-04 14:44:06.000', 'AGHU', '2025-04-04 14:53:58.000', 'AGHU', NULL, NULL, 'N', 'Inversão de 180 graus no layout da pulseira infantil (POI).', NULL, 0, NULL, NULL, NULL, NULL, 'T');
            RAISE NOTICE 'Insert com descrição "P_INVERSAO_180_GRAUS_POI_PULSEIRA_INFANTIL" realizado com sucesso.';

        EXCEPTION
            WHEN OTHERS THEN
              RAISE NOTICE 'Erro no insert com descrição "P_INVERSAO_180_GRAUS_POI_PULSEIRA_INFANTIL": %', SQLERRM;
        END;
    ELSE
              RAISE NOTICE 'Registro com descrição "P_INVERSAO_180_GRAUS_POI_PULSEIRA_INFANTIL" já existe. Nenhum insert foi realizado.';
    END IF;


    IF NOT EXISTS ( SELECT 1 FROM agh.agh_parametros parametro WHERE parametro.nome LIKE '%P_INVERSAO_180_GRAUS_POI_PULSEIRA_ADULTO%') THEN
        BEGIN

            INSERT INTO agh.agh_parametros(seq, sis_sigla, nome, mantem_historico, criado_em, criado_por, alterado_em, alterado_por, vlr_data, vlr_numerico, vlr_texto, descricao, rotina_consistencia, "version", vlr_data_padrao, vlr_numerico_padrao, vlr_texto_padrao, exemplo_uso, tipo_dado)
            VALUES(nextval('agh.agh_psi_sq1'), 'AIP', 'P_INVERSAO_180_GRAUS_POI_PULSEIRA_ADULTO', 'N', '2025-04-04 14:41:49.000', 'AGHU', '2025-04-04 14:53:38.000', 'AGHU', NULL, NULL, 'N', 'Inversão de 180 graus no layout da pulseira adulta (POI).', NULL, 0, NULL, NULL, NULL, NULL, 'T');
            RAISE NOTICE 'Insert com descrição "P_INVERSAO_180_GRAUS_POI_PULSEIRA_ADULTO" realizado com sucesso.';

        EXCEPTION
            WHEN OTHERS THEN
              RAISE NOTICE 'Erro no insert com descrição "P_INVERSAO_180_GRAUS_POI_PULSEIRA_ADULTO": %', SQLERRM;
        END;
    ELSE
            RAISE NOTICE 'Registro com descrição "P_INVERSAO_180_GRAUS_POI_PULSEIRA_ADULTO" já existe. Nenhum insert foi realizado.';
    END IF;



    IF NOT EXISTS ( SELECT 1 FROM agh.agh_parametros parametro WHERE parametro.nome LIKE '%P_AREA_MENOR_IMPRESSAO_BARCODE_PULSEIRA_NEO%') THEN
        BEGIN

            INSERT INTO agh.agh_parametros(seq, sis_sigla, nome, mantem_historico, criado_em, criado_por, alterado_em, alterado_por, vlr_data, vlr_numerico, vlr_texto, descricao, rotina_consistencia, "version", vlr_data_padrao, vlr_numerico_padrao, vlr_texto_padrao, exemplo_uso, tipo_dado)
            VALUES(nextval('agh.agh_psi_sq1'), 'AIP', 'P_AREA_MENOR_IMPRESSAO_BARCODE_PULSEIRA_NEO', 'N', '2025-04-04 14:41:49.000', 'AGHU', '2025-04-04 14:53:38.000', 'AGHU', NULL, 30, 'N', 'Tamanho horizontal do codigo de barras, padrão nova pulseira neo é 30', NULL, 0, NULL, NULL, NULL, NULL, 'T');
            RAISE NOTICE 'Insert com descrição "P_AREA_MENOR_IMPRESSAO_BARCODE_PULSEIRA_NEO" realizado com sucesso.';

        EXCEPTION
            WHEN OTHERS THEN
              RAISE NOTICE 'Erro no insert com descrição "P_AREA_MENOR_IMPRESSAO_BARCODE_PULSEIRA_NEO": %', SQLERRM;
        END;
    ELSE
            RAISE NOTICE 'Registro com descrição "P_AREA_MENOR_IMPRESSAO_BARCODE_PULSEIRA_NEO" já existe. Nenhum insert foi realizado.';
    END IF;


    IF NOT EXISTS ( SELECT 1 FROM agh.agh_parametros parametro WHERE parametro.nome LIKE '%P_AREA_LARGURA_DOTS_IMPRESSAO_PULSEIRA_NEO%') THEN
        BEGIN

            INSERT INTO agh.agh_parametros(seq, sis_sigla, nome, mantem_historico, criado_em, criado_por, alterado_em, alterado_por, vlr_data, vlr_numerico, vlr_texto, descricao, rotina_consistencia, "version", vlr_data_padrao, vlr_numerico_padrao, vlr_texto_padrao, exemplo_uso, tipo_dado)
            VALUES(nextval('agh.agh_psi_sq1'), 'AIP', 'P_AREA_LARGURA_DOTS_IMPRESSAO_PULSEIRA_NEO', 'N', '2025-04-04 14:41:49.000', 'AGHU', '2025-04-04 14:53:38.000', 'AGHU', NULL, 310 , 'N', 'referece a largura em dots da impressão do texto na nova pulseira neo, para 40 cm, 310 padrão, avalie calcular espaço codido Barras e nome hospital', NULL, 0, NULL, NULL, NULL, NULL, 'T');
            RAISE NOTICE 'Insert com descrição "P_AREA_LARGURA_DOTS_IMPRESSAO_PULSEIRA_NEO" realizado com sucesso.';

        EXCEPTION
            WHEN OTHERS THEN
              RAISE NOTICE 'Erro no insert com descrição "P_AREA_LARGURA_DOTS_IMPRESSAO_PULSEIRA_NEO": %', SQLERRM;
        END;
    ELSE
        RAISE NOTICE 'Registro com descrição "P_AREA_LARGURA_DOTS_IMPRESSAO_PULSEIRA_NEO" já existe. Nenhum insert foi realizado.';
    END IF;

END
$$;