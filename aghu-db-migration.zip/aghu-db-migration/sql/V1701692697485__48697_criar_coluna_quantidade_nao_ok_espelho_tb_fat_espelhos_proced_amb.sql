DO $$
BEGIN

    IF NOT EXISTS(
            SELECT 1
            FROM information_schema.columns
            WHERE table_schema = 'agh'
                AND table_name = 'fat_espelhos_proced_amb'
                AND column_name = 'quantidade_nok'
        ) THEN
        ALTER TABLE agh.fat_espelhos_proced_amb ADD COLUMN quantidade_nok int4 NULL;
        COMMENT ON COLUMN agh.fat_espelhos_proced_amb.quantidade_nok IS 'Quantidade de procedimentos além da permitida pela tabela SIGTAP.';
        RAISE NOTICE 'Criação da Coluna: QUANTIDADE_NOK, na Tabela: agh.fat_espelhos_proced_amb #48697';
    END IF;

END $$