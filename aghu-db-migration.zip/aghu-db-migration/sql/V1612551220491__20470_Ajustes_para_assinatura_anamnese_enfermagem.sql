do $$
declare	
	var_data_type varchar(64) := null;
	var_character_maximum_length decimal(10) := null;
begin
	select a.character_maximum_length 
	into var_character_maximum_length
	from information_schema.columns a 
	where a.table_schema = 'agh' and a.table_name = 'agh_documentos_certificados' and a.column_name = 'tipo';
	if(var_character_maximum_length = 7) then
		raise info 'N�o foi necess�rio alterar a coluna agh.agh_documentos_certificados.tipo';
		elsif(var_character_maximum_length < 7) then 
			alter table agh.agh_documentos_certificados alter column tipo type varchar(7);
	end if;

	if exists(select null from information_schema.columns
        	where table_name = 'v_afa_prcr_disp_mdtos_painel' and table_schema = 'agh') then
    	drop view agh.v_afa_prcr_disp_mdtos_painel;
	end if;

	if exists(select null from information_schema.columns
        	where table_name = 'v_afa_prcr_disp_mdtos_painel' and table_schema = 'db_migration') then
    	drop view db_migration.v_afa_prcr_disp_mdtos_painel;
	end if;
	
	if exists(select null from information_schema.columns
			where table_name = 'v_mpm_lista_pac_internados' and table_schema = 'agh') then
	    drop view agh.v_mpm_lista_pac_internados;
	end if;

	if exists(select null from information_schema.columns
			where table_name = 'v_lista_prescricao_enfermagem' and table_schema = 'agh') then
	    drop view agh.v_lista_prescricao_enfermagem;
	end if;

	if exists(select null from information_schema.columns
			where table_name = 'v_agh_versoes_documentos' and table_schema = 'agh') then 
	    drop view agh.v_agh_versoes_documentos;
	end if;

	alter table agh.agh_documentos alter column tipo type varchar(7);
	
	--Insere novo tipo de documento
	IF not exists(select null from AGH.AGH_DOCUMENTOS_CERTIFICADOS where nome = '/br/gov/mec/aghu/prescricaoenfermagem/report/relatorioAnamnesePaciente.jasper' and tipo = 'ANA_PEN')
	    then
	    insert into AGH.AGH_DOCUMENTOS_CERTIFICADOS(seq, nome, dthr_edicao, identificador, tipo, ind_situacao, version, ind_impressao_automatica)
	    values (nextval('AGH.AGH_DCE_SQ1'), '/br/gov/mec/aghu/prescricaoenfermagem/report/relatorioAnamnesePaciente.jasper', now(), 'ATD_SEQ', 'ANA_PEN', 'A', 1, 'S');
	END IF;

	create view agh.v_agh_versoes_documentos(dov_seq, dov_criado_em, dov_situacao, dok_tipo, pac_codigo, pac_prontuario, pac_nome, ser_matricula, ser_vin_codigo, ser_cct_codigo, ser_cct_codigo_atua, pes_nome) as
	SELECT dov.seq AS dov_seq,
	       dov.criado_em AS dov_criado_em,
	       dov.situacao AS dov_situacao,
	       dok.tipo AS dok_tipo,
	       pac.codigo AS pac_codigo,
	       pac.prontuario AS pac_prontuario,
	       pac.nome AS pac_nome,
	       ser.matricula AS ser_matricula,
	       ser.vin_codigo AS ser_vin_codigo,
	       ser.cct_codigo AS ser_cct_codigo,
	       ser.cct_codigo_atua AS ser_cct_codigo_atua,
	       pes.nome AS pes_nome
	FROM agh.agh_versoes_documentos dov,
	     agh.agh_documentos dok,
	     agh.agh_atendimentos atd,
	     agh.aip_pacientes pac,
	     agh.rap_servidores ser,
	     agh.rap_pessoas_fisicas pes
	WHERE dov.dok_seq = dok.seq AND dok.atd_seq = atd.seq AND atd.pac_codigo = pac.codigo AND dov.ser_matricula_resp = ser.matricula AND dov.ser_vin_codigo_resp = ser.vin_codigo AND ser.pes_codigo = pes.codigo
	UNION
	SELECT dov.seq AS dov_seq,
	       dov.criado_em AS dov_criado_em,
	       dov.situacao AS dov_situacao,
	       dok.tipo AS dok_tipo,
	       pac.codigo AS pac_codigo,
	       pac.prontuario AS pac_prontuario,
	       pac.nome AS pac_nome,
	       ser.matricula AS ser_matricula,
	       ser.vin_codigo AS ser_vin_codigo,
	       ser.cct_codigo AS ser_cct_codigo,
	       ser.cct_codigo_atua AS ser_cct_codigo_atua,
	       pes.nome AS pes_nome
	FROM agh.agh_versoes_documentos dov,
	     agh.agh_documentos dok,
	     agh.mbc_cirurgias mbc,
	     agh.aip_pacientes pac,
	     agh.rap_servidores ser,
	     agh.rap_pessoas_fisicas pes
	WHERE dov.dok_seq = dok.seq AND mbc.pac_codigo = pac.codigo AND dov.ser_matricula_resp = ser.matricula AND dov.ser_vin_codigo_resp = ser.vin_codigo AND ser.pes_codigo = pes.codigo AND mbc.seq = dok.crg_seq
	UNION
	SELECT dov.seq AS dov_seq,
	       dov.criado_em AS dov_criado_em,
	       dov.situacao AS dov_situacao,
	       dok.tipo AS dok_tipo,
	       pac.codigo AS pac_codigo,
	       pac.prontuario AS pac_prontuario,
	       pac.nome AS pac_nome,
	       ser.matricula AS ser_matricula,
	       ser.vin_codigo AS ser_vin_codigo,
	       ser.cct_codigo AS ser_cct_codigo,
	       ser.cct_codigo_atua AS ser_cct_codigo_atua,
	       pes.nome AS pes_nome
	FROM agh.agh_versoes_documentos dov,
	     agh.agh_documentos dok,
	     agh.mbc_ficha_anestesias fic,
	     agh.aip_pacientes pac,
	     agh.rap_servidores ser,
	     agh.rap_pessoas_fisicas pes
	WHERE fic.seq = dok.fic_seq AND fic.pac_codigo = pac.codigo AND dov.ser_matricula_resp = ser.matricula AND dov.ser_vin_codigo_resp = ser.vin_codigo AND ser.pes_codigo = pes.codigo AND dov.dok_seq = dok.seq
	UNION
	SELECT dov.seq AS dov_seq,
	       dov.criado_em AS dov_criado_em,
	       dov.situacao AS dov_situacao,
	       dok.tipo AS dok_tipo,
	       pac.codigo AS pac_codigo,
	       pac.prontuario AS pac_prontuario,
	       pac.nome AS pac_nome,
	       ser.matricula AS ser_matricula,
	       ser.vin_codigo AS ser_vin_codigo,
	       ser.cct_codigo AS ser_cct_codigo,
	       ser.cct_codigo_atua AS ser_cct_codigo_atua,
	       pes.nome AS pes_nome
	FROM agh.agh_versoes_documentos dov,
	     agh.agh_documentos dok,
	     agh.mam_nota_adicional_evolucoes npo,
	     agh.aip_pacientes pac,
	     agh.rap_servidores ser,
	     agh.rap_pessoas_fisicas pes
	WHERE npo.seq = dok.npo_seq AND npo.pac_codigo = pac.codigo AND npo.seq = dok.npo_seq AND dov.dok_seq = dok.seq AND dov.ser_matricula_resp = ser.matricula AND dov.ser_vin_codigo_resp = ser.vin_codigo AND ser.pes_codigo = pes.codigo
	UNION
	SELECT dov.seq AS dov_seq,
	       dov.criado_em AS dov_criado_em,
	       dov.situacao AS dov_situacao,
	       dok.tipo AS dok_tipo,
	       pac.codigo AS pac_codigo,
	       pac.prontuario AS pac_prontuario,
	       pac.nome AS pac_nome,
	       ser.matricula AS ser_matricula,
	       ser.vin_codigo AS ser_vin_codigo,
	       ser.cct_codigo AS ser_cct_codigo,
	       ser.cct_codigo_atua AS ser_cct_codigo_atua,
	       pes.nome AS pes_nome
	FROM agh.agh_versoes_documentos dov,
	     agh.agh_documentos dok,
	     agh.mam_laudo_aihs lai,
	     agh.aip_pacientes pac,
	     agh.rap_servidores ser,
	     agh.rap_pessoas_fisicas pes
	WHERE lai.seq = dok.lai_seq AND lai.pac_codigo = pac.codigo AND dov.dok_seq = dok.seq AND dov.ser_matricula_resp = ser.matricula AND dov.ser_vin_codigo_resp = ser.vin_codigo AND ser.pes_codigo = pes.codigo
	UNION
	SELECT dov.seq AS dov_seq,
	       dov.criado_em AS dov_criado_em,
	       dov.situacao AS dov_situacao,
	       dok.tipo AS dok_tipo,
	       pac.codigo AS pac_codigo,
	       pac.prontuario AS pac_prontuario,
	       pac.nome AS pac_nome,
	       ser.matricula AS ser_matricula,
	       ser.vin_codigo AS ser_vin_codigo,
	       ser.cct_codigo AS ser_cct_codigo,
	       ser.cct_codigo_atua AS ser_cct_codigo_atua,
	       pes.nome AS pes_nome
	FROM agh.agh_versoes_documentos dov,
	     agh.agh_documentos dok,
	     agh.mbc_agendas agd,
	     agh.aip_pacientes pac,
	     agh.rap_servidores ser,
	     agh.rap_pessoas_fisicas pes
	WHERE agd.seq = dok.agd_seq AND agd.pac_codigo = pac.codigo AND dov.dok_seq = dok.seq AND dov.ser_matricula_resp = ser.matricula AND dov.ser_vin_codigo_resp = ser.vin_codigo AND ser.pes_codigo = pes.codigo
	UNION
	SELECT dov.seq AS dov_seq,
	       dov.criado_em AS dov_criado_em,
	       dov.situacao AS dov_situacao,
	       dok.tipo AS dok_tipo,
	       pac.codigo AS pac_codigo,
	       pac.prontuario AS pac_prontuario,
	       pac.nome AS pac_nome,
	       ser.matricula AS ser_matricula,
	       ser.vin_codigo AS ser_vin_codigo,
	       ser.cct_codigo AS ser_cct_codigo,
	       ser.cct_codigo_atua AS ser_cct_codigo_atua,
	       pes.nome AS pes_nome
	FROM agh.agh_versoes_documentos dov,
	     agh.agh_documentos dok,
	     agh.ael_atendimento_diversos atv,
	     agh.aip_pacientes pac,
	     agh.rap_servidores ser,
	     agh.rap_pessoas_fisicas pes
	WHERE atv.seq = dok.agd_seq AND atv.pac_codigo = pac.codigo AND dov.dok_seq = dok.seq AND dov.ser_matricula_resp = ser.matricula AND dov.ser_vin_codigo_resp = ser.vin_codigo AND ser.pes_codigo = pes.codigo;

	alter table agh.v_agh_versoes_documentos owner to postgres;
	
	grant insert, select, update, delete, truncate, references, trigger on agh.v_agh_versoes_documentos to acesso_completo;
	grant insert, select, update, delete, truncate, references, trigger on agh.v_agh_versoes_documentos to acesso_leitura;
	grant insert, select, update, delete, truncate, references, trigger on agh.v_agh_versoes_documentos to escrita_integra;
	
	create view agh.v_afa_prcr_disp_mdtos_painel
	            (atd_seq, seq, dt_referencia, dthr_inicio, dthr_fim, atd_seq_local, prontuario, lto_lto_id, qrt_numero,
	             unf_seq, trp_seq, codigo, nome, apa_atd_seq, apa_seq, seqp, countsolic, countdisp, countconf, countenv,
	             counttriado, countocorr, unf_descricao, configprescmed, dataprescmed, configprescmedassinada,
	             esta_assinada, clinica_codigo)
	as
	SELECT x.atd_seq,
	       x.seq,
	       x.dt_referencia,
	       x.dthr_inicio,
	       x.dthr_fim,
	       x.atd_seq_local,
	       x.prontuario,
	       x.lto_lto_id,
	       x.qrt_numero,
	       x.unf_seq,
	       x.trp_seq,
	       x.codigo,
	       x.nome,
	       x.apa_atd_seq,
	       x.apa_seq,
	       x.seqp,
	       x.countsolic,
	       x.countdisp,
	       x.countconf,
	       x.countenv,
	       x.counttriado,
	       x.countocorr,
	       (((COALESCE(unf.andar, ''::character varying)::text || ' '::text) ||
	         COALESCE(unf.ind_ala, ''::character varying)::text) || ' - '::text) ||
	       COALESCE(unf.descricao, ''::character varying)::text AS unf_descricao,
	       CASE
	           WHEN
	                   CASE
	                       WHEN atd.ind_pac_atendimento::text = 'S'::text AND cuf.unf_seq IS NOT NULL THEN 'false'::text
	                       ELSE 'true'::text
	                       END = 'true'::text THEN ''::text
	           WHEN NOT ((SELECT count(*) AS count
	                      FROM agh.mpm_prescricao_medicas pm
	                      WHERE pm.atd_seq = atd.seq
	                        AND pm.ser_matricula_valida IS NOT NULL
	                        AND pm.ser_vin_codigo_valida IS NOT NULL
	                        AND pm.dthr_fim > now())) > 0 THEN 'PRESCRICAO_NAO_REALIZADA'::text
	           WHEN NOT ((SELECT count(*) AS count
	                      FROM agh.mpm_prescricao_medicas pm
	                      WHERE pm.atd_seq = atd.seq
	                        AND pm.ser_matricula_valida IS NOT NULL
	                        AND pm.ser_vin_codigo_valida IS NOT NULL
	                        AND pm.dthr_inicio > now()
	                        AND to_char(unf.hrio_validade_pme, 'HH24:mi'::text) =
	                            to_char(pm.dthr_inicio, 'HH24:mi'::text))) > 0 THEN 'PRESCRICAO_VENCE_NO_DIA'::text
	           ELSE 'PRESCRICAO_VENCE_NO_DIA_SEGUINTE'::text
	           END                                              AS configprescmed,
	       CASE
	           WHEN
	                   CASE
	                       WHEN atd.ind_pac_atendimento::text = 'S'::text AND cuf.unf_seq IS NOT NULL THEN 'false'::text
	                       ELSE 'true'::text
	                       END = 'true'::text THEN NULL::timestamp without time zone
	           WHEN NOT ((SELECT count(*) AS count
	                      FROM agh.mpm_prescricao_medicas pm
	                      WHERE pm.atd_seq = atd.seq
	                        AND pm.ser_matricula_valida IS NOT NULL
	                        AND pm.ser_vin_codigo_valida IS NOT NULL
	                        AND pm.dthr_fim > now())) > 0 THEN NULL::timestamp without time zone
	           ELSE (SELECT max(pm.dthr_inicio) AS dthr_inicio
	                 FROM agh.mpm_prescricao_medicas pm
	                 WHERE pm.atd_seq = atd.seq
	                   AND pm.ser_matricula_valida IS NOT NULL
	                   AND pm.ser_vin_codigo_valida IS NOT NULL
	                   AND to_char(unf.hrio_validade_pme, 'HH24:mi'::text) = to_char(pm.dthr_inicio, 'HH24:mi'::text))
	           END                                              AS dataprescmed,
	       CASE
	           WHEN
	                   CASE
	                       WHEN atd.ind_pac_atendimento::text = 'S'::text AND cuf.unf_seq IS NOT NULL THEN 'false'::text
	                       ELSE 'true'::text
	                       END = 'true'::text THEN ''::text
	           WHEN NOT ((SELECT count(*) AS count
	                      FROM agh.mpm_prescricao_medicas pm
	                      WHERE pm.atd_seq = atd.seq
	                        AND pm.ser_matricula_valida IS NOT NULL
	                        AND pm.ser_vin_codigo_valida IS NOT NULL
	                        AND pm.dthr_fim > now())) > 0 THEN ''::text
	           WHEN NOT ((SELECT count(*) AS count
	                      FROM agh.mpm_prescricao_medicas pm
	                      WHERE pm.atd_seq = atd.seq
	                        AND pm.ser_matricula_valida IS NOT NULL
	                        AND pm.ser_vin_codigo_valida IS NOT NULL
	                        AND pm.dthr_inicio > now()
	                        AND to_char(unf.hrio_validade_pme, 'HH24:mi'::text) =
	                            to_char(pm.dthr_inicio, 'HH24:mi'::text))) > 0 THEN
	               CASE
	                   WHEN ((SELECT count(docs.pac_codigo) AS count
	                          FROM agh.v_agh_versoes_documentos docs
	                          WHERE docs.dov_situacao::text = 'A'::text
	                            AND docs.dok_tipo::text = 'PM'::text
	                            AND docs.pac_codigo = atd.pac_codigo)) > 0 THEN 'ASSINADO'::text
	                   ELSE ''::text
	                   END
	           ELSE
	               CASE
	                   WHEN ((SELECT count(docs.pac_codigo) AS count
	                          FROM agh.v_agh_versoes_documentos docs
	                          WHERE docs.dov_situacao::text = 'A'::text
	                            AND docs.dok_tipo::text = 'PM'::text
	                            AND docs.pac_codigo = atd.pac_codigo)) > 0 THEN 'ASSINADO'::text
	                   ELSE ''::text
	                   END
	           END                                              AS configprescmedassinada,
	       CASE
	           WHEN ((SELECT count(docs.pac_codigo) AS count
	                  FROM agh.v_agh_versoes_documentos docs
	                  WHERE docs.dov_situacao::text = 'A'::text
	                    AND docs.dok_tipo::text = 'PM'::text
	                    AND docs.pac_codigo = atd.pac_codigo)) > 0 THEN 'ASSINADO'::text
	           ELSE ''::text
	           END                                              AS esta_assinada,
	       clinicas.codigo                                      AS clinica_codigo
	FROM agh.v_afa_prcr_disp_mdtos x
	         JOIN agh.agh_atendimentos atd ON atd.seq = x.atd_seq
	         LEFT JOIN agh.agh_unidades_funcionais unf ON atd.unf_seq = unf.seq
	         LEFT JOIN agh.agh_caract_unid_funcionais cuf
	                   ON cuf.unf_seq = atd.unf_seq AND cuf.caracteristica::text = 'Pme Informatizada'::text
	         LEFT JOIN agh.agh_clinicas clinicas ON unf.clc_codigo = clinicas.codigo;
	
	alter table agh.v_afa_prcr_disp_mdtos_painel
	    owner to postgres;
	
	
	create view agh.v_mpm_lista_pac_internados
	            (atd_seq, prontuario, pac_codigo, nome, nome_social, data_inicio_atendimento, data_fim_atendimento,
	             data_nascimento, atd_ser_matricula, atd_ser_vin_codigo, ser_matricula, ser_vin_codigo,
	             ind_sit_sumario_alta, origem, esp_seq, unf_seq, ind_pac_cpa, ind_pac_atendimento, lto_lto_id, qrt_numero,
	             nome_responsavel, possui_plano_altas, local, status_prescricao, status_sumario_alta,
	             status_exames_nao_vistos, status_pendencia_documento, status_paciente_pesquisa, status_evolucao,
	             status_certificacao_digital, disable_button_alta_obito, disable_button_prescrever, label_alta, label_obito,
	             ind_gmr, tem_unf_caract_anamnese_evolucao, status_anamnese_evolucao, status_dosagem_maxima)
	as
	SELECT atd.seq            AS atd_seq,
	       pac.prontuario,
	       atd.pac_codigo,
	       pac.nome,
	       pac.nome_social,
	       atd.dthr_inicio    AS data_inicio_atendimento,
	       atd.dthr_fim       AS data_fim_atendimento,
	       pac.dt_nascimento  AS data_nascimento,
	       atd.ser_matricula  AS atd_ser_matricula,
	       atd.ser_vin_codigo AS atd_ser_vin_codigo,
	       atd.ser_matricula,
	       atd.ser_vin_codigo,
	       atd.ind_sit_sumario_alta,
	       atd.origem,
	       atd.esp_seq,
	       atd.unf_seq,
	       atd.ind_pac_cpa,
	       atd.ind_pac_atendimento,
	       atd.lto_lto_id,
	       atd.qrt_numero,
	       CASE
	           WHEN rapf.nome_usual IS NULL OR rapf.nome_usual::text = ''::text THEN rapf.nome
	           ELSE rapf.nome_usual
	           END            AS nome_responsavel,
	       CASE
	           WHEN atd.origem::text = 'I'::text AND ((SELECT max(cpa.criado_em) AS max
	                                                   FROM agh.mpm_control_prev_altas cpa
	                                                   WHERE cpa.atd_seq = atd.seq
	                                                     AND cpa.resposta::text = 'S'::text
	                                                     AND cpa.dt_fim IS NOT NULL
	                                                     AND date_part('day'::text, cpa.dt_fim::timestamp with time zone - now()) >=
	                                                         0::double precision
	                                                     AND date_part('day'::text, cpa.dt_fim::timestamp with time zone - now()) <=
	                                                         2::double precision)) IS NOT NULL THEN 'true'::text
	           WHEN atd.origem::text = 'N'::text AND ((SELECT max(cpa.criado_em) AS max
	                                                   FROM agh.mpm_control_prev_altas cpa
	                                                            JOIN agh.agh_atendimentos atd_mae
	                                                                 ON atd_mae.seq = cpa.atd_seq AND atd_mae.origem::text = 'I'::text
	                                                   WHERE cpa.atd_seq = atd.atd_seq_mae
	                                                     AND cpa.resposta::text = 'S'::text
	                                                     AND cpa.dt_fim IS NOT NULL
	                                                     AND date_part('day'::text, cpa.dt_fim::timestamp with time zone - now()) >=
	                                                         0::double precision
	                                                     AND date_part('day'::text, cpa.dt_fim::timestamp with time zone - now()) <=
	                                                         2::double precision)) IS NOT NULL THEN 'true'::text
	           ELSE 'false'::text
	           END            AS possui_plano_altas,
	       CASE
	           WHEN atd.lto_lto_id IS NOT NULL THEN (SELECT ('L:'::text || q.descricao::text) || l.leito::text
	                                                 FROM agh.ain_leitos l
	                                                          JOIN agh.ain_quartos q ON l.qrt_numero = q.numero
	                                                 WHERE l.lto_id::text = atd.lto_lto_id::text)
	           WHEN atd.qrt_numero IS NOT NULL THEN concat('Q:', atd.qrt_numero)
	           ELSE (SELECT (((('U:'::text || unf_1.andar::text) || ' '::text) || unf_1.ind_ala::text) || ' - '::text) ||
	                        unf_1.descricao::text
	                 FROM agh.agh_unidades_funcionais unf_1
	                 WHERE unf_1.seq = atd.unf_seq)
	           END            AS local,
	       CASE
	           WHEN
	                   CASE
	                       WHEN atd.ind_pac_atendimento::text = 'S'::text AND cuf.unf_seq IS NOT NULL THEN 'false'::text
	                       ELSE 'true'::text
	                       END = 'true'::text THEN ''::text
	           WHEN NOT ((SELECT count(*) AS count
	                      FROM agh.mpm_prescricao_medicas pm
	                      WHERE pm.atd_seq = atd.seq
	                        AND pm.ser_matricula_valida IS NOT NULL
	                        AND pm.ser_vin_codigo_valida IS NOT NULL
	                        AND pm.dthr_fim > now())) > 0 THEN 'PRESCRICAO_NAO_REALIZADA'::text
	           WHEN NOT ((SELECT count(*) AS count
	                      FROM agh.mpm_prescricao_medicas pm
	                      WHERE pm.atd_seq = atd.seq
	                        AND pm.ser_matricula_valida IS NOT NULL
	                        AND pm.ser_vin_codigo_valida IS NOT NULL
	                        AND pm.dthr_inicio > now()
	                        AND to_char(unf.hrio_validade_pme, 'HH24:mi'::text) =
	                            to_char(pm.dthr_inicio, 'HH24:mi'::text))) > 0 THEN 'PRESCRICAO_VENCE_NO_DIA'::text
	           ELSE 'PRESCRICAO_VENCE_NO_DIA_SEGUINTE'::text
	           END            AS status_prescricao,
	       CASE
	           WHEN atd.ind_pac_atendimento::text = 'N'::text AND atd.ctrl_sumr_alta_pendente::text = 'E'::text
	               THEN 'SUMARIO_ALTA_NAO_ENTREGUE_SAMIS'::text
	           WHEN atd.ind_pac_atendimento::text = 'N'::text AND atd.ctrl_sumr_alta_pendente::text <> 'E'::text
	               THEN 'SUMARIO_ALTA_NAO_REALIZADO'::text
	           ELSE ''::text
	           END            AS status_sumario_alta,
	       CASE
	           WHEN ((SELECT count(*) AS count
	                  FROM agh.ael_item_solicitacao_exames ise
	                           JOIN agh.ael_solicitacao_exames soe ON ise.soe_seq = soe.seq
	                  WHERE soe.atd_seq = atd.seq
	                    AND ise.sit_codigo::text = 'LI'::text
	                    AND NOT (EXISTS(SELECT its.ise_seqp,
	                                           its.ise_soe_seq
	                                    FROM agh.ael_item_solic_consultados its
	                                             JOIN agh.ael_item_solicitacao_exames sub_ise
	                                                  ON its.ise_seqp = sub_ise.seqp AND its.ise_soe_seq = sub_ise.soe_seq
	                                             JOIN agh.ael_solicitacao_exames sub_soe ON sub_ise.soe_seq = sub_soe.seq
	                                    WHERE its.ise_soe_seq = ise.soe_seq
	                                      AND its.ise_seqp = ise.seqp
	                                      AND sub_soe.atd_seq = atd.seq
	                                      AND sub_ise.sit_codigo::text = 'LI'::text))
	                    AND NOT (EXISTS(SELECT iri.ise_seqp,
	                                           iri.ise_soe_seq
	                                    FROM agh.ael_itens_resul_impressao iri
	                                    WHERE iri.ise_soe_seq = ise.soe_seq
	                                      AND iri.ise_seqp = ise.seqp)))) > 0 THEN 'RESULTADOS_NAO_VISUALIZADOS'::text
	           WHEN ((SELECT count(*) AS count
	                  FROM agh.ael_item_solicitacao_exames ise
	                           JOIN agh.ael_solicitacao_exames soe ON ise.soe_seq = soe.seq
	                  WHERE soe.atd_seq = atd.seq
	                    AND ise.sit_codigo::text = 'LI'::text
	                    AND NOT (EXISTS(SELECT its.ise_seqp,
	                                           its.ise_soe_seq
	                                    FROM agh.ael_item_solic_consultados its
	                                             JOIN agh.ael_item_solicitacao_exames sub_ise
	                                                  ON its.ise_seqp = sub_ise.seqp AND its.ise_soe_seq = sub_ise.soe_seq
	                                             JOIN agh.ael_solicitacao_exames sub_soe ON sub_ise.soe_seq = sub_soe.seq
	                                    WHERE its.ise_soe_seq = ise.soe_seq
	                                      AND its.ise_seqp = ise.seqp
	                                      AND sub_soe.atd_seq = atd.seq
	                                      AND sub_ise.sit_codigo::text = 'LI'::text
	                                      AND its.ser_matricula = atd.ser_matricula
	                                      AND its.ser_vin_codigo = atd.ser_vin_codigo))
	                    AND NOT (EXISTS(SELECT iri.ise_seqp,
	                                           iri.ise_soe_seq
	                                    FROM agh.ael_itens_resul_impressao iri
	                                    WHERE iri.ise_soe_seq = ise.soe_seq
	                                      AND iri.ise_seqp = ise.seqp)))) > 0 THEN 'RESULTADOS_VISUALIZADOS_OUTRO_MEDICO'::text
	           ELSE ''::text
	           END            AS status_exames_nao_vistos,
	       CASE
	           WHEN ((SELECT count(*) AS count
	                  FROM agh.mpm_laudos lau
	                  WHERE lau.atd_seq = atd.seq
	                    AND lau.tuo_seq IS NOT NULL
	                    AND lau.justificativa IS NULL)) > 0 THEN 'PENDENCIA_LAUDO_UTI'::text
	           ELSE ''::text
	           END            AS status_pendencia_documento,
	       CASE
	           WHEN ((SELECT count(projetos.pac_codigo) AS count
	                  FROM agh.ael_projeto_pacientes projetos
	                  WHERE projetos.pac_codigo = atd.pac_codigo
	                    AND (projetos.dt_fim IS NULL OR projetos.dt_fim >= now())
	                    AND (projetos.jex_seq IS NULL OR (EXISTS(SELECT jex_.seq AS y0_
	                                                             FROM agh.ael_justificativa_exclusoes jex_
	                                                             WHERE jex_.seq = projetos.jex_seq
	                                                               AND jex_.ind_mostra_telas::text = 'S'::text)))
	                    AND (EXISTS(SELECT pjq_.seq AS y0_
	                                FROM agh.ael_projeto_pesquisas pjq_
	                                WHERE pjq_.seq = projetos.pjq_seq
	                                  AND (pjq_.dt_fim IS NULL OR pjq_.dt_fim >= now()))))) > 0 THEN 'PACIENTE_PESQUISA'::text
	           ELSE ''::text
	           END            AS status_paciente_pesquisa,
	       CASE
	           WHEN atd.origem::text = 'I'::text OR atd.origem::text = 'N'::text THEN
	               CASE
	                   WHEN ((SELECT count(*) AS count
	                          FROM agh.mam_evolucoes evo
	                          WHERE evo.atd_seq = atd.seq
	                            AND date_part('day'::text, evo.dthr_valida::timestamp with time zone - now()) =
	                                0::double precision
	                            AND evo.dthr_valida_mvto IS NULL)) > 0 THEN
	                       CASE
	                           WHEN ((SELECT cprf.cag_seq AS seq
	                                  FROM agh.cse_categoria_perfis cprf
	                                           JOIN agh.cse_categoria_profissionais csecategor1_
	                                                ON cprf.cag_seq = csecategor1_.seq
	                                  WHERE csecategor1_.ind_situacao::text = 'A'::text
	                                    AND cprf.ind_situacao::text = 'A'::text
	                                    AND (cprf.per_nome::text IN (SELECT cprf_1.nome AS y0_
	                                                                 FROM casca.csc_perfil cprf_1
	                                                                          JOIN casca.csc_perfis_usuarios perfisusua1_
	                                                                               ON cprf_1.id = perfisusua1_.id_perfil
	                                                                          JOIN casca.csc_usuario usuario2_ ON perfisusua1_.id_usuario = usuario2_.id
	                                                                          JOIN agh.rap_servidores srv
	                                                                               ON lower(srv.usuario::text) = lower(usuario2_.login::text)
	                                                                 WHERE cprf_1.situacao::text = 'A'::text
	                                                                   AND (perfisusua1_.dthr_expiracao IS NULL OR
	                                                                        perfisusua1_.dthr_expiracao > now())
	                                                                   AND usuario2_.ativo = true
	                                                                   AND srv.matricula = atd.ser_matricula
	                                                                   AND srv.vin_codigo = atd.ser_vin_codigo))
	                                  LIMIT 1)) = ((SELECT agh_parametros.vlr_numerico
	                                                FROM agh.agh_parametros
	                                                WHERE agh_parametros.nome::text = 'P_CATEG_PROF_MEDICO'::text))
	                               THEN 'EVOLUCAO'::text
	                           WHEN ((SELECT cprf.cag_seq AS seq
	                                  FROM agh.cse_categoria_perfis cprf
	                                           JOIN agh.cse_categoria_profissionais csecategor1_
	                                                ON cprf.cag_seq = csecategor1_.seq
	                                  WHERE csecategor1_.ind_situacao::text = 'A'::text
	                                    AND cprf.ind_situacao::text = 'A'::text
	                                    AND (cprf.per_nome::text IN (SELECT cprf_1.nome AS y0_
	                                                                 FROM casca.csc_perfil cprf_1
	                                                                          JOIN casca.csc_perfis_usuarios perfisusua1_
	                                                                               ON cprf_1.id = perfisusua1_.id_perfil
	                                                                          JOIN casca.csc_usuario usuario2_ ON perfisusua1_.id_usuario = usuario2_.id
	                                                                          JOIN agh.rap_servidores srv
	                                                                               ON lower(srv.usuario::text) = lower(usuario2_.login::text)
	                                                                 WHERE cprf_1.situacao::text = 'A'::text
	                                                                   AND (perfisusua1_.dthr_expiracao IS NULL OR
	                                                                        perfisusua1_.dthr_expiracao > now())
	                                                                   AND usuario2_.ativo = true
	                                                                   AND srv.matricula = atd.ser_matricula
	                                                                   AND srv.vin_codigo = atd.ser_vin_codigo))
	                                  LIMIT 1)) = ((SELECT agh_parametros.vlr_numerico
	                                                FROM agh.agh_parametros
	                                                WHERE agh_parametros.nome::text = 'P_CATEG_PROF_OUTROS'::text))
	                               THEN 'EVOLUCAO'::text
	                           WHEN ((SELECT cprf.cag_seq AS seq
	                                  FROM agh.cse_categoria_perfis cprf
	                                           JOIN agh.cse_categoria_profissionais csecategor1_
	                                                ON cprf.cag_seq = csecategor1_.seq
	                                  WHERE csecategor1_.ind_situacao::text = 'A'::text
	                                    AND cprf.ind_situacao::text = 'A'::text
	                                    AND (cprf.per_nome::text IN (SELECT cprf_1.nome AS y0_
	                                                                 FROM casca.csc_perfil cprf_1
	                                                                          JOIN casca.csc_perfis_usuarios perfisusua1_
	                                                                               ON cprf_1.id = perfisusua1_.id_perfil
	                                                                          JOIN casca.csc_usuario usuario2_ ON perfisusua1_.id_usuario = usuario2_.id
	                                                                          JOIN agh.rap_servidores srv
	                                                                               ON lower(srv.usuario::text) = lower(usuario2_.login::text)
	                                                                 WHERE cprf_1.situacao::text = 'A'::text
	                                                                   AND (perfisusua1_.dthr_expiracao IS NULL OR
	                                                                        perfisusua1_.dthr_expiracao > now())
	                                                                   AND usuario2_.ativo = true
	                                                                   AND srv.matricula = atd.ser_matricula
	                                                                   AND srv.vin_codigo = atd.ser_vin_codigo))
	                                  LIMIT 1)) = ((SELECT agh_parametros.vlr_numerico
	                                                FROM agh.agh_parametros
	                                                WHERE agh_parametros.nome::text = 'P_CATEG_PROF_ENF'::text)) THEN
	                               CASE
	                                   WHEN ((SELECT count(*) AS count
	                                          FROM agh.mam_item_evolucoes iev
	                                          WHERE iev.evo_seq = ((SELECT evo.seq
	                                                                FROM agh.mam_evolucoes evo
	                                                                WHERE evo.atd_seq = atd.seq
	                                                                  AND date_part('day'::text,
	                                                                                evo.dthr_valida::timestamp with time zone - now()) =
	                                                                      0::double precision
	                                                                  AND evo.dthr_valida_mvto IS NULL
	                                                                LIMIT 1))
	                                            AND (iev.tie_seq IN (SELECT mam_tipo_item_evolucoes.seq
	                                                                 FROM agh.mam_tipo_item_evolucoes
	                                                                 WHERE mam_tipo_item_evolucoes.sigla::text = 'C'::text)))) >
	                                        0 THEN 'EVOLUCAO'::text
	                                   ELSE ''::text
	                                   END
	                           ELSE ''::text
	                           END
	                   ELSE ''::text
	                   END
	           ELSE ''::text
	           END            AS status_evolucao,
	       CASE
	           WHEN ((SELECT count(docs.pac_codigo) AS count
	                  FROM agh.v_agh_versoes_documentos docs
	                  WHERE docs.dov_situacao::text = 'P'::text
	                    AND docs.pac_codigo = atd.pac_codigo)) > 0 THEN 'PENDENTE'::text
	           ELSE ''::text
	           END            AS status_certificacao_digital,
	       CASE
	           WHEN ((SELECT count(*) AS count
	                  FROM agh.mpm_sumario_altas sa
	                  WHERE sa.atd_seq = atd.seq
	                    AND sa.mam_seq IS NOT NULL)) > 0 THEN 'true'::text
	           WHEN ((SELECT count(*) AS count
	                  FROM agh.mpm_alta_sumarios asu
	                  WHERE asu.apa_atd_seq = atd.seq
	                    AND asu.ind_concluido::text = 'S'::text)) > 0 THEN 'true'::text
	           WHEN (((SELECT agh_parametros.vlr_texto
	                   FROM agh.agh_parametros
	                   WHERE agh_parametros.nome::text = 'P_BLOQUEIA_PAC_EMERG'::text))::text) <> 'S'::text AND
	                ((SELECT count(*) AS count
	                  FROM agh.agh_caract_unid_funcionais cuf2
	                  WHERE cuf2.unf_seq = atd.unf_seq
	                    AND cuf2.caracteristica::text = 'Atend emerg terreo'::text)) > 0 THEN 'true'::text
	           ELSE 'false'::text
	           END            AS disable_button_alta_obito,
	       CASE
	           WHEN atd.ind_pac_atendimento::text = 'S'::text AND cuf.unf_seq IS NOT NULL THEN 'false'::text
	           ELSE 'true'::text
	           END            AS disable_button_prescrever,
	       CASE
	           WHEN atd.ind_pac_atendimento::text = 'N'::text AND atd.ctrl_sumr_alta_pendente::text <> 'E'::text
	               THEN 'SUMARIO_ALTA'::text
	           ELSE 'ALTA'::text
	           END            AS label_alta,
	       CASE
	           WHEN atd.ind_pac_atendimento::text = 'N'::text AND atd.ctrl_sumr_alta_pendente::text <> 'E'::text
	               THEN 'SUMARIO_OBITO'::text
	           ELSE 'OBITO'::text
	           END            AS label_obito,
	       CASE
	           WHEN ((SELECT count(*) AS count
	                  FROM agh.mci_notificacao_gmr gmr
	                  WHERE gmr.pac_codigo = atd.pac_codigo
	                    AND gmr.ind_notificacao_ativa::text = 'S'::text)) > 0 THEN 'true'::text
	           ELSE 'false'::text
	           END            AS ind_gmr,
	       CASE
	           WHEN ((SELECT count(*) AS count
	                  FROM agh.agh_caract_unid_funcionais car
	                  WHERE car.caracteristica::text = 'Anamnese/Evolução Eletrônica'::text
	                    AND car.unf_seq = atd.unf_seq)) > 0 THEN 'true'::text
	           ELSE 'false'::text
	           END            AS tem_unf_caract_anamnese_evolucao,
	       CASE
	           WHEN ((SELECT count(*) AS count
	                  FROM agh.mpm_anamneses ana
	                           JOIN agh.agh_atendimentos atd1 ON atd1.seq = ana.atd_seq
	                           JOIN agh.rap_servidores rap
	                                ON rap.matricula = atd1.ser_matricula AND rap.vin_codigo = atd1.ser_vin_codigo
	                           JOIN agh.rap_pessoas_fisicas pes ON pes.codigo = rap.pes_codigo
	                           JOIN agh.agh_unidades_funcionais unf_1 ON unf_1.seq = atd1.unf_seq
	                           JOIN agh.agh_caract_unid_funcionais car ON car.unf_seq = unf_1.seq
	                  WHERE ana.atd_seq = atd.seq)) > 0 THEN (SELECT DISTINCT CASE ana.ind_pendente
	                                                                              WHEN 'R'::text
	                                                                                  THEN 'ANAMNESE_NAO_REALIZADA'::text
	                                                                              WHEN 'P'::text THEN 'ANAMNESE_PENDENTE'::text
	                                                                              WHEN 'V'::text THEN
	                                                                                  CASE
	                                                                                      WHEN ((SELECT count(*) AS count
	                                                                                             FROM agh.mpm_evolucoes evo
	                                                                                                      JOIN agh.mpm_anamneses ana_1 ON ana_1.seq = evo.ana_seq
	                                                                                             WHERE evo.ana_seq = ana_1.seq
	                                                                                               AND to_char(evo.dthr_referencia, 'YYYYMMDD'::text) =
	                                                                                                   to_char(now(), 'YYYYMMDD'::text)
	                                                                                               AND evo.ind_pendente::text <> 'R'::text)) =
	                                                                                           0
	                                                                                          THEN 'EVOLUCAO_DO_DIA_NAO_REALIZADA'::text
	                                                                                      WHEN ((SELECT count(*) AS count
	                                                                                             FROM agh.mpm_evolucoes evo
	                                                                                                      JOIN agh.mpm_anamneses ana_1 ON ana_1.seq = evo.ana_seq
	                                                                                             WHERE evo.ana_seq = ana_1.seq
	                                                                                               AND to_char(evo.dthr_referencia, 'YYYYMMDD'::text) =
	                                                                                                   to_char(now(), 'YYYYMMDD'::text)
	                                                                                               AND evo.ind_pendente::text = 'P'::text)) >
	                                                                                           0
	                                                                                          THEN 'EVOLUCAO_DO_DIA_PENDENTE'::text
	                                                                                      WHEN ((SELECT count(*) AS count
	                                                                                             FROM agh.mpm_evolucoes evo
	                                                                                                      JOIN agh.mpm_anamneses ana_1 ON ana_1.seq = evo.ana_seq
	                                                                                             WHERE evo.ana_seq = ana_1.seq
	                                                                                               AND evo.dthr_referencia > date_trunc('day'::text, now())
	                                                                                               AND evo.ind_pendente::text = 'V'::text)) =
	                                                                                           0
	                                                                                          THEN 'EVOLUCAO_VENCE_NO_DIA_SEGUINTE'::text
	                                                                                      ELSE NULL::text
	                                                                                      END
	                                                                              ELSE NULL::text
	                                                                              END AS "case"
	                                                          FROM agh.mpm_anamneses ana
	                                                                   JOIN agh.agh_atendimentos atd1 ON atd1.seq = ana.atd_seq
	                                                                   JOIN agh.rap_servidores rap
	                                                                        ON rap.matricula = atd1.ser_matricula AND
	                                                                           rap.vin_codigo = atd1.ser_vin_codigo
	                                                                   JOIN agh.rap_pessoas_fisicas pes ON pes.codigo = rap.pes_codigo
	                                                                   JOIN agh.agh_unidades_funcionais unf1 ON unf1.seq = atd1.unf_seq
	                                                                   JOIN agh.agh_caract_unid_funcionais car ON car.unf_seq = unf1.seq
	                                                          WHERE ana.atd_seq = atd.seq
	                                                            AND ana.tql_codigo = raptq.codigo)
	           ELSE 'ANAMNESE_NAO_REALIZADA'::text
	           END            AS status_anamnese_evolucao,
	       CASE
	           WHEN ((SELECT count(*) AS count
	                  FROM agh.mpm_prescricao_medicas mp
	                           JOIN agh.afa_dispensacao_mdtos afad
	                                ON mp.atd_seq = afad.pme_atd_seq AND mp.seq = afad.pme_seq
	                  WHERE mp.atd_seq = atd.seq
	                    AND afad.parecer_farm_dosagem_maxima IS NOT NULL)) > 0 THEN 'S'::text
	           ELSE 'N'::text
	           END            AS status_dosagem_maxima
	FROM agh.agh_atendimentos atd
	         LEFT JOIN agh.agh_caract_unid_funcionais cuf
	                   ON cuf.unf_seq = atd.unf_seq AND cuf.caracteristica::text = 'Pme Informatizada'::text
	         LEFT JOIN agh.agh_unidades_funcionais unf ON atd.unf_seq = unf.seq
	         LEFT JOIN agh.rap_servidores raps
	                   ON raps.matricula = atd.ser_matricula AND raps.vin_codigo = atd.ser_vin_codigo
	         LEFT JOIN agh.rap_pessoas_fisicas rapf ON raps.pes_codigo = rapf.codigo
	         LEFT JOIN agh.rap_qualificacoes rapql
	                   ON rapql.pes_codigo = rapf.codigo AND rapql.ser_matricula = rapf.ser_matricula AND
	                      rapql.ser_vin_codigo = rapf.ser_vin_codigo
	         LEFT JOIN agh.rap_tipos_qualificacao raptq ON raptq.codigo = rapql.tql_codigo
	         LEFT JOIN agh.aip_pacientes pac ON pac.codigo = atd.pac_codigo;
	
	alter table agh.v_mpm_lista_pac_internados owner to postgres;
	
	grant insert, select, update, delete, truncate, references, trigger on agh.v_mpm_lista_pac_internados to acesso_completo;
	grant insert, select, update, delete, truncate, references, trigger on agh.v_mpm_lista_pac_internados to acesso_leitura;
	grant insert, select, update, delete, truncate, references, trigger on agh.v_mpm_lista_pac_internados to escrita_integra;
end $$;
