DO $$
BEGIN

IF NOT EXISTS (
	SELECT
	FROM information_schema.columns
	WHERE table_schema ilike 'agh'
	AND table_name ilike 'mpm_alta_recomendacoes'
	AND column_name ilike 'PALE_SEQ') THEN

alter table agh.mpm_alta_recomendacoes add PALE_SEQ bigint;

END IF;

IF NOT EXISTS (
	SELECT
	FROM information_schema.columns
	WHERE table_schema ilike 'agh'
	AND table_name ilike 'mpm_alta_recomendacoes'
	AND column_name ilike 'PALE_ATD_SEQ') THEN

alter table agh.mpm_alta_recomendacoes add PALE_ATD_SEQ integer;
create index mpm_arc_pale_fk1_i on agh.mpm_alta_recomendacoes (PALE_ATD_SEQ, PALE_SEQ);

END IF;

END $$