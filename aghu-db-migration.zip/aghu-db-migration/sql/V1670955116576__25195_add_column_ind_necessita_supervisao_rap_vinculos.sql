DO $$
BEGIN

	IF NOT EXISTS (
		SELECT 1
		FROM information_schema.columns
		WHERE table_schema = 'agh'
		AND table_name = 'rap_vinculos'
		AND column_name = 'ind_necessita_supervisao'
	) THEN
ALTER TABLE agh.rap_vinculos ADD COLUMN ind_necessita_supervisao varchar(1) NULL DEFAULT 'N'::character varying;
COMMENT ON COLUMN agh.rap_vinculos.ind_necessita_supervisao IS 'vínculo do colaborador necessita de profissional supervisor do atendimento.';
	RAISE NOTICE 'EXECUTADO ALTERAÇÃO: #25195 - Novas coluna agh.rap_vinculos.ind_necessita_supervisao';
END IF;

END $$