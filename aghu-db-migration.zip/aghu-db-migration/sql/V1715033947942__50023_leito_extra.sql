DO
$$
BEGIN

IF
NOT EXISTS (
        select 1 from information_schema.columns
        where table_schema = 'agh'
        AND table_name = 'ain_leitos'
        AND column_name = 'ind_leito_extra') then

    alter table agh.ain_leitos add ind_leito_extra char(1) not null default 'N'
        constraint ain_lto_ck8
            check ((ind_leito_extra)::text = ANY (ARRAY [('S'::character varying)::text, ('N'::character varying)::text]));

    create or replace view agh.v_ain_pesq_leitos
                (lto_lto_id, int_seq, tml_codigo, grupo_mvto_leito, acm_seq, clc_codigo, ind_exclusiv_infeccao, cnv_codigo,
                 grupo_convenio, grupo_conv_part, andar, ind_ala, unf_seq, livre, justificativa, dthr_lancamento,
                 ser_vin_codigo, ser_matricula, sexo_determinante, sexo_ocupacao, pac_codigo, criado_em, tcl_descricao)
    as
    SELECT lto.lto_id                                         AS lto_lto_id,
           lto.int_seq,
           lto.tml_codigo,
           CASE
               WHEN lto.ind_situacao::text = 'I'::text THEN 'IN'::character varying
               ELSE tml.grupo_mvto_leito
    END                                            AS grupo_mvto_leito,
           qrt.acm_seq,
           qrt.clc_codigo,
           qrt.ind_exclusiv_infeccao,
           "int".csp_cnv_codigo                               AS cnv_codigo,
           cnv.grupo_convenio,
           CASE
               WHEN cnv.grupo_convenio::text = 'C'::text THEN 'CP'::text
               WHEN cnv.grupo_convenio::text = 'P'::text THEN 'CP'::text
               ELSE 'S'::text
    END                                            AS grupo_conv_part,
           unf.andar,
           unf.ind_ala,
           unf.seq                                            AS unf_seq,
           CASE
               WHEN tml.grupo_mvto_leito::text = 'L'::text THEN 'LIVRE'::text
               ELSE NULL::text
    END                                            AS livre,
           exl.justificativa,
           CASE
               WHEN tml.grupo_mvto_leito::text = 'O'::text THEN COALESCE(atd.dthr_inicio, exl.dthr_lancamento)
               ELSE exl.dthr_lancamento
    END                                            AS dthr_lancamento,
           exl.ser_vin_codigo,
           exl.ser_matricula,
           qrt.sexo_determinante,
           COALESCE(qrt.sexo_ocupacao, qrt.sexo_determinante) AS sexo_ocupacao,
           "int".pac_codigo,
           exl.criado_em,
           tcl.descricao                                      AS tcl_descricao,
           lto.ind_leito_extra                                AS lto_ind_leito_extra
    FROM agh.ain_leitos lto
             JOIN agh.ain_tipos_mvto_leito tml ON tml.codigo = lto.tml_codigo
             JOIN agh.ain_quartos qrt ON qrt.numero = lto.qrt_numero
             JOIN agh.ain_extrato_leitos exl ON exl.lto_lto_id::text = lto.lto_id::text
             JOIN agh.agh_unidades_funcionais unf ON unf.seq = lto.unf_seq
             LEFT JOIN agh.agh_atendimentos atd ON atd.int_seq = lto.int_seq
             LEFT JOIN agh.ain_caracteristicas_leito clt
                       ON clt.lto_lto_id::text = lto.lto_id::text AND clt.ind_caracteristica_principal::text = 'S'::text
             LEFT JOIN agh.ain_internacoes "int" ON "int".seq = lto.int_seq
             LEFT JOIN agh.ain_tipos_caracteristica_leito tcl ON tcl.seq = clt.tcl_seq
             LEFT JOIN agh.fat_convenios_saude cnv ON cnv.codigo = "int".csp_cnv_codigo
    WHERE tml.grupo_mvto_leito::text <> 'R'::text
      AND exl.lto_lto_id::text = lto.lto_id::text
      AND exl.criado_em = ((SELECT max(exl1.criado_em) AS max
                            FROM agh.ain_extrato_leitos exl1
                            WHERE exl1.lto_lto_id::text = lto.lto_id::text))
    UNION
    SELECT lto.lto_id                                         AS lto_lto_id,
           lto.int_seq,
           lto.tml_codigo,
           tml.grupo_mvto_leito,
           qrt.acm_seq,
           qrt.clc_codigo,
           qrt.ind_exclusiv_infeccao,
           "int".csp_cnv_codigo                               AS cnv_codigo,
           cnv.grupo_convenio,
           CASE
               WHEN cnv.grupo_convenio::text = 'C'::text THEN 'CP'::text
               WHEN cnv.grupo_convenio::text = 'P'::text THEN 'CP'::text
               ELSE 'S'::text
               END                                            AS grupo_conv_part,
           unf.andar,
           unf.ind_ala,
           unf.seq                                            AS unf_seq,
           NULL::text                                         AS livre,
            CASE
                WHEN pac.nome::text = NULL::text THEN exl.justificativa
               ELSE pac.nome
    END                                            AS justificativa,
           exl.dthr_lancamento,
           exl.ser_vin_codigo,
           exl.ser_matricula,
           qrt.sexo_determinante,
           COALESCE(qrt.sexo_ocupacao, qrt.sexo_determinante) AS sexo_ocupacao,
           "int".pac_codigo,
           exl.criado_em,
           tcl.descricao                                      AS tcl_descricao,
           lto.ind_leito_extra                                AS lto_ind_leito_extra
    FROM agh.ain_leitos lto
             JOIN agh.ain_tipos_mvto_leito tml ON tml.codigo = lto.tml_codigo
             JOIN agh.ain_quartos qrt ON qrt.numero = lto.qrt_numero
             JOIN agh.ain_extrato_leitos exl ON exl.lto_lto_id::text = lto.lto_id::text
             JOIN agh.agh_unidades_funcionais unf ON unf.seq = lto.unf_seq
             LEFT JOIN agh.ain_solic_transf_pacientes stp
                       ON stp.lto_lto_id::text = exl.lto_lto_id::text AND stp.int_seq = exl.int_seq AND
                          stp.ind_sit_solic_leito::text = 'A'::text
             LEFT JOIN agh.ain_internacoes "int" ON "int".seq = stp.int_seq
             LEFT JOIN agh.aip_pacientes pac ON pac.codigo = "int".pac_codigo
             LEFT JOIN agh.fat_convenios_saude cnv ON cnv.codigo = "int".csp_cnv_codigo
             LEFT JOIN agh.ain_caracteristicas_leito clt
                       ON clt.lto_lto_id::text = lto.lto_id::text AND clt.ind_caracteristica_principal::text = 'S'::text
             LEFT JOIN agh.ain_tipos_caracteristica_leito tcl ON tcl.seq = clt.tcl_seq
    WHERE exl.criado_em = ((SELECT max(exl1.criado_em) AS max
                            FROM agh.ain_extrato_leitos exl1
                            WHERE exl1.lto_lto_id::text = lto.lto_id::text))
      AND tml.grupo_mvto_leito::text = 'R'::text;
END IF;

END $$;