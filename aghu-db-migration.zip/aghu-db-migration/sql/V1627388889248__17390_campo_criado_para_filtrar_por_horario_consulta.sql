DO
$$
BEGIN

	IF NOT EXISTS (
            SELECT null
            FROM information_schema.columns
            WHERE table_schema = 'agh'
              AND table_name = 'aac_consultas'
              AND column_name ilike 'HORARIO_CONSULTA'
	) THEN
        ALTER TABLE agh.aac_consultas ADD COLUMN HORARIO_CONSULTA character varying(5);
        COMMENT ON COLUMN agh.aac_consultas.HORARIO_CONSULTA IS 'Campo criado para filtrar por horário consulta na pesquisa de grade consulta';
END IF;

END $$