drop view agh.v_lista_prescricao_enfermagem;

create view agh.v_lista_prescricao_enfermagem
            (atd_seq, nome, nome_social, dt_nascimento, dt_atendimento, prontuario, pac_codigo, origem, unf_seq,
             esp_seq, dthr_fim, ser_matricula, ser_vin_codigo, ind_pac_atendimento, ind_pac_cpa, local,
             solic_consultoria_resp, solic_consultoria_solic, ind_alta_medica, germ_multi_resistente,
             paciente_possui_controle, existe_projeto_paciente, cor_germe_multiresistente, habilita_prescricao,
             possui_prescricao_vigente, servidor_prescricao_vigente, servidor_prescricao_futura,
             servidor_presc_vigente_valida, servidor_presc_futura_valida, dthr_fim_prescricao_vigente,
             prescricao_futura, habilita_botao_prescricao, ulcera_pressao, ulcera_medicao, evolucao_pelo_medico,
             evolucao_pelo_outros, evolucao_pelo_enfermeiro, dt_prev_alta, resp_prev_alta, dt_prev_alta_atd_mae,
             resp_prev_alta_atd_mae, origem_atd_mae, status_certificacao_digital, status_certificacao_digital_assinado)
as
SELECT atendimento.seq                                                                                                                AS atd_seq,
       paciente.nome,
       paciente.nome_social,
       paciente.dt_nascimento,
       atendimento.dthr_inicio                                                                                                        AS dt_atendimento,
       atendimento.prontuario,
       paciente.codigo                                                                                                                AS pac_codigo,
       atendimento.origem,
       atendimento.unf_seq,
       atendimento.esp_seq,
       atendimento.dthr_fim,
       atendimento.ser_matricula,
       atendimento.ser_vin_codigo,
       atendimento.ind_pac_atendimento,
       atendimento.ind_pac_cpa,
       CASE
           WHEN atendimento.lto_lto_id IS NOT NULL THEN concat('L:', atendimento.lto_lto_id)
           WHEN atendimento.qrt_numero IS NOT NULL THEN concat('Q:', atendimento.qrt_numero)
           ELSE (SELECT (((('U:'::text || unf.andar::text) || ' '::text) || unf.ind_ala::text) || ' - '::text) ||
                        unf.descricao::text
                 FROM agh.agh_unidades_funcionais unf
                 WHERE unf.seq = atendimento.unf_seq)
           END                                                                                                                        AS local,
       CASE
           WHEN ((SELECT count(*) AS count
                  FROM agh.mpm_solicitacao_consultorias solic
                  WHERE solic.atd_seq = atendimento.seq
                    AND solic.origem::text = 'E'::text
                    AND solic.dthr_resposta IS NOT NULL
                    AND solic.dthr_conhecimento_resposta IS NULL
                    AND solic.ind_situacao::text = 'A'::text)) > 0 THEN 'S'::text
           ELSE 'N'::text
           END                                                                                                                        AS solic_consultoria_resp,
       CASE
           WHEN ((SELECT count(*) AS count
                  FROM agh.mpm_solicitacao_consultorias solic
                  WHERE solic.atd_seq = atendimento.seq
                    AND solic.origem::text = 'E'::text
                    AND solic.dthr_resposta IS NULL
                    AND solic.dthr_conhecimento_resposta IS NULL
                    AND solic.ind_situacao::text = 'A'::text)) > 0 THEN 'S'::text
           ELSE 'N'::text
           END                                                                                                                        AS solic_consultoria_solic,
       (SELECT mpm.ind_concluido
        FROM agh.mpm_alta_sumarios mpm
        WHERE mpm.apa_atd_seq = atendimento.seq
          AND mpm.ind_concluido::text = 'S'::text
          AND (mpm.ind_tipo::text = ANY
               (ARRAY ['ALT'::character varying::text, 'OBT'::character varying::text])))                                             AS ind_alta_medica,
       CASE
           WHEN ((SELECT count(*) AS count
                  FROM agh.mci_notificacao_gmr gmr
                  WHERE gmr.pac_codigo = paciente.codigo
                    AND gmr.ind_notificacao_ativa::text = 'S'::text)) > 0 THEN 'S'::text
           ELSE 'N'::text
           END                                                                                                                        AS germ_multi_resistente,
       CASE
           WHEN ((SELECT count(*) AS count
                  FROM agh.ecp_controle_pacientes contro
                           JOIN agh.ecp_horario_controles hor ON contro.hct_seq = hor.seq
                  WHERE hor.atd_seq = atendimento.seq
                    AND hor.pac_codigo = paciente.codigo)) > 0 THEN 'S'::text
           ELSE 'N'::text
           END                                                                                                                        AS paciente_possui_controle,
       CASE
           WHEN ((SELECT count(*) AS count
                  FROM agh.ael_projeto_pacientes proj_pac
                  WHERE proj_pac.pac_codigo = paciente.codigo
                    AND (proj_pac.dt_fim IS NULL OR proj_pac.dt_fim >= now())
                    AND (proj_pac.jex_seq IS NULL OR (EXISTS(SELECT jex_.seq
                                                             FROM agh.ael_justificativa_exclusoes jex_
                                                             WHERE jex_.seq = proj_pac.jex_seq
                                                               AND jex_.ind_mostra_telas::text = 'S'::text))))) > 0
               THEN 'S'::text
           ELSE 'N'::text
           END                                                                                                                        AS existe_projeto_paciente,
       CASE
           WHEN ((SELECT count(*) AS count
                  FROM agh.mci_notificacao_gmr gmr
                  WHERE gmr.pac_codigo = paciente.codigo
                    AND gmr.ind_notificacao_ativa::text = 'S'::text)) > 0 THEN (SELECT agh_parametros.vlr_texto
                                                                                FROM agh.agh_parametros
                                                                                WHERE agh_parametros.nome::text = 'P_AGHU_COR_NOTIF_GMR'::text)
           ELSE NULL::character varying
           END                                                                                                                        AS cor_germe_multiresistente,
       CASE
           WHEN ((SELECT count(*) AS count
                  FROM agh.agh_caract_unid_funcionais caract_unidade
                  WHERE unidade_funcional.seq = caract_unidade.unf_seq
                    AND caract_unidade.caracteristica::text = 'Pen Informatizada'::text)) > 0 THEN 'S'::text
           ELSE 'N'::text
           END                                                                                                                        AS habilita_prescricao,
       CASE
           WHEN ((SELECT count(*) AS count
                  FROM agh.epe_prescricoes_enfermagem pre
                  WHERE pre.atd_seq = atendimento.seq
                    AND pre.dthr_inicio <= now()
                    AND pre.dthr_fim > now())) > 0 THEN 'S'::text
           ELSE 'N'::text
           END                                                                                                                        AS possui_prescricao_vigente,
       CASE
           WHEN ((SELECT count(*) AS count
                  FROM agh.epe_prescricoes_enfermagem pre
                  WHERE pre.atd_seq = atendimento.seq
                    AND pre.dthr_inicio <= now()
                    AND pre.dthr_fim > now())) > 0 THEN (SELECT pre.ser_matricula_valida
                                                         FROM agh.epe_prescricoes_enfermagem pre
                                                         WHERE pre.atd_seq = atendimento.seq
                                                           AND pre.dthr_inicio <= now()
                                                           AND pre.dthr_fim > now()
                                                         LIMIT 1)
           ELSE NULL::integer
           END                                                                                                                        AS servidor_prescricao_vigente,
       CASE
           WHEN ((SELECT count(*) AS count
                  FROM agh.epe_prescricoes_enfermagem pre
                  WHERE pre.atd_seq = atendimento.seq
                    AND pre.dthr_inicio <= now()
                    AND pre.dthr_fim > now())) > 0 THEN (SELECT pre.ser_matricula
                                                         FROM agh.epe_prescricoes_enfermagem pre
                                                         WHERE pre.atd_seq = atendimento.seq
                                                           AND pre.dthr_inicio > now()
                                                         LIMIT 1)
           ELSE NULL::integer
           END                                                                                                                        AS servidor_prescricao_futura,
       CASE
           WHEN ((SELECT count(*) AS count
                  FROM agh.epe_prescricoes_enfermagem pre
                  WHERE pre.atd_seq = atendimento.seq
                    AND pre.dthr_inicio <= now()
                    AND pre.dthr_fim > now())) > 0 THEN (SELECT pre.ser_matricula_valida
                                                         FROM agh.epe_prescricoes_enfermagem pre
                                                         WHERE pre.atd_seq = atendimento.seq
                                                           AND pre.dthr_inicio <= now()
                                                           AND pre.dthr_fim > now()
                                                         LIMIT 1)
           ELSE NULL::integer
           END                                                                                                                        AS servidor_presc_vigente_valida,
       CASE
           WHEN ((SELECT count(*) AS count
                  FROM agh.epe_prescricoes_enfermagem pre
                  WHERE pre.atd_seq = atendimento.seq
                    AND pre.dthr_inicio <= now()
                    AND pre.dthr_fim > now())) > 0 THEN (SELECT pre.ser_matricula_valida
                                                         FROM agh.epe_prescricoes_enfermagem pre
                                                         WHERE pre.atd_seq = atendimento.seq
                                                           AND pre.dthr_inicio > now()
                                                         LIMIT 1)
           ELSE NULL::integer
           END                                                                                                                        AS servidor_presc_futura_valida,
       CASE
           WHEN ((SELECT count(*) AS count
                  FROM agh.epe_prescricoes_enfermagem pre
                  WHERE pre.atd_seq = atendimento.seq
                    AND pre.dthr_inicio <= now()
                    AND pre.dthr_fim > now())) > 0 THEN (SELECT pre.dthr_fim
                                                         FROM agh.epe_prescricoes_enfermagem pre
                                                         WHERE pre.atd_seq = atendimento.seq
                                                           AND pre.dthr_inicio <= now()
                                                           AND pre.dthr_fim > now()
                                                         LIMIT 1)
           ELSE NULL::timestamp without time zone
           END                                                                                                                        AS dthr_fim_prescricao_vigente,
       CASE
           WHEN ((SELECT count(*) AS count
                  FROM agh.epe_prescricoes_enfermagem pre
                  WHERE pre.atd_seq = atendimento.seq
                    AND pre.dthr_inicio > now())) > 0 THEN 'S'::text
           ELSE 'N'::text
           END                                                                                                                        AS prescricao_futura,
       CASE
           WHEN ((SELECT count(*) AS count
                  FROM agh.agh_caract_unid_funcionais carac
                  WHERE unidade_funcional.seq = carac.unf_seq
                    AND carac.caracteristica::text = 'Anamnese/Evolução Eletrônica'::text)) > 0 THEN 'S'::text
           ELSE 'N'::text
           END                                                                                                                        AS habilita_botao_prescricao,
       CASE
           WHEN ((SELECT count(*) AS count
                  FROM agh.epe_notificacoes hora_contr
                  WHERE hora_contr.atd_seq = atendimento.seq
                    AND hora_contr.tipo::text = 'U'::text)) > 0 THEN 'S'::text
           ELSE 'N'::text
           END                                                                                                                        AS ulcera_pressao,
       (SELECT pac_contro.medicao
        FROM agh.ecp_horario_controles hora_contr
                 JOIN agh.ecp_controle_pacientes pac_contro ON hora_contr.seq = pac_contro.hct_seq
                 JOIN agh.ecp_item_controles item_contro ON pac_contro.ice_seq = item_contro.seq
        WHERE hora_contr.atd_seq = atendimento.seq
          AND item_contro.seq = ((SELECT agh_parametros.vlr_numerico
                                  FROM agh.agh_parametros
                                  WHERE agh_parametros.nome::text = 'P_AGHU_CONTROLES_UP'::text))
          AND hora_contr.data_hora = ((SELECT max(hora_contr_1.data_hora) AS y0_
                                       FROM agh.ecp_horario_controles hora_contr_1
                                                JOIN agh.ecp_controle_pacientes pac_contro_1
                                                     ON hora_contr_1.seq = pac_contro_1.hct_seq
                                                JOIN agh.ecp_item_controles item_contro_1
                                                     ON pac_contro_1.ice_seq = item_contro_1.seq
                                       WHERE hora_contr_1.atd_seq = atendimento.seq
                                         AND item_contro_1.seq = ((SELECT agh_parametros.vlr_numerico
                                                                   FROM agh.agh_parametros
                                                                   WHERE agh_parametros.nome::text = 'P_AGHU_CONTROLES_UP'::text))))) AS ulcera_medicao,
       CASE
           WHEN ((SELECT count(evolucao.seq) AS count
                  FROM agh.mam_tipo_item_evolucoes tipo_evolucao
                           CROSS JOIN agh.mam_item_evolucoes item_evolucao
                           CROSS JOIN agh.mam_evolucoes evolucao
                           CROSS JOIN agh.mam_registros registro
                  WHERE registro.atd_seq = atendimento.seq
                    AND registro.seq = evolucao.rgt_seq
                    AND evolucao.ind_pendente::text = 'V'::text
                    AND evolucao.dthr_valida_mvto IS NULL
                    AND evolucao.dthr_valida = now()
                    AND evolucao.seq = item_evolucao.evo_seq
                    AND item_evolucao.tie_seq = tipo_evolucao.seq
                    AND tipo_evolucao.cag_seq = ((SELECT agh_parametros.vlr_numerico
                                                  FROM agh.agh_parametros
                                                  WHERE agh_parametros.nome::text = 'P_CATEG_PROF_MEDICO'::text))
                    AND NOT (evolucao.seq IN (SELECT mamevoluco4_.evo_seq
                                              FROM agh.mam_evolucoes mamevoluco4_
                                              WHERE mamevoluco4_.evo_seq = evolucao.seq
                                                AND (mamevoluco4_.ind_pendente::text = ANY
                                                     (ARRAY ['P'::character varying::text, 'V'::character varying::text, 'E'::character varying::text, 'A'::character varying::text])))))) >
                0 THEN 'S'::text
           ELSE 'N'::text
           END                                                                                                                        AS evolucao_pelo_medico,
       CASE
           WHEN ((SELECT count(evolucao.seq) AS count
                  FROM agh.mam_tipo_item_evolucoes tipo_evolucao
                           CROSS JOIN agh.mam_item_evolucoes item_evolucao
                           CROSS JOIN agh.mam_evolucoes evolucao
                           CROSS JOIN agh.mam_registros registro
                  WHERE registro.atd_seq = atendimento.seq
                    AND registro.seq = evolucao.rgt_seq
                    AND evolucao.ind_pendente::text = 'V'::text
                    AND evolucao.dthr_valida_mvto IS NULL
                    AND evolucao.dthr_valida = now()
                    AND evolucao.seq = item_evolucao.evo_seq
                    AND item_evolucao.tie_seq = tipo_evolucao.seq
                    AND tipo_evolucao.cag_seq = ((SELECT agh_parametros.vlr_numerico
                                                  FROM agh.agh_parametros
                                                  WHERE agh_parametros.nome::text = 'P_CATEG_PROF_OUTROS'::text))
                    AND NOT (evolucao.seq IN (SELECT mamevoluco4_.evo_seq
                                              FROM agh.mam_evolucoes mamevoluco4_
                                              WHERE mamevoluco4_.evo_seq = evolucao.seq
                                                AND (mamevoluco4_.ind_pendente::text = ANY
                                                     (ARRAY ['P'::character varying::text, 'V'::character varying::text, 'E'::character varying::text, 'A'::character varying::text])))))) >
                0 THEN 'S'::text
           ELSE 'N'::text
           END                                                                                                                        AS evolucao_pelo_outros,
       CASE
           WHEN ((SELECT count(evolucao.seq) AS count
                  FROM agh.mam_tipo_item_evolucoes tipo_evolucao
                           CROSS JOIN agh.mam_item_evolucoes item_evolucao
                           CROSS JOIN agh.mam_evolucoes evolucao
                           CROSS JOIN agh.mam_registros registro
                  WHERE registro.atd_seq = atendimento.seq
                    AND registro.seq = evolucao.rgt_seq
                    AND evolucao.ind_pendente::text = 'V'::text
                    AND evolucao.dthr_valida_mvto IS NULL
                    AND evolucao.dthr_valida = now()
                    AND evolucao.seq = item_evolucao.evo_seq
                    AND item_evolucao.tie_seq = tipo_evolucao.seq
                    AND tipo_evolucao.cag_seq = ((SELECT agh_parametros.vlr_numerico
                                                  FROM agh.agh_parametros
                                                  WHERE agh_parametros.nome::text = 'P_CATEG_PROF_ENF'::text))
                    AND tipo_evolucao.seq <> ((SELECT agh_parametros.vlr_numerico
                                               FROM agh.agh_parametros
                                               WHERE agh_parametros.nome::text = 'P_TIPO_ITEM_EVOLUCAO'::text))
                    AND NOT (evolucao.seq IN (SELECT mamevoluco4_.evo_seq
                                              FROM agh.mam_evolucoes mamevoluco4_
                                              WHERE mamevoluco4_.evo_seq = evolucao.seq
                                                AND (mamevoluco4_.ind_pendente::text = ANY
                                                     (ARRAY ['P'::character varying::text, 'V'::character varying::text, 'E'::character varying::text, 'A'::character varying::text])))))) >
                0 THEN 'S'::text
           ELSE 'N'::text
           END                                                                                                                        AS evolucao_pelo_enfermeiro,
       (SELECT max(crt.criado_em) AS max
        FROM agh.mpm_control_prev_altas crt
        WHERE atendimento.origem::text = 'I'::text
          AND atendimento.seq = crt.atd_seq)                                                                                          AS dt_prev_alta,
       (SELECT crt.resposta
        FROM agh.mpm_control_prev_altas crt
        WHERE atendimento.origem::text = 'I'::text
          AND atendimento.seq = crt.atd_seq
          AND crt.criado_em = ((SELECT max(crt_1.criado_em) AS max
                                FROM agh.mpm_control_prev_altas crt_1
                                WHERE atendimento.origem::text = 'I'::text
                                  AND atendimento.seq = crt_1.atd_seq)))                                                              AS resp_prev_alta,
       CASE
           WHEN atendimento.atd_seq_mae IS NOT NULL THEN (SELECT max(crt.criado_em) AS max
                                                          FROM agh.mpm_control_prev_altas crt
                                                          WHERE atendimento.origem::text = 'I'::text
                                                            AND atendimento.atd_seq_mae = crt.atd_seq)
           ELSE NULL::timestamp without time zone
           END                                                                                                                        AS dt_prev_alta_atd_mae,
       CASE
           WHEN atendimento.atd_seq_mae IS NOT NULL THEN (SELECT crt.resposta
                                                          FROM agh.mpm_control_prev_altas crt
                                                          WHERE atendimento.origem::text = 'I'::text
                                                            AND atendimento.atd_seq_mae = crt.atd_seq
                                                            AND crt.criado_em = ((SELECT max(crt_1.criado_em) AS max
                                                                                  FROM agh.mpm_control_prev_altas crt_1
                                                                                  WHERE atendimento.origem::text = 'I'::text
                                                                                    AND atendimento.atd_seq_mae = crt_1.atd_seq)))
           ELSE NULL::character varying
           END                                                                                                                        AS resp_prev_alta_atd_mae,
       CASE
           WHEN atendimento.atd_seq_mae IS NOT NULL THEN (SELECT mae.origem
                                                          FROM agh.agh_atendimentos mae
                                                          WHERE atendimento.atd_seq_mae = mae.seq)
           ELSE NULL::character varying
           END                                                                                                                        AS origem_atd_mae,
       CASE
           WHEN ((SELECT count(docs.pac_codigo) AS count
                  FROM agh.v_agh_versoes_documentos docs
                  WHERE docs.dov_situacao::text = 'P'::text
                    AND docs.pac_codigo = atendimento.pac_codigo)) > 0 THEN 'PENDENTE'::text
           ELSE ''::text
           END                                                                                                                        AS status_certificacao_digital,
       CASE
           WHEN ((SELECT count(docs.pac_codigo) AS count
                  FROM agh.v_agh_versoes_documentos docs
                  WHERE docs.dov_situacao::text = 'A'::text
                    AND docs.pac_codigo = atendimento.pac_codigo)) > 0 THEN 'ASSINADO'::text
           ELSE ''::text
           END                                                                                                                        AS status_certificacao_digital_assinado
FROM agh.agh_atendimentos atendimento
         JOIN agh.aip_pacientes paciente ON atendimento.pac_codigo = paciente.codigo
         JOIN agh.agh_unidades_funcionais unidade_funcional ON atendimento.unf_seq = unidade_funcional.seq
WHERE atendimento.ind_pac_atendimento::text = 'S'::text
  AND (atendimento.origem::text = ANY
       (ARRAY ['I'::character varying::text, 'H'::character varying::text, 'U'::character varying::text, 'N'::character varying::text]))
ORDER BY CASE
             WHEN atendimento.lto_lto_id IS NOT NULL THEN concat('L:', atendimento.lto_lto_id)
             WHEN atendimento.qrt_numero IS NOT NULL THEN concat('Q:', atendimento.qrt_numero)
             ELSE (SELECT (((('U:'::text || unf.andar::text) || ' '::text) || unf.ind_ala::text) || ' - '::text) ||
                          unf.descricao::text
                   FROM agh.agh_unidades_funcionais unf
                   WHERE unf.seq = atendimento.unf_seq)
             END;

alter table agh.v_lista_prescricao_enfermagem owner to postgres;

grant insert, select, update, delete, truncate, references, trigger on agh.v_lista_prescricao_enfermagem to acesso_completo;

grant insert, select, update, delete, truncate, references, trigger on agh.v_lista_prescricao_enfermagem to acesso_leitura;

grant insert, select, update, delete, truncate, references, trigger on agh.v_lista_prescricao_enfermagem to escrita_integra;