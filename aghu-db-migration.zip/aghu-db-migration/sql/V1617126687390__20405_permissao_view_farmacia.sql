ALTER TABLE agh.v_afa_prcr_disp_mdtos_painel OWNER TO postgres;
GRANT ALL ON TABLE agh.v_afa_prcr_disp_mdtos_painel TO postgres;
GRANT ALL ON TABLE agh.v_afa_prcr_disp_mdtos_painel TO acesso_completo;
GRANT SELECT ON TABLE agh.v_afa_prcr_disp_mdtos_painel TO acesso_leitura;