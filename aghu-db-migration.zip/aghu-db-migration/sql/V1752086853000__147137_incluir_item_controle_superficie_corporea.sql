DO $$
DECLARE
v_descricao_grupo TEXT := 'Monitorização Metabólica';
  v_seq_grupo INT;
  v_ordem_grupo INT2 := 5;
  v_tipo_monitorizacao TEXT = 'MN';
  v_descricao_m2 TEXT := 'm2';
  v_descricao_m_quadrado TEXT := 'm²';
  v_descricao_superficie_corporea TEXT := 'Superfície Corpórea';
  v_regex_superficie_corporea TEXT := 'superf(i|í)cie corp(o|ó)rea';
  v_sigla_superficie_corporea TEXT := 'SC';
  v_ordem_superficie_corporea INT2 := 4;
  v_tipo_medicao_numerica TEXT := 'NU';
  v_sequence_superficie_corporea INT;
  v_matricula_aghu INT;
  v_vinculo_aghu SMALLINT;
BEGIN

  RAISE INFO 'Iniciando processo de inclusão de itens de controle: Altura e Peso';

SELECT matricula, vin_codigo
INTO v_matricula_aghu, v_vinculo_aghu
FROM agh.rap_servidores ser
         JOIN agh.rap_pessoas_fisicas pes
              ON ser.pes_codigo = pes.codigo
WHERE lower(pes.nome) like '%aghu%';

RAISE INFO 'Identificada matrícula (%) e vínculo (%) do AGHU'
    , v_matricula_aghu, v_vinculo_aghu;

SELECT gco.seq
INTO v_seq_grupo
FROM agh.ecp_grupo_controles gco
         JOIN agh.ecp_item_controles ice
              ON ice.gco_seq = gco.seq
WHERE ice.sigla = 'Peso';

RAISE INFO 'Identificado Grupo de Controle %', v_seq_grupo;

  IF NOT EXISTS (
    SELECT 1
    FROM agh.ecp_grupo_controles
    WHERE lower(descricao) = lower(v_descricao_grupo)
  ) AND (v_seq_grupo IS NULL) THEN
    INSERT INTO agh.ecp_grupo_controles (
      seq, descricao, ordem, situacao
    , criado_em, ser_matricula, ser_vin_codigo
    , "version", tipo
    )
    VALUES (
      NEXTVAL('agh.ecp_gco_sq1')
    , v_descricao_grupo
    , v_ordem_grupo
    , 'A'
    , NOW()
    , v_matricula_aghu
    , v_vinculo_aghu
    , 0
    , v_tipo_monitorizacao
    );

    RAISE INFO 'Inserido grupo de controle: %', v_descricao_grupo;
END IF;

  IF EXISTS (
    SELECT 1
    FROM agh.mpm_unidade_medida_medicas
    WHERE lower(descricao) = lower(v_descricao_m2)
  ) THEN
UPDATE agh.mpm_unidade_medida_medicas
SET descricao = lower(v_descricao_m_quadrado)
WHERE lower(descricao) = lower(v_descricao_m2);

RAISE INFO 'Alterada descrição da unidade de medida médica de % para %', v_descricao_m2, v_descricao_m_quadrado;
END IF;

  IF NOT EXISTS (
    SELECT 1
    FROM agh.mpm_unidade_medida_medicas
    WHERE lower(descricao) = lower(v_descricao_m_quadrado)
  ) THEN
    INSERT INTO agh.mpm_unidade_medida_medicas (
      seq, ser_matricula, ser_vin_codigo
    , descricao, criado_em
    )
    VALUES (
      NEXTVAL('agh.mpm_umm_sq1')
    , v_matricula_aghu
    , v_vinculo_aghu
    , v_descricao_m_quadrado
    , NOW()
    );

    RAISE INFO 'Inserida unidade de medida médica: %', v_descricao_m_quadrado;
END IF;

  IF EXISTS (
    SELECT 1
    FROM agh.ecp_item_controles
    WHERE lower(descricao) != lower(v_descricao_superficie_corporea)
    AND lower(sigla) = lower(v_sigla_superficie_corporea)
  ) THEN
    UPDATE agh.ecp_item_controles
    SET sigla = LEFT(v_sigla_superficie_corporea, LENGTH(v_sigla_superficie_corporea) - 1)
    WHERE lower(sigla) = lower(v_sigla_superficie_corporea);

    RAISE INFO 'Encontrado item de controle com a sigla %, mas com outra descrição.', v_sigla_superficie_corporea;
    RAISE INFO 'Alterada a sigla para %.', LEFT(v_sigla_superficie_corporea, LENGTH(v_sigla_superficie_corporea) - 1);
  END IF;

SELECT seq INTO v_sequence_superficie_corporea
FROM agh.ecp_item_controles
WHERE descricao ~* v_regex_superficie_corporea;

IF (v_sequence_superficie_corporea IS NULL) THEN
    INSERT INTO agh.ecp_item_controles (
      seq, descricao, sigla, ordem, tipo_medicao
    , criado_em, situacao, gco_seq, umm_seq
    , ser_matricula, ser_vin_codigo, "version"
    )
    VALUES (
      NEXTVAL('agh.ecp_ice_sq1')
    , v_descricao_superficie_corporea
    , v_sigla_superficie_corporea
    , v_ordem_superficie_corporea
    , v_tipo_medicao_numerica
    , NOW()
    , 'A'
    , COALESCE(v_seq_grupo, (SELECT seq FROM agh.ecp_grupo_controles WHERE lower(descricao) = lower(v_descricao_grupo)))
    , (SELECT seq FROM agh.mpm_unidade_medida_medicas WHERE lower(descricao) = lower(v_descricao_m_quadrado))
    , v_matricula_aghu
    , v_vinculo_aghu
    , 0
    );

    RAISE INFO 'Inserido item de controle: %', v_descricao_superficie_corporea;
ELSE
UPDATE agh.ecp_item_controles
SET
    sigla = v_sigla_superficie_corporea
  , umm_seq = (SELECT seq FROM agh.mpm_unidade_medida_medicas WHERE lower(descricao) = lower(v_descricao_m_quadrado))
WHERE seq = v_sequence_superficie_corporea;

RAISE INFO 'Atualizado item de controle: %', v_descricao_superficie_corporea;
END IF;

  RAISE INFO 'Finalizado processo de inclusão de item de controle: Superfície Corpórea.';
END;
$$;
