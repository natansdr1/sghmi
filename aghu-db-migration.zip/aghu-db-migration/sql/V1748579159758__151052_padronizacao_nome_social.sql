DO $$
BEGIN

CREATE OR REPLACE VIEW agh.v_ael_exames_solicitacao_atd_aghu
AS SELECT soe.seq AS soe_seq,
          soe.atd_seq,
          soe.criado_em,
          man.descricao AS descricao_material,
          eis.dthr_evento,
          (exa.descricao_usual::text || ' /  '::text) || man.descricao::text AS nome_exame_material,
                  pes.nome AS soe_servidor_nome,
          cnv.descricao AS cnv_descricao,
          atd.lto_lto_id,
          atd.qrt_numero,
          qrt.descricao AS qrt_descricao,
          atd.unf_seq,
          ise.dthr_programada,
          cnv.grupo_convenio,
          aie.origem_mapa,
          ise.ufe_ema_exa_sigla,
          ise.sit_codigo,
          ise.ufe_unf_seq,
          ( SELECT
                CASE
                    WHEN soetemp.atd_seq > 0 THEN (case when coalesce(pac_atd.nome_social, '') = '' then pac_atd.nome else pac_atd.nome_social end)
                    WHEN pac_atv.nome IS NOT NULL THEN
                        CASE
                            WHEN pjq.numero IS NOT NULL THEN ((('GPP-'::text || pjq.numero::text) || ' - '::text) || (case when coalesce(pac_atv.nome_social, '') = '' then pac_atv.nome else pac_atv.nome_social end)::text)::character varying
                        ELSE (case when coalesce(pac_atv.nome_social, '') = '' then pac_atv.nome else pac_atv.nome_social end)
END
WHEN atv.nome_paciente IS NOT NULL THEN
                    CASE
                        WHEN pjq.numero IS NOT NULL THEN ((('GPP-'::text || pjq.numero::text) || ' - '::text) || atv.nome_paciente::text)::character varying
                        ELSE atv.nome_paciente
END
WHEN pjq.numero IS NOT NULL THEN ((('GPP-'::text || pjq.numero::text) || ' - '::text) || pjq.nome::text)::character varying
                    WHEN ccq.seq IS NOT NULL THEN ccq.material
                    WHEN lae.seq IS NOT NULL THEN lae.nome
                    WHEN ddv.seq IS NOT NULL THEN ddv.nome
                    WHEN cad.seq IS NOT NULL THEN cad.nome
                    ELSE NULL::character varying
END AS "case"
           FROM agh.ael_solicitacao_exames soetemp
             LEFT JOIN agh.agh_atendimentos atd_1 ON atd_1.seq = soetemp.atd_seq
             LEFT JOIN agh.aip_pacientes pac_atd ON pac_atd.codigo = atd_1.pac_codigo
             LEFT JOIN agh.ael_atendimento_diversos atv ON atv.seq = soetemp.atv_seq
             LEFT JOIN agh.aip_pacientes pac_atv ON pac_atv.codigo = atv.pac_codigo
             LEFT JOIN agh.ael_projeto_pesquisas pjq ON pjq.seq = atv.pjq_seq
             LEFT JOIN agh.ael_cad_ctrl_qualidades ccq ON ccq.seq = atv.ccq_seq
             LEFT JOIN agh.ael_laboratorio_externos lae ON lae.seq = atv.lae_seq
             LEFT JOIN agh.ael_dados_cadaveres ddv ON ddv.seq = atv.ddv_seq
             LEFT JOIN agh.abs_candidatos_doadores cad ON cad.seq = atv.cad_seq
          WHERE soetemp.seq = soe.seq) AS nome_paciente,
    ( SELECT COALESCE(pac.prontuario, atv.prontuario) AS "coalesce"
           FROM agh.ael_solicitacao_exames soetemp
             LEFT JOIN agh.agh_atendimentos atd_1 ON atd_1.seq = soetemp.atd_seq
             LEFT JOIN agh.ael_atendimento_diversos atv ON atv.seq = soetemp.atv_seq
             LEFT JOIN agh.aip_pacientes pac ON pac.codigo = COALESCE(atd_1.pac_codigo, atv.pac_codigo)
          WHERE soetemp.seq = soe.seq) AS prontuario,
    ( SELECT
                CASE
                    WHEN atd_1.origem::text = 'N'::text THEN 'I'::character varying
                    WHEN atd_1.origem IS NULL THEN 'D'::character varying
                    ELSE atd_1.origem
                END AS origem
           FROM agh.ael_solicitacao_exames soetemp
             LEFT JOIN agh.agh_atendimentos atd_1 ON atd_1.seq = soetemp.atd_seq
             LEFT JOIN agh.ael_atendimento_diversos atv ON atv.seq = soetemp.atv_seq
          WHERE soetemp.seq = soe.seq) AS origem,
    ( SELECT
                CASE
                    WHEN atd_1.lto_lto_id IS NOT NULL THEN 'L:'::text || atd_1.lto_lto_id::text
                    WHEN qrt_1.descricao IS NOT NULL THEN 'Q:'::text || qrt_1.descricao::text
                    WHEN atd_1.unf_seq IS NOT NULL THEN (((('U:'::text || auf.andar::text) || ' '::text) || auf.ind_ala::text) || ' - '::text) || auf.descricao::text
                    ELSE NULL::text
                END AS "case"
           FROM agh.ael_solicitacao_exames soetemp
             LEFT JOIN agh.agh_atendimentos atd_1 ON atd_1.seq = soetemp.atd_seq
             LEFT JOIN agh.ain_quartos qrt_1 ON atd_1.qrt_numero = qrt_1.numero
             LEFT JOIN agh.agh_unidades_funcionais auf ON auf.seq = atd_1.unf_seq
          WHERE soetemp.seq = soe.seq) AS localizacao
   FROM agh.ael_item_solicitacao_exames ise
     JOIN agh.ael_exames exa ON exa.sigla::text = ise.ufe_ema_exa_sigla::text
     JOIN agh.ael_materiais_analises man ON man.seq = ise.ufe_ema_man_seq
     JOIN agh.ael_extrato_item_solics eis ON eis.ise_soe_seq = ise.soe_seq AND eis.ise_seqp = ise.seqp AND eis.sit_codigo::text = ise.sit_codigo::text
     JOIN agh.ael_solicitacao_exames soe ON soe.seq = ise.soe_seq
     JOIN agh.fat_convenios_saude cnv ON cnv.codigo = soe.csp_cnv_codigo
     JOIN agh.rap_servidores ser ON ser.matricula = soe.ser_matricula_eh_responsabilid AND ser.vin_codigo = soe.ser_vin_codigo_eh_responsabili
     JOIN agh.rap_pessoas_fisicas pes ON pes.codigo = ser.pes_codigo
     LEFT JOIN agh.agh_atendimentos atd ON atd.seq = soe.atd_seq
     LEFT JOIN agh.ain_quartos qrt ON atd.qrt_numero = qrt.numero
     LEFT JOIN agh.ael_amostra_item_exames aie ON aie.ise_soe_seq = ise.soe_seq AND aie.ise_seqp = ise.seqp
  WHERE (eis.criado_em IN ( SELECT max(eis1.criado_em) AS max
           FROM agh.ael_extrato_item_solics eis1
          WHERE eis1.ise_soe_seq = eis.ise_soe_seq AND eis1.ise_seqp = eis.ise_seqp))
  GROUP BY soe.seq, soe.atd_seq, soe.criado_em, man.descricao, eis.dthr_evento, (exa.descricao_usual::text || ' /  '::text) || man.descricao::text, pes.nome, cnv.descricao, atd.lto_lto_id, atd.qrt_numero, qrt.descricao, atd.unf_seq, ise.dthr_programada, cnv.grupo_convenio, aie.origem_mapa, ise.ufe_ema_exa_sigla, ise.sit_codigo, ise.ufe_unf_seq, ( SELECT
                CASE
                    WHEN soetemp.atd_seq > 0 THEN pac_atd.nome
                    WHEN pac_atv.nome IS NOT NULL THEN
                    CASE
                        WHEN pjq.numero IS NOT NULL THEN ((('GPP-'::text || pjq.numero::text) || ' - '::text) || pac_atv.nome::text)::character varying
                        ELSE pac_atv.nome
                    END
                    WHEN atv.nome_paciente IS NOT NULL THEN
                    CASE
                        WHEN pjq.numero IS NOT NULL THEN ((('GPP-'::text || pjq.numero::text) || ' - '::text) || atv.nome_paciente::text)::character varying
                        ELSE atv.nome_paciente
                    END
                    WHEN pjq.numero IS NOT NULL THEN ((('GPP-'::text || pjq.numero::text) || ' - '::text) || pjq.nome::text)::character varying
                    WHEN ccq.seq IS NOT NULL THEN ccq.material
                    WHEN lae.seq IS NOT NULL THEN lae.nome
                    WHEN ddv.seq IS NOT NULL THEN ddv.nome
                    WHEN cad.seq IS NOT NULL THEN cad.nome
                    ELSE NULL::character varying
                END AS "case"
           FROM agh.ael_solicitacao_exames soetemp
             LEFT JOIN agh.agh_atendimentos atd_1 ON atd_1.seq = soetemp.atd_seq
             LEFT JOIN agh.aip_pacientes pac_atd ON pac_atd.codigo = atd_1.pac_codigo
             LEFT JOIN agh.ael_atendimento_diversos atv ON atv.seq = soetemp.atv_seq
             LEFT JOIN agh.aip_pacientes pac_atv ON pac_atv.codigo = atv.pac_codigo
             LEFT JOIN agh.ael_projeto_pesquisas pjq ON pjq.seq = atv.pjq_seq
             LEFT JOIN agh.ael_cad_ctrl_qualidades ccq ON ccq.seq = atv.ccq_seq
             LEFT JOIN agh.ael_laboratorio_externos lae ON lae.seq = atv.lae_seq
             LEFT JOIN agh.ael_dados_cadaveres ddv ON ddv.seq = atv.ddv_seq
             LEFT JOIN agh.abs_candidatos_doadores cad ON cad.seq = atv.cad_seq
          WHERE soetemp.seq = soe.seq), ( SELECT COALESCE(pac.prontuario, atv.prontuario) AS "coalesce"
           FROM agh.ael_solicitacao_exames soetemp
             LEFT JOIN agh.agh_atendimentos atd_1 ON atd_1.seq = soetemp.atd_seq
             LEFT JOIN agh.ael_atendimento_diversos atv ON atv.seq = soetemp.atv_seq
             LEFT JOIN agh.aip_pacientes pac ON pac.codigo = COALESCE(atd_1.pac_codigo, atv.pac_codigo)
          WHERE soetemp.seq = soe.seq), ( SELECT
                CASE
                    WHEN atd_1.origem::text = 'N'::text THEN 'I'::character varying
                    WHEN atd_1.origem IS NULL THEN 'D'::character varying
                    ELSE atd_1.origem
                END AS origem
           FROM agh.ael_solicitacao_exames soetemp
             LEFT JOIN agh.agh_atendimentos atd_1 ON atd_1.seq = soetemp.atd_seq
             LEFT JOIN agh.ael_atendimento_diversos atv ON atv.seq = soetemp.atv_seq
          WHERE soetemp.seq = soe.seq), ( SELECT
                CASE
                    WHEN atd_1.lto_lto_id IS NOT NULL THEN 'L:'::text || atd_1.lto_lto_id::text
                    WHEN qrt_1.descricao IS NOT NULL THEN 'Q:'::text || qrt_1.descricao::text
                    WHEN atd_1.unf_seq IS NOT NULL THEN (((('U:'::text || auf.andar::text) || ' '::text) || auf.ind_ala::text) || ' - '::text) || auf.descricao::text
                    ELSE NULL::text
                END AS "case"
           FROM agh.ael_solicitacao_exames soetemp
             LEFT JOIN agh.agh_atendimentos atd_1 ON atd_1.seq = soetemp.atd_seq
             LEFT JOIN agh.ain_quartos qrt_1 ON atd_1.qrt_numero = qrt_1.numero
             LEFT JOIN agh.agh_unidades_funcionais auf ON auf.seq = atd_1.unf_seq
          WHERE soetemp.seq = soe.seq);

ALTER TABLE agh.v_ael_exames_solicitacao_atd_aghu
    OWNER TO postgres;

GRANT ALL ON TABLE agh.v_ael_exames_solicitacao_atd_aghu TO acesso_completo;
GRANT ALL ON TABLE agh.v_ael_exames_solicitacao_atd_aghu TO postgres;
GRANT SELECT ON TABLE agh.v_ael_exames_solicitacao_atd_aghu TO acesso_leitura;

CREATE OR REPLACE VIEW agh.v_ael_exame_solic_atd_aghu
 AS
SELECT soe.seq AS soe_seq,
       soe.atd_seq,
       soe.criado_em,
       man.descricao AS descricao_material,
       eis.dthr_evento,
       (exa.descricao_usual::text || ' /  '::text) || man.descricao::text AS nome_exame_material,
        pes.nome AS soe_servidor_nome,
       cnv.descricao AS cnv_descricao,
       atd.lto_lto_id,
       atd.qrt_numero,
       qrt.descricao AS qrt_descricao,
       atd.unf_seq,
       ise.dthr_programada,
       cnv.grupo_convenio,
       aie.origem_mapa,
       ise.ufe_ema_exa_sigla,
       ise.sit_codigo,
       ise.ufe_unf_seq,
       ( SELECT
             CASE
                 WHEN soetemp.atd_seq > 0 THEN (case when coalesce(pac_atd.nome_social, '') = '' then pac_atd.nome else pac_atd.nome_social end)
                 WHEN pac_atv.nome IS NOT NULL THEN
                     CASE
                         WHEN pjq.numero IS NOT NULL THEN ((('GPP-'::text || pjq.numero::text) || ' - '::text) || (case when coalesce(pac_atv.nome_social, '') = '' then pac_atv.nome else pac_atv.nome_social end)::text)::character varying
                        ELSE (case when coalesce(pac_atv.nome_social, '') = '' then pac_atv.nome else pac_atv.nome_social end)
END
WHEN atv.nome_paciente IS NOT NULL THEN
                    CASE
                        WHEN pjq.numero IS NOT NULL THEN ((('GPP-'::text || pjq.numero::text) || ' - '::text) || atv.nome_paciente::text)::character varying
                        ELSE atv.nome_paciente
END
WHEN pjq.numero IS NOT NULL THEN ((('GPP-'::text || pjq.numero::text) || ' - '::text) || pjq.nome::text)::character varying
                    WHEN ccq.seq IS NOT NULL THEN ccq.material
                    WHEN lae.seq IS NOT NULL THEN lae.nome
                    WHEN ddv.seq IS NOT NULL THEN ddv.nome
                    WHEN cad.seq IS NOT NULL THEN cad.nome
                    ELSE NULL::character varying
END AS "case"
           FROM agh.ael_solicitacao_exames soetemp
             LEFT JOIN agh.agh_atendimentos atd_1 ON atd_1.seq = soetemp.atd_seq
             LEFT JOIN agh.aip_pacientes pac_atd ON pac_atd.codigo = atd_1.pac_codigo
             LEFT JOIN agh.ael_atendimento_diversos atv ON atv.seq = soetemp.atv_seq
             LEFT JOIN agh.aip_pacientes pac_atv ON pac_atv.codigo = atv.pac_codigo
             LEFT JOIN agh.ael_projeto_pesquisas pjq ON pjq.seq = atv.pjq_seq
             LEFT JOIN agh.ael_cad_ctrl_qualidades ccq ON ccq.seq = atv.ccq_seq
             LEFT JOIN agh.ael_laboratorio_externos lae ON lae.seq = atv.lae_seq
             LEFT JOIN agh.ael_dados_cadaveres ddv ON ddv.seq = atv.ddv_seq
             LEFT JOIN agh.abs_candidatos_doadores cad ON cad.seq = atv.cad_seq
          WHERE soetemp.seq = soe.seq) AS nome_paciente,
    ( SELECT COALESCE(pac.prontuario, atv.prontuario) AS "coalesce"
           FROM agh.ael_solicitacao_exames soetemp
             LEFT JOIN agh.agh_atendimentos atd_1 ON atd_1.seq = soetemp.atd_seq
             LEFT JOIN agh.ael_atendimento_diversos atv ON atv.seq = soetemp.atv_seq
             LEFT JOIN agh.aip_pacientes pac ON pac.codigo = COALESCE(atd_1.pac_codigo, atv.pac_codigo)
          WHERE soetemp.seq = soe.seq) AS prontuario,
    ( SELECT
                CASE
                    WHEN atd_1.origem::text = 'N'::text THEN 'I'::character varying
                    WHEN atd_1.origem IS NULL THEN 'D'::character varying
                    ELSE atd_1.origem
                END AS origem
           FROM agh.ael_solicitacao_exames soetemp
             LEFT JOIN agh.agh_atendimentos atd_1 ON atd_1.seq = soetemp.atd_seq
             LEFT JOIN agh.ael_atendimento_diversos atv ON atv.seq = soetemp.atv_seq
          WHERE soetemp.seq = soe.seq) AS origem,
    ( SELECT
                CASE
                    WHEN atd_1.lto_lto_id IS NOT NULL THEN 'L:'::text || atd_1.lto_lto_id::text
                    WHEN qrt_1.descricao IS NOT NULL THEN 'Q:'::text || qrt_1.descricao::text
                    WHEN atd_1.unf_seq IS NOT NULL THEN (((('U:'::text || auf.andar::text) || ' '::text) || auf.ind_ala::text) || ' - '::text) || auf.descricao::text
                    ELSE NULL::text
                END AS "case"
           FROM agh.ael_solicitacao_exames soetemp
             LEFT JOIN agh.agh_atendimentos atd_1 ON atd_1.seq = soetemp.atd_seq
             LEFT JOIN agh.ain_quartos qrt_1 ON atd_1.qrt_numero = qrt_1.numero
             LEFT JOIN agh.agh_unidades_funcionais auf ON auf.seq = atd_1.unf_seq
          WHERE soetemp.seq = soe.seq) AS localizacao
   FROM agh.ael_item_solicitacao_exames ise
     JOIN agh.ael_exames exa ON exa.sigla::text = ise.ufe_ema_exa_sigla::text
     JOIN agh.ael_materiais_analises man ON man.seq = ise.ufe_ema_man_seq
     JOIN agh.ael_extrato_item_solics eis ON eis.ise_soe_seq = ise.soe_seq AND eis.ise_seqp = ise.seqp AND eis.sit_codigo::text = ise.sit_codigo::text
     JOIN agh.ael_solicitacao_exames soe ON soe.seq = ise.soe_seq
     JOIN agh.fat_convenios_saude cnv ON cnv.codigo = soe.csp_cnv_codigo
     LEFT JOIN agh.rap_servidores ser ON ser.matricula = soe.ser_matricula_eh_responsabilid AND ser.vin_codigo = soe.ser_vin_codigo_eh_responsabili
     LEFT JOIN agh.rap_pessoas_fisicas pes ON pes.codigo = ser.pes_codigo
     LEFT JOIN agh.agh_atendimentos atd ON atd.seq = soe.atd_seq
     LEFT JOIN agh.ain_quartos qrt ON atd.qrt_numero = qrt.numero
     LEFT JOIN agh.ael_amostra_item_exames aie ON aie.ise_soe_seq = ise.soe_seq AND aie.ise_seqp = ise.seqp
  WHERE (eis.criado_em IN ( SELECT max(eis1.criado_em) AS max
           FROM agh.ael_extrato_item_solics eis1
          WHERE eis1.ise_soe_seq = eis.ise_soe_seq AND eis1.ise_seqp = eis.ise_seqp))
  GROUP BY soe.seq, soe.atd_seq, soe.criado_em, man.descricao, eis.dthr_evento, (exa.descricao_usual::text || ' /  '::text) || man.descricao::text, pes.nome, cnv.descricao, atd.lto_lto_id, atd.qrt_numero, qrt.descricao, atd.unf_seq, ise.dthr_programada, cnv.grupo_convenio, aie.origem_mapa, ise.ufe_ema_exa_sigla, ise.sit_codigo, ise.ufe_unf_seq, ( SELECT
                CASE
                    WHEN soetemp.atd_seq > 0 THEN pac_atd.nome
                    WHEN pac_atv.nome IS NOT NULL THEN
                    CASE
                        WHEN pjq.numero IS NOT NULL THEN ((('GPP-'::text || pjq.numero::text) || ' - '::text) || pac_atv.nome::text)::character varying
                        ELSE pac_atv.nome
                    END
                    WHEN atv.nome_paciente IS NOT NULL THEN
                    CASE
                        WHEN pjq.numero IS NOT NULL THEN ((('GPP-'::text || pjq.numero::text) || ' - '::text) || atv.nome_paciente::text)::character varying
                        ELSE atv.nome_paciente
                    END
                    WHEN pjq.numero IS NOT NULL THEN ((('GPP-'::text || pjq.numero::text) || ' - '::text) || pjq.nome::text)::character varying
                    WHEN ccq.seq IS NOT NULL THEN ccq.material
                    WHEN lae.seq IS NOT NULL THEN lae.nome
                    WHEN ddv.seq IS NOT NULL THEN ddv.nome
                    WHEN cad.seq IS NOT NULL THEN cad.nome
                    ELSE NULL::character varying
                END AS "case"
           FROM agh.ael_solicitacao_exames soetemp
             LEFT JOIN agh.agh_atendimentos atd_1 ON atd_1.seq = soetemp.atd_seq
             LEFT JOIN agh.aip_pacientes pac_atd ON pac_atd.codigo = atd_1.pac_codigo
             LEFT JOIN agh.ael_atendimento_diversos atv ON atv.seq = soetemp.atv_seq
             LEFT JOIN agh.aip_pacientes pac_atv ON pac_atv.codigo = atv.pac_codigo
             LEFT JOIN agh.ael_projeto_pesquisas pjq ON pjq.seq = atv.pjq_seq
             LEFT JOIN agh.ael_cad_ctrl_qualidades ccq ON ccq.seq = atv.ccq_seq
             LEFT JOIN agh.ael_laboratorio_externos lae ON lae.seq = atv.lae_seq
             LEFT JOIN agh.ael_dados_cadaveres ddv ON ddv.seq = atv.ddv_seq
             LEFT JOIN agh.abs_candidatos_doadores cad ON cad.seq = atv.cad_seq
          WHERE soetemp.seq = soe.seq), ( SELECT COALESCE(pac.prontuario, atv.prontuario) AS "coalesce"
           FROM agh.ael_solicitacao_exames soetemp
             LEFT JOIN agh.agh_atendimentos atd_1 ON atd_1.seq = soetemp.atd_seq
             LEFT JOIN agh.ael_atendimento_diversos atv ON atv.seq = soetemp.atv_seq
             LEFT JOIN agh.aip_pacientes pac ON pac.codigo = COALESCE(atd_1.pac_codigo, atv.pac_codigo)
          WHERE soetemp.seq = soe.seq), ( SELECT
                CASE
                    WHEN atd_1.origem::text = 'N'::text THEN 'I'::character varying
                    WHEN atd_1.origem IS NULL THEN 'D'::character varying
                    ELSE atd_1.origem
                END AS origem
           FROM agh.ael_solicitacao_exames soetemp
             LEFT JOIN agh.agh_atendimentos atd_1 ON atd_1.seq = soetemp.atd_seq
             LEFT JOIN agh.ael_atendimento_diversos atv ON atv.seq = soetemp.atv_seq
          WHERE soetemp.seq = soe.seq), ( SELECT
                CASE
                    WHEN atd_1.lto_lto_id IS NOT NULL THEN 'L:'::text || atd_1.lto_lto_id::text
                    WHEN qrt_1.descricao IS NOT NULL THEN 'Q:'::text || qrt_1.descricao::text
                    WHEN atd_1.unf_seq IS NOT NULL THEN (((('U:'::text || auf.andar::text) || ' '::text) || auf.ind_ala::text) || ' - '::text) || auf.descricao::text
                    ELSE NULL::text
                END AS "case"
           FROM agh.ael_solicitacao_exames soetemp
             LEFT JOIN agh.agh_atendimentos atd_1 ON atd_1.seq = soetemp.atd_seq
             LEFT JOIN agh.ain_quartos qrt_1 ON atd_1.qrt_numero = qrt_1.numero
             LEFT JOIN agh.agh_unidades_funcionais auf ON auf.seq = atd_1.unf_seq
          WHERE soetemp.seq = soe.seq);

ALTER TABLE agh.v_ael_exame_solic_atd_aghu
    OWNER TO postgres;

GRANT ALL ON TABLE agh.v_ael_exame_solic_atd_aghu TO acesso_completo;
GRANT ALL ON TABLE agh.v_ael_exame_solic_atd_aghu TO postgres;
GRANT SELECT ON TABLE agh.v_ael_exame_solic_atd_aghu TO acesso_leitura;

CREATE OR REPLACE VIEW agh.v_abs_unf_executa_exames
 AS
SELECT exa.sigla,
       man.seq AS man_seq,
       ufe.unf_seq,
       exa.descricao_usual AS descricao_usual_exame
FROM agh.ael_exames exa,
     agh.ael_exames_material_analise ema,
     agh.ael_materiais_analises man,
     agh.ael_unf_executa_exames ufe,
     agh.agh_unidades_funcionais unf,
     agh.agh_caract_unid_funcionais cuf
WHERE ufe.ind_situacao::text = 'A'::text AND ema.exa_sigla::text = ufe.ema_exa_sigla::text AND ema.man_seq = ufe.ema_man_seq AND ema.ind_situacao::text = 'A'::text AND exa.sigla::text = ema.exa_sigla::text AND man.seq = ema.man_seq AND unf.seq = ufe.unf_seq AND unf.seq = cuf.unf_seq AND (cuf.caracteristica::text = ANY (ARRAY['Unid sorologia doadores'::character varying::text, 'Unid Radioimunoensaio'::character varying::text]));

ALTER TABLE agh.v_abs_unf_executa_exames
    OWNER TO postgres;

GRANT ALL ON TABLE agh.v_abs_unf_executa_exames TO acesso_completo;
GRANT ALL ON TABLE agh.v_abs_unf_executa_exames TO postgres;
GRANT SELECT ON TABLE agh.v_abs_unf_executa_exames TO acesso_leitura;



END $$