do
$$
declare
  qtd_linhas_afetadas INTEGER;
begin
IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'agh' and table_name = 'pdt_procs') then
UPDATE    agh.pdt_procs pdt
SET       proc_principal = (
          CASE epc.ind_principal
                    WHEN 'S' THEN TRUE
                    ELSE FALSE
          END
          )
FROM      agh.mbc_cirurgias crg,
          agh.mbc_proc_esp_por_cirurgias epc,
          agh.pdt_descricoes ddt,
          agh.pdt_proc_diag_teraps dpt
WHERE     pdt.ddt_seq = ddt.seq
AND       pdt.dpt_seq = dpt.seq
AND       dpt.pci_seq = epc.epr_pci_seq
AND       epc.crg_seq = crg.seq
AND       ddt.crg_seq = crg.seq
AND       pdt.proc_principal IS NULL
AND       ddt.situacao = 'DEF';
 
GET DIAGNOSTICS qtd_linhas_afetadas = ROW_COUNT;
RAISE NOTICE 'Número de linhas atualizadas 1-agh.pdt_procs: [%]', qtd_linhas_afetadas;
ELSE
RAISE NOTICE 'Número de linhas atualizadas 1-agh.pdt_procs: (0)';
END IF;
 
IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'agh' and table_name = 'pdt_procs') then
UPDATE    agh.pdt_procs
SET       proc_principal = TRUE
WHERE     ddt_seq IN (
          SELECT    ddt_seq
          FROM      agh.pdt_procs pdt
          JOIN      agh.pdt_descricoes ddt ON pdt.ddt_seq = ddt.seq
          WHERE     proc_principal IS NULL
          AND       ddt.situacao = 'DEF'
          GROUP BY  ddt_seq
          HAVING    COUNT(1) = 1
          );
GET DIAGNOSTICS qtd_linhas_afetadas = ROW_COUNT;
RAISE NOTICE 'Número de linhas atualizadas 2-agh.pdt_procs: [%]', qtd_linhas_afetadas;
ELSE
RAISE NOTICE 'Número de linhas atualizadas 2-agh.pdt_procs: (0)';
END IF;
end;
$$