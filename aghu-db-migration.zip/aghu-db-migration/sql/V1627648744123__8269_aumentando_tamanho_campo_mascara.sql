DO $$
BEGIN

    DROP VIEW agh.resultado_exames_epf;
    DROP VIEW agh.v_integracao;
    DROP VIEW agh.v_ael_unf_executa_exames;
    DROP VIEW agh.v_ael_exames_solicitacao;
    DROP VIEW agh.v_ael_exame_mat_analise;
    DROP VIEW agh.v_ael_exa_agend_pac;
    DROP VIEW agh.v_temp_count_exames2;
    DROP VIEW agh.v_temp_count_exames;
    DROP VIEW agh.v_mco_exames;
    DROP VIEW agh.v_ael_pesq_pol_exames_unid;
    DROP VIEW agh.v_ael_pesq_pol_exame_unid_hist;
    DROP VIEW agh.v_ael_exames_solicitacao_atd_aghu;
    DROP VIEW agh.v_ael_exames_solicitacao_atd;
    DROP VIEW agh.v_ael_exames_liberados;
    DROP VIEW agh.v_ael_exame_solic_atd_aghu;
    DROP VIEW agh.v_abs_unf_executa_exames;

        IF not EXISTS (
              SELECT
              FROM information_schema.columns
              WHERE table_schema = 'agh'
              AND table_name = 'ael_exames'
              AND column_name = 'descricao'
           ) THEN
        ALTER TABLE agh.ael_exames ALTER COLUMN descricao TYPE varchar(200);
        END IF;
        IF EXISTS (
              SELECT
              FROM information_schema.columns
              WHERE table_schema = 'agh'
              AND table_name = 'ael_exames'
              AND column_name = 'descricao_usual'
           ) THEN
        ALTER TABLE agh.ael_exames ALTER COLUMN descricao_usual TYPE varchar(200);
        END IF;
        IF EXISTS (
                SELECT
                FROM information_schema.columns
                WHERE table_schema = 'agh'
                AND table_name = 'ael_resultados_codificados'
                AND column_name = 'descricao'
            ) THEN
        ALTER TABLE agh.ael_resultados_codificados ALTER COLUMN descricao TYPE varchar(10000);
        END IF;

    CREATE OR REPLACE VIEW agh.resultado_exames_epf
    AS
    SELECT ael_campos_laudo.nome AS nome_campo,
    ael_exames.descricao AS nome_exame,
    ael_materiais_analises.descricao AS mat_analise,
    ael_resultados_codificados.descricao,
    ael_resultados_exames.valor,
    ael_solicitacao_exames.seq,
    aip_pacientes.nome AS nome_paciente,
    agh_atendimentos.dthr_inicio,
    agh_atendimentos.dthr_fim,
    agh_atendimentos.origem,
    agh_atendimentos.prontuario
    FROM agh.ael_campos_laudo ael_campos_laudo,
    agh.ael_exames ael_exames,
    agh.ael_exames_material_analise ael_exames_material_analise,
    agh.ael_item_solicitacao_exames ael_item_solicitacao_exames,
    agh.ael_materiais_analises ael_materiais_analises,
    agh.ael_parametro_campos_laudo ael_parametro_campos_laudo,
    agh.ael_solicitacao_exames ael_solicitacao_exames,
    agh.ael_unf_executa_exames ael_unf_executa_exames,
    agh.aip_pacientes aip_pacientes,
    agh.agh_atendimentos agh_atendimentos,
    agh.ael_resultados_exames ael_resultados_exames
    LEFT JOIN agh.ael_resultados_codificados ael_resultados_codificados ON ael_resultados_codificados.gtc_seq = ael_resultados_exames.rcd_gtc_seq AND ael_resultados_codificados.seqp = ael_resultados_exames.rcd_seqp
    WHERE ael_campos_laudo.seq = ael_parametro_campos_laudo.cal_seq AND ael_exames.sigla::text = ael_exames_material_analise.exa_sigla::text AND ael_materiais_analises.seq = ael_exames_material_analise.man_seq AND ael_exames_material_analise.exa_sigla::text = ael_unf_executa_exames.ema_exa_sigla::text AND ael_exames_material_analise.man_seq = ael_unf_executa_exames.ema_man_seq AND ael_solicitacao_exames.seq = ael_item_solicitacao_exames.soe_seq AND ael_unf_executa_exames.ema_exa_sigla::text = ael_item_solicitacao_exames.ufe_ema_exa_sigla::text AND ael_unf_executa_exames.ema_man_seq = ael_item_solicitacao_exames.ufe_ema_man_seq AND ael_unf_executa_exames.unf_seq = ael_item_solicitacao_exames.ufe_unf_seq AND ael_item_solicitacao_exames.soe_seq = ael_resultados_exames.ise_soe_seq AND ael_item_solicitacao_exames.seqp = ael_resultados_exames.ise_seqp AND ael_parametro_campos_laudo.vel_ema_exa_sigla::text = ael_resultados_exames.pcl_vel_ema_exa_sigla::text AND ael_parametro_campos_laudo.vel_ema_man_seq = ael_resultados_exames.pcl_vel_ema_man_seq AND ael_parametro_campos_laudo.vel_seqp = ael_resultados_exames.pcl_vel_seqp AND ael_parametro_campos_laudo.cal_seq = ael_resultados_exames.pcl_cal_seq AND ael_parametro_campos_laudo.seqp = ael_resultados_exames.pcl_seqp AND aip_pacientes.codigo = agh_atendimentos.pac_codigo AND agh_atendimentos.seq = ael_solicitacao_exames.atd_seq AND ael_item_solicitacao_exames.ufe_ema_exa_sigla::text = 'EPF'::text AND ael_campos_laudo.tipo_campo::text <> 'T'::text AND ael_item_solicitacao_exames.sit_codigo::text = 'LI'::text AND ael_resultados_exames.ind_anulacao_laudo::text <> 'S'::text;

    ALTER TABLE agh.resultado_exames_epf
    OWNER TO postgres;

    GRANT ALL ON TABLE agh.resultado_exames_epf TO acesso_completo;
    GRANT ALL ON TABLE agh.resultado_exames_epf TO postgres;
    GRANT SELECT ON TABLE agh.resultado_exames_epf TO acesso_leitura;

    CREATE OR REPLACE VIEW agh.v_integracao
    AS
    SELECT atd.pac_codigo AS pac_id,
    pac.nome AS pac_nome,
    pac.dt_nascimento AS pac_nascimento,
    pac.sexo AS pac_sexo,
    pac.nome_mae AS pac_mae,
    pac.fone_residencial AS pac_fone,
    pac.cpf AS pac_cpf,
    pac.rg AS pac_rg,
    pac.nro_cartao_saude AS pac_cns,
    CASE
    WHEN pac.cor::text = 'B'::text THEN 'Branca'::text
    WHEN pac.cor::text = 'P'::text THEN 'Preta'::text
    WHEN pac.cor::text = 'M'::text THEN 'Parda'::text
    WHEN pac.cor::text = 'A'::text THEN 'Amarela'::text
    WHEN pac.cor::text = 'I'::text THEN 'Indigena'::text
    ELSE 'Sem declaracao'::text
    END AS pac_cor,
    CASE
    WHEN end_pac.bcl_clo_cep IS NOT NULL THEN concat(logr_pac.nome, ', ', end_pac.nro_logradouro)
    ELSE concat(end_pac.logradouro, ', ', end_pac.nro_logradouro)
    END AS pac_endereco,
    end_pac.compl_logradouro AS pac_end_compl,
    CASE
    WHEN end_pac.bcl_clo_cep IS NOT NULL THEN bai_pac.descricao
    ELSE end_pac.bairro
    END AS pac_end_bairro,
    CASE
    WHEN end_pac.bcl_clo_cep IS NOT NULL THEN end_pac.bcl_clo_cep
    ELSE end_pac.cep
    END AS pac_end_cep,
    CASE
    WHEN end_pac.bcl_clo_cep IS NOT NULL THEN cid_pac.nome
    WHEN end_pac.cdd_codigo IS NOT NULL THEN end_cid_pac.nome
    ELSE end_pac.cidade
    END AS pac_end_cidade,
    CASE
    WHEN end_pac.bcl_clo_cep IS NOT NULL THEN cid_pac.uf_sigla
    WHEN end_pac.cdd_codigo IS NOT NULL THEN end_cid_pac.uf_sigla
    ELSE end_pac.uf_sigla
    END AS pac_end_uf,
    cnv.codigo AS exame_conv_id,
    cnv.descricao AS exame_conv_descr,
    solic.unf_seq AS unid_requisitante_id,
    unf_solic.descricao AS unid_requisitante_descr,
    unf_solic.ind_unid_internacao AS und_req_interna,
    unf_exec.unf_seq AS unid_entrega_id,
    unf.descricao AS unid_entrega_descr,
    atd.lto_lto_id AS unid_leito_id,
    CASE
    WHEN qualif.nro_reg_conselho IS NOT NULL THEN qualif.nro_reg_conselho
    ELSE qualif2.nro_reg_conselho
    END AS solic_reg,
    CASE
    WHEN qualif.nro_reg_conselho IS NOT NULL THEN pessoa.uf_sigla
    ELSE pessoa2.uf_sigla
    END AS solic_uf,
    CASE
    WHEN qualif.nro_reg_conselho IS NOT NULL THEN conselho.sigla
    ELSE conselho2.sigla
    END AS solic_conselho,
    CASE
    WHEN qualif.nro_reg_conselho IS NOT NULL THEN pessoa.nome
    ELSE pessoa2.nome
    END AS solic_nome,
    CASE
    WHEN qualif.nro_reg_conselho IS NOT NULL THEN pessoa.dt_nascimento
    ELSE pessoa2.dt_nascimento
    END AS solic_nascimento,
    CASE
    WHEN qualif.nro_reg_conselho IS NOT NULL THEN pessoa.sexo
    ELSE pessoa2.sexo
    END AS solic_sexo,
    CASE
    WHEN qualif.nro_reg_conselho IS NOT NULL THEN serv.email
    ELSE serv2.email
    END AS solic_email,
    item_solic.ufe_ema_exa_sigla AS exame_id,
    exa.descricao AS exame_descr,
    item_solic.ufe_ema_man_seq AS exame_mat_id,
    mat_an.descricao AS exame_descr_mat_analise,
    ex_mat_an.ind_dependente AS exame_dependente,
    tip_am_exa.nro_amostras AS exame_qtde_amostras,
    item_hr.hed_dthr_agenda AS exame_datahora,
    solic.informacoes_clinicas AS exame_info_adic,
    solic.atd_seq AS atendimento_id,
    solic.seq AS solic_exame,
    item_solic.seqp AS solic_seq_item,
    solic.criado_em AS solic_criada_em,
    sit_solic.sit_codigo AS solic_status,
    sit_solic_ex.descricao AS solic_status_descr,
    sit_solic.criado_em AS solic_sit_exame_datahora,
    amo.man_seq AS tipo_am_exa,
    item_solic.desc_material_analise,
    atd.prontuario AS pac_same,
    int_col.descricao AS intervalo_coleta,
    CASE
    WHEN int_col.nro_amostras IS NULL THEN 1::bigint
    ELSE int_col.nro_amostras
    END AS nro_amostras
    FROM agh.ael_solicitacao_exames solic
    JOIN agh.agh_atendimentos atd ON atd.seq = solic.atd_seq
    JOIN agh.ael_item_solicitacao_exames item_solic ON item_solic.soe_seq = solic.seq
    JOIN agh.ael_exames exa ON item_solic.ufe_ema_exa_sigla::text = exa.sigla::text
    JOIN agh.ael_unf_executa_exames unf_exec ON unf_exec.ema_exa_sigla::text = exa.sigla::text AND item_solic.ufe_ema_exa_sigla::text = unf_exec.ema_exa_sigla::text AND item_solic.ufe_ema_man_seq = unf_exec.ema_man_seq AND item_solic.ufe_unf_seq = unf_exec.unf_seq
    JOIN agh.ael_exames_material_analise ex_mat_an ON ex_mat_an.exa_sigla::text = exa.sigla::text AND ex_mat_an.man_seq = item_solic.ufe_ema_man_seq
    JOIN agh.ael_materiais_analises mat_an ON mat_an.seq = ex_mat_an.man_seq
    JOIN agh.agh_unidades_funcionais unf ON unf.seq = unf_exec.unf_seq
    JOIN agh.agh_unidades_funcionais unf_solic ON unf_solic.seq = solic.unf_seq
    LEFT JOIN agh.ael_tipos_amostra_exames tip_am_exa ON mat_an.seq = tip_am_exa.man_seq AND ex_mat_an.exa_sigla::text = tip_am_exa.ema_exa_sigla::text AND ex_mat_an.man_seq = tip_am_exa.ema_man_seq
    LEFT JOIN agh.ael_item_horario_agendados item_hr ON item_hr.ise_soe_seq = item_solic.soe_seq AND item_hr.ise_seqp = item_solic.seqp
    JOIN agh.rap_servidores serv ON solic.ser_matricula = serv.matricula
    JOIN agh.rap_pessoas_fisicas pessoa ON pessoa.codigo = serv.pes_codigo
    LEFT JOIN agh.rap_qualificacoes qualif ON qualif.pes_codigo = pessoa.codigo AND qualif.sequencia = (( SELECT max(q.sequencia) AS max
    FROM agh.rap_qualificacoes q
    WHERE q.pes_codigo = qualif.pes_codigo))
    LEFT JOIN agh.rap_tipos_qualificacao tipo_qualif ON qualif.tql_codigo = tipo_qualif.codigo
    LEFT JOIN agh.rap_conselhos_profissionais conselho ON tipo_qualif.cpr_codigo = conselho.codigo
    JOIN agh.fat_conv_saude_planos cnv_planos ON cnv_planos.seq = solic.csp_seq AND cnv_planos.cnv_codigo = solic.csp_cnv_codigo
    JOIN agh.fat_convenios_saude cnv ON cnv.codigo = cnv_planos.cnv_codigo
    JOIN agh.aip_pacientes pac ON atd.pac_codigo = pac.codigo
    JOIN agh.aip_enderecos_pacientes end_pac ON end_pac.pac_codigo = pac.codigo
    LEFT JOIN agh.aip_cidades end_cid_pac ON end_cid_pac.codigo = end_pac.cdd_codigo
    LEFT JOIN agh.aip_bairros bai_pac ON end_pac.bcl_bai_codigo = bai_pac.codigo
    LEFT JOIN agh.aip_logradouros logr_pac ON end_pac.bcl_clo_lgr_codigo = logr_pac.codigo
    LEFT JOIN agh.aip_cidades cid_pac ON logr_pac.cdd_codigo = cid_pac.codigo
    JOIN agh.ael_sit_item_solicitacoes sit_solic_ex ON sit_solic_ex.codigo::text = item_solic.sit_codigo::text
    JOIN agh.ael_extrato_item_solics sit_solic ON item_solic.soe_seq = sit_solic.ise_soe_seq AND item_solic.seqp = sit_solic.ise_seqp AND sit_solic.seqp = (( SELECT max(es1.seqp) AS max
    FROM agh.ael_extrato_item_solics es1
    WHERE sit_solic.ise_soe_seq = es1.ise_soe_seq AND sit_solic.ise_seqp = es1.ise_seqp))
    LEFT JOIN agh.ael_amostra_item_exames am_item_ex ON item_solic.soe_seq = am_item_ex.ise_soe_seq AND item_solic.seqp = am_item_ex.ise_seqp AND am_item_ex.amo_seqp = 1
    LEFT JOIN agh.ael_amostras amo ON am_item_ex.amo_soe_seq = amo.soe_seq AND am_item_ex.amo_seqp = amo.seqp
    LEFT JOIN ( SELECT vic.seq,
    vic.descricao,
    vic.tipo_substancia,
    vic.ema_exa_sigla,
    vic.ema_man_seq,
    count(vic.seq) AS nro_amostras
    FROM agh.v_ael_intervalo_coletas vic
    GROUP BY vic.seq, vic.descricao, vic.tipo_substancia, vic.ema_exa_sigla, vic.ema_man_seq) int_col ON item_solic.ico_seq = int_col.seq
    JOIN agh.rap_servidores serv2 ON solic.ser_matricula_eh_responsabilid = serv2.matricula
    JOIN agh.rap_pessoas_fisicas pessoa2 ON pessoa2.codigo = serv2.pes_codigo
    LEFT JOIN agh.rap_qualificacoes qualif2 ON qualif2.pes_codigo = pessoa2.codigo AND qualif2.sequencia = (( SELECT max(q.sequencia) AS max
    FROM agh.rap_qualificacoes q
    WHERE q.pes_codigo = qualif2.pes_codigo))
    LEFT JOIN agh.rap_tipos_qualificacao tipo_qualif2 ON qualif2.tql_codigo = tipo_qualif2.codigo
    LEFT JOIN agh.rap_conselhos_profissionais conselho2 ON tipo_qualif2.cpr_codigo = conselho2.codigo
    ORDER BY solic.seq DESC, item_solic.seqp;

    ALTER TABLE agh.v_integracao
    OWNER TO postgres;

    GRANT ALL ON TABLE agh.v_integracao TO ugen_aghu;
    GRANT ALL ON TABLE agh.v_integracao TO acesso_completo;
    GRANT ALL ON TABLE agh.v_integracao TO postgres;
    GRANT SELECT ON TABLE agh.v_integracao TO acesso_leitura;

    CREATE OR REPLACE VIEW agh.v_ael_unf_executa_exames
    AS
    SELECT ema.exa_sigla AS sigla,
    ema.man_seq,
    ufe.unf_seq,
    exa.descricao AS descricao_exame,
    exa.descricao_usual AS descricao_usual_exame,
    man.descricao AS descricao_material,
    unf.descricao AS descricao_unidade,
    ufe.tempo_medio_ocup_sala AS tempo_ocup_sala,
    ufe.ind_agendam_previo_int,
    ufe.ind_agendam_previo_nao_int,
    ufe.ind_situacao AS ind_situacao_ufe,
    ufe.motivo_desativacao,
    ufe.ind_desativa_temp AS ufe_ind_desativa_temp,
    ufe.dthr_reativa_temp AS ufe_dthr_reativa_temp,
    (((substr(exa.descricao_usual::text, 1, 35) || ' / '::text) || substr(man.descricao::text, 1, 35)) || ' / '::text) || substr(unf.descricao::text, 1, 20) AS exa_man_unidade
    FROM agh.agh_unidades_funcionais unf,
    agh.ael_materiais_analises man,
    agh.ael_exames exa,
    agh.ael_exames_material_analise ema,
    agh.ael_unf_executa_exames ufe
    WHERE ema.exa_sigla::text = ufe.ema_exa_sigla::text AND ema.man_seq = ufe.ema_man_seq AND exa.sigla::text = ema.exa_sigla::text AND man.seq = ema.man_seq AND unf.seq = ufe.unf_seq;

    ALTER TABLE agh.v_ael_unf_executa_exames
    OWNER TO postgres;

    GRANT ALL ON TABLE agh.v_ael_unf_executa_exames TO acesso_completo;
    GRANT ALL ON TABLE agh.v_ael_unf_executa_exames TO postgres;
    GRANT SELECT ON TABLE agh.v_ael_unf_executa_exames TO acesso_leitura;

    CREATE OR REPLACE VIEW agh.v_ael_exames_solicitacao
    AS
    SELECT ema.exa_sigla AS sigla,
    ema.man_seq,
    ufe.unf_seq,
    exa.descricao AS descricao_exame,
    sie.nome AS descricao_usual_exame,
    man.descricao AS descricao_material,
    unf.descricao AS descricao_unidade,
    ema.ind_dependente
    FROM agh.agh_unidades_funcionais unf,
    agh.ael_materiais_analises man,
    agh.ael_exames exa,
    agh.ael_sinonimos_exames sie,
    agh.ael_exames_material_analise ema,
    agh.ael_unf_executa_exames ufe
    WHERE ufe.ind_situacao::text = 'A'::text AND ema.exa_sigla::text = ufe.ema_exa_sigla::text AND ema.man_seq = ufe.ema_man_seq AND ema.ind_situacao::text = 'A'::text AND sie.exa_sigla::text = ema.exa_sigla::text AND sie.ind_situacao::text = 'A'::text AND exa.sigla::text = ema.exa_sigla::text AND exa.ind_situacao::text = 'A'::text AND man.seq = ema.man_seq AND man.ind_situacao::text = 'A'::text AND unf.seq = ufe.unf_seq AND unf.ind_sit_unid_func::text = 'A'::text;

    ALTER TABLE agh.v_ael_exames_solicitacao
    OWNER TO postgres;

    GRANT ALL ON TABLE agh.v_ael_exames_solicitacao TO acesso_completo;
    GRANT ALL ON TABLE agh.v_ael_exames_solicitacao TO postgres;
    GRANT SELECT ON TABLE agh.v_ael_exames_solicitacao TO acesso_leitura;

    CREATE OR REPLACE VIEW agh.v_ael_exame_mat_analise
     AS
     SELECT ema.exa_sigla AS sigla,
        ema.man_seq,
        exa.descricao AS descricao_exame,
        exa.descricao_usual AS descricao_usual_exame,
        man.descricao AS descricao_material,
        (exa.descricao_usual::text || ' /  '::text) || man.descricao::text AS nome_usual_material,
        ema.ind_dependente,
        ema.ind_cci,
        man.ind_exige_desc_mat_anls,
        ema.ind_limita_solic,
        ema.ind_comedi,
        ema.ind_situacao
       FROM agh.ael_materiais_analises man,
        agh.ael_exames exa,
        agh.ael_exames_material_analise ema
      WHERE exa.sigla::text = ema.exa_sigla::text AND man.seq = ema.man_seq AND ema.ind_situacao::text = 'A'::text;

    ALTER TABLE agh.v_ael_exame_mat_analise
        OWNER TO postgres;

    GRANT ALL ON TABLE agh.v_ael_exame_mat_analise TO acesso_completo;
    GRANT ALL ON TABLE agh.v_ael_exame_mat_analise TO postgres;
    GRANT SELECT ON TABLE agh.v_ael_exame_mat_analise TO acesso_leitura;

CREATE OR REPLACE VIEW agh.v_ael_exa_agend_pac
 AS
 SELECT atd.pac_codigo,
    ise.soe_seq AS ise_soe_seq,
    iha.hed_dthr_agenda,
    ise.ufe_ema_exa_sigla AS exa_sigla,
    ise.ufe_ema_man_seq AS man_seq,
    ise.ufe_unf_seq AS unf_seq,
    exa.descricao AS descricao_exame,
    ise.soe_seq AS ise_solicitacao,
    iha.hed_gae_unf_seq,
    iha.hed_gae_seqp,
    soe.criado_em AS data_solic
   FROM agh.ael_exames exa,
    agh.ael_item_horario_agendados iha,
    agh.ael_item_solicitacao_exames ise,
    agh.ael_solicitacao_exames soe,
    agh.agh_atendimentos atd
  WHERE soe.atd_seq = atd.seq AND ise.soe_seq = soe.seq AND iha.ise_soe_seq = ise.soe_seq AND iha.ise_seqp = ise.seqp AND iha.hed_dthr_agenda >= 'now'::text::date AND exa.sigla::text = ise.ufe_ema_exa_sigla::text;

ALTER TABLE agh.v_ael_exa_agend_pac
    OWNER TO postgres;

GRANT ALL ON TABLE agh.v_ael_exa_agend_pac TO acesso_completo;
GRANT ALL ON TABLE agh.v_ael_exa_agend_pac TO postgres;
GRANT SELECT ON TABLE agh.v_ael_exa_agend_pac TO acesso_leitura;

CREATE OR REPLACE VIEW agh.v_temp_count_exames2
 AS
 SELECT DISTINCT atd.pac_codigo,
    count(exa.descricao_usual) AS tot_exames,
    exa.descricao_usual AS exame
   FROM agh.ael_exames exa,
    agh.agh_atendimentos atd,
    agh.ael_solicitacao_exames soe,
    agh.ael_item_solicitacao_exames ise
  WHERE ise.dthr_liberada >= to_date('01042009000000'::text, 'ddmmyyyyhh24miss'::text) AND ise.dthr_liberada <= to_date('30042009235959'::text, 'ddmmyyyyhh24miss'::text) AND substr(ise.sit_codigo::text, 1, 2) = 'LI'::text AND (ise.ufe_unf_seq = ANY (ARRAY[154, 26, 23])) AND soe.seq = ise.soe_seq AND atd.seq = soe.atd_seq AND exa.sigla::text = ise.ufe_ema_exa_sigla::text
  GROUP BY atd.pac_codigo, exa.descricao_usual
  ORDER BY atd.pac_codigo, count(exa.descricao_usual), exa.descricao_usual;

ALTER TABLE agh.v_temp_count_exames2
    OWNER TO postgres;

GRANT ALL ON TABLE agh.v_temp_count_exames2 TO acesso_completo;
GRANT ALL ON TABLE agh.v_temp_count_exames2 TO postgres;
GRANT SELECT ON TABLE agh.v_temp_count_exames2 TO acesso_leitura;

CREATE OR REPLACE VIEW agh.v_temp_count_exames
 AS
 SELECT DISTINCT atd.pac_codigo,
    count(exa.descricao_usual) AS exame
   FROM agh.ael_exames exa,
    agh.agh_atendimentos atd,
    agh.ael_solicitacao_exames soe,
    agh.ael_item_solicitacao_exames ise
  WHERE ise.dthr_liberada >= to_date('01052009000000'::text, 'ddmmyyyyhh24miss'::text) AND ise.dthr_liberada <= to_date('31052009235959'::text, 'ddmmyyyyhh24miss'::text) AND substr(ise.sit_codigo::text, 1, 2) = 'LI'::text AND (ise.ufe_unf_seq = ANY (ARRAY[154, 26, 23])) AND soe.seq = ise.soe_seq AND atd.seq = soe.atd_seq AND exa.sigla::text = ise.ufe_ema_exa_sigla::text
  GROUP BY atd.pac_codigo
  ORDER BY atd.pac_codigo, count(exa.descricao_usual);

ALTER TABLE agh.v_temp_count_exames
    OWNER TO postgres;

GRANT ALL ON TABLE agh.v_temp_count_exames TO acesso_completo;
GRANT ALL ON TABLE agh.v_temp_count_exames TO postgres;
GRANT SELECT ON TABLE agh.v_temp_count_exames TO acesso_leitura;

CREATE OR REPLACE VIEW agh.v_mco_exames
 AS
 SELECT (COALESCE(ema.exa_sigla, ' '::character varying)::text || COALESCE(ema.man_seq::text, '0'::text)) || '0'::text AS chave,
    ema.exa_sigla,
    ema.man_seq,
    NULL::integer AS eex_seq,
    (exa.descricao_usual::text || '-'::text) || man.descricao::text AS descricao,
    'HCPA'::text AS origem
   FROM agh.ael_materiais_analises man,
    agh.ael_exames exa,
    agh.ael_exames_material_analise ema
  WHERE ema.ind_situacao::text = 'A'::text AND exa.sigla::text = ema.exa_sigla::text AND man.seq = ema.man_seq
UNION
 SELECT (' '::text || '0'::text) || COALESCE(eex.seq::text, '0'::text) AS chave,
    NULL::character varying AS exa_sigla,
    NULL::integer AS man_seq,
    eex.seq AS eex_seq,
    eex.descricao,
    'EXT'::text AS origem
   FROM agh.mco_exame_externos eex
  WHERE eex.ind_situacao::text = 'A'::text;

ALTER TABLE agh.v_mco_exames
    OWNER TO postgres;

GRANT ALL ON TABLE agh.v_mco_exames TO acesso_completo;
GRANT ALL ON TABLE agh.v_mco_exames TO postgres;
GRANT SELECT ON TABLE agh.v_mco_exames TO acesso_leitura;

CREATE OR REPLACE VIEW agh.v_ael_pesq_pol_exames_unid
 AS
 SELECT "substring"(unf.descricao::text, 1, 30) AS unf_descricao,
    unf.seq AS unf_seq,
        CASE
            WHEN ise.sit_codigo::text = 'LI'::text THEN ( SELECT max(eis.dthr_evento) AS max
               FROM agh.ael_extrato_item_solics eis
              WHERE eis.ise_soe_seq = soe.seq AND eis.ise_seqp = ise.seqp AND eis.sit_codigo::text = 'AE'::text)
            WHEN ise.sit_codigo::text <> 'LI'::text THEN soe.criado_em
            ELSE NULL::timestamp without time zone
        END AS data,
    oem.ordem_nivel1,
    oem.ordem_nivel2,
    exa.descricao_usual,
    man.descricao,
    ise.soe_seq,
    ise.seqp,
    atd.pac_codigo
   FROM agh.agh_atendimentos atd
     JOIN agh.ael_solicitacao_exames soe ON atd.seq = soe.atd_seq
     JOIN agh.ael_item_solicitacao_exames ise ON soe.seq = ise.soe_seq
     JOIN agh.ael_exames exa ON exa.sigla::text = ise.ufe_ema_exa_sigla::text
     JOIN agh.ael_materiais_analises man ON man.seq = ise.ufe_ema_man_seq
     JOIN agh.agh_unidades_funcionais unf ON unf.seq = ise.ufe_unf_seq
     LEFT JOIN agh.ael_ord_exame_mat_analises oem ON oem.ema_exa_sigla::text = ise.ufe_ema_exa_sigla::text AND oem.ema_man_seq = ise.ufe_ema_man_seq
  WHERE ise.sit_codigo::text <> 'CA'::text
UNION
 SELECT "substring"(unf.descricao::text, 1, 30) AS unf_descricao,
    unf.seq AS unf_seq,
        CASE
            WHEN ise.sit_codigo::text = 'LI'::text THEN ( SELECT max(eis.dthr_evento) AS max
               FROM agh.ael_extrato_item_solics eis
              WHERE eis.ise_soe_seq = soe.seq AND eis.ise_seqp = ise.seqp AND eis.sit_codigo::text = 'AE'::text)
            WHEN ise.sit_codigo::text <> 'LI'::text THEN soe.criado_em
            ELSE NULL::timestamp without time zone
        END AS data,
    oem.ordem_nivel1,
    oem.ordem_nivel2,
    exa.descricao_usual,
    man.descricao,
    ise.soe_seq,
    ise.seqp,
    atv.pac_codigo
   FROM agh.ael_atendimento_diversos atv
     JOIN agh.ael_solicitacao_exames soe ON atv.seq = soe.atv_seq
     JOIN agh.ael_item_solicitacao_exames ise ON soe.seq = ise.soe_seq
     JOIN agh.ael_exames exa ON exa.sigla::text = ise.ufe_ema_exa_sigla::text
     JOIN agh.ael_materiais_analises man ON man.seq = ise.ufe_ema_man_seq
     JOIN agh.agh_unidades_funcionais unf ON unf.seq = ise.ufe_unf_seq
     LEFT JOIN agh.ael_ord_exame_mat_analises oem ON oem.ema_exa_sigla::text = ise.ufe_ema_exa_sigla::text AND oem.ema_man_seq = ise.ufe_ema_man_seq
  WHERE soe.atv_seq = atv.seq AND ise.soe_seq = soe.seq AND ise.sit_codigo::text <> 'CA'::text AND exa.sigla::text = ise.ufe_ema_exa_sigla::text AND man.seq = ise.ufe_ema_man_seq AND unf.seq = ise.ufe_unf_seq AND oem.ema_exa_sigla::text = ise.ufe_ema_exa_sigla::text AND oem.ema_man_seq = ise.ufe_ema_man_seq
  ORDER BY 1, 3 DESC, 4, 5, 6, 7;

ALTER TABLE agh.v_ael_pesq_pol_exames_unid
    OWNER TO postgres;

GRANT ALL ON TABLE agh.v_ael_pesq_pol_exames_unid TO acesso_completo;
GRANT ALL ON TABLE agh.v_ael_pesq_pol_exames_unid TO postgres;
GRANT SELECT ON TABLE agh.v_ael_pesq_pol_exames_unid TO acesso_leitura;

CREATE OR REPLACE VIEW agh.v_ael_pesq_pol_exame_unid_hist
 AS
 SELECT "substring"(unf.descricao::text, 1, 30) AS unf_descricao,
    unf.seq AS unf_seq,
        CASE
            WHEN ise.sit_codigo::text = 'LI'::text THEN ( SELECT max(eis.dthr_evento) AS max
               FROM hist.ael_extrato_item_solics eis
              WHERE eis.ise_soe_seq = soe.seq AND eis.ise_seqp = ise.seqp AND eis.sit_codigo::text = 'AE'::text)
            WHEN ise.sit_codigo::text <> 'LI'::text THEN soe.criado_em
            ELSE NULL::timestamp without time zone
        END AS data,
    oem.ordem_nivel1,
    oem.ordem_nivel2,
    exa.descricao_usual,
    man.descricao,
    ise.soe_seq,
    ise.seqp,
    atd.pac_codigo
   FROM agh.agh_atendimentos atd
     JOIN hist.ael_solicitacao_exames soe ON atd.seq = soe.atd_seq
     JOIN hist.ael_item_solicitacao_exames ise ON soe.seq = ise.soe_seq
     JOIN agh.ael_exames exa ON exa.sigla::text = ise.ufe_ema_exa_sigla::text
     JOIN agh.ael_materiais_analises man ON man.seq = ise.ufe_ema_man_seq
     JOIN agh.agh_unidades_funcionais unf ON unf.seq = ise.ufe_unf_seq
     LEFT JOIN agh.ael_ord_exame_mat_analises oem ON oem.ema_exa_sigla::text = ise.ufe_ema_exa_sigla::text AND oem.ema_man_seq = ise.ufe_ema_man_seq
  WHERE ise.sit_codigo::text <> 'CA'::text
UNION
 SELECT "substring"(unf.descricao::text, 1, 30) AS unf_descricao,
    unf.seq AS unf_seq,
        CASE
            WHEN ise.sit_codigo::text = 'LI'::text THEN ( SELECT max(eis.dthr_evento) AS max
               FROM hist.ael_extrato_item_solics eis
              WHERE eis.ise_soe_seq = soe.seq AND eis.ise_seqp = ise.seqp AND eis.sit_codigo::text = 'AE'::text)
            WHEN ise.sit_codigo::text <> 'LI'::text THEN soe.criado_em
            ELSE NULL::timestamp without time zone
        END AS data,
    oem.ordem_nivel1,
    oem.ordem_nivel2,
    exa.descricao_usual,
    man.descricao,
    ise.soe_seq,
    ise.seqp,
    atv.pac_codigo
   FROM agh.ael_atendimento_diversos atv
     JOIN hist.ael_solicitacao_exames soe ON atv.seq = soe.atv_seq
     JOIN hist.ael_item_solicitacao_exames ise ON soe.seq = ise.soe_seq
     JOIN agh.ael_exames exa ON exa.sigla::text = ise.ufe_ema_exa_sigla::text
     JOIN agh.ael_materiais_analises man ON man.seq = ise.ufe_ema_man_seq
     JOIN agh.agh_unidades_funcionais unf ON unf.seq = ise.ufe_unf_seq
     LEFT JOIN agh.ael_ord_exame_mat_analises oem ON oem.ema_exa_sigla::text = ise.ufe_ema_exa_sigla::text AND oem.ema_man_seq = ise.ufe_ema_man_seq
  WHERE soe.atv_seq = atv.seq AND ise.soe_seq = soe.seq AND ise.sit_codigo::text <> 'CA'::text AND exa.sigla::text = ise.ufe_ema_exa_sigla::text AND man.seq = ise.ufe_ema_man_seq AND unf.seq = ise.ufe_unf_seq AND oem.ema_exa_sigla::text = ise.ufe_ema_exa_sigla::text AND oem.ema_man_seq = ise.ufe_ema_man_seq
  ORDER BY 1, 3 DESC, 4, 5, 6, 7;

ALTER TABLE agh.v_ael_pesq_pol_exame_unid_hist
    OWNER TO postgres;

GRANT ALL ON TABLE agh.v_ael_pesq_pol_exame_unid_hist TO acesso_completo;
GRANT ALL ON TABLE agh.v_ael_pesq_pol_exame_unid_hist TO postgres;
GRANT SELECT ON TABLE agh.v_ael_pesq_pol_exame_unid_hist TO acesso_leitura;

CREATE OR REPLACE VIEW agh.v_ael_exames_solicitacao_atd_aghu
 AS
 SELECT soe.seq AS soe_seq,
    soe.atd_seq,
    soe.criado_em,
    man.descricao AS descricao_material,
    eis.dthr_evento,
    (exa.descricao_usual::text || ' /  '::text) || man.descricao::text AS nome_exame_material,
    pes.nome AS soe_servidor_nome,
    cnv.descricao AS cnv_descricao,
    atd.lto_lto_id,
    atd.qrt_numero,
    qrt.descricao AS qrt_descricao,
    atd.unf_seq,
    ise.dthr_programada,
    cnv.grupo_convenio,
    aie.origem_mapa,
    ise.ufe_ema_exa_sigla,
    ise.sit_codigo,
    ise.ufe_unf_seq,
    ( SELECT
                CASE
                    WHEN soetemp.atd_seq > 0 THEN pac_atd.nome
                    WHEN pac_atv.nome IS NOT NULL THEN
                    CASE
                        WHEN pjq.numero IS NOT NULL THEN ((('GPP-'::text || pjq.numero::text) || ' - '::text) || pac_atv.nome::text)::character varying
                        ELSE pac_atv.nome
                    END
                    WHEN atv.nome_paciente IS NOT NULL THEN
                    CASE
                        WHEN pjq.numero IS NOT NULL THEN ((('GPP-'::text || pjq.numero::text) || ' - '::text) || atv.nome_paciente::text)::character varying
                        ELSE atv.nome_paciente
                    END
                    WHEN pjq.numero IS NOT NULL THEN ((('GPP-'::text || pjq.numero::text) || ' - '::text) || pjq.nome::text)::character varying
                    WHEN ccq.seq IS NOT NULL THEN ccq.material
                    WHEN lae.seq IS NOT NULL THEN lae.nome
                    WHEN ddv.seq IS NOT NULL THEN ddv.nome
                    WHEN cad.seq IS NOT NULL THEN cad.nome
                    ELSE NULL::character varying
                END AS "case"
           FROM agh.ael_solicitacao_exames soetemp
             LEFT JOIN agh.agh_atendimentos atd_1 ON atd_1.seq = soetemp.atd_seq
             LEFT JOIN agh.aip_pacientes pac_atd ON pac_atd.codigo = atd_1.pac_codigo
             LEFT JOIN agh.ael_atendimento_diversos atv ON atv.seq = soetemp.atv_seq
             LEFT JOIN agh.aip_pacientes pac_atv ON pac_atv.codigo = atv.pac_codigo
             LEFT JOIN agh.ael_projeto_pesquisas pjq ON pjq.seq = atv.pjq_seq
             LEFT JOIN agh.ael_cad_ctrl_qualidades ccq ON ccq.seq = atv.ccq_seq
             LEFT JOIN agh.ael_laboratorio_externos lae ON lae.seq = atv.lae_seq
             LEFT JOIN agh.ael_dados_cadaveres ddv ON ddv.seq = atv.ddv_seq
             LEFT JOIN agh.abs_candidatos_doadores cad ON cad.seq = atv.cad_seq
          WHERE soetemp.seq = soe.seq) AS nome_paciente,
    ( SELECT COALESCE(pac.prontuario, atv.prontuario) AS "coalesce"
           FROM agh.ael_solicitacao_exames soetemp
             LEFT JOIN agh.agh_atendimentos atd_1 ON atd_1.seq = soetemp.atd_seq
             LEFT JOIN agh.ael_atendimento_diversos atv ON atv.seq = soetemp.atv_seq
             LEFT JOIN agh.aip_pacientes pac ON pac.codigo = COALESCE(atd_1.pac_codigo, atv.pac_codigo)
          WHERE soetemp.seq = soe.seq) AS prontuario,
    ( SELECT
                CASE
                    WHEN atd_1.origem::text = 'N'::text THEN 'I'::character varying
                    WHEN atd_1.origem IS NULL THEN 'D'::character varying
                    ELSE atd_1.origem
                END AS origem
           FROM agh.ael_solicitacao_exames soetemp
             LEFT JOIN agh.agh_atendimentos atd_1 ON atd_1.seq = soetemp.atd_seq
             LEFT JOIN agh.ael_atendimento_diversos atv ON atv.seq = soetemp.atv_seq
          WHERE soetemp.seq = soe.seq) AS origem,
    ( SELECT
                CASE
                    WHEN atd_1.lto_lto_id IS NOT NULL THEN 'L:'::text || atd_1.lto_lto_id::text
                    WHEN qrt_1.descricao IS NOT NULL THEN 'Q:'::text || qrt_1.descricao::text
                    WHEN atd_1.unf_seq IS NOT NULL THEN (((('U:'::text || auf.andar::text) || ' '::text) || auf.ind_ala::text) || ' - '::text) || auf.descricao::text
                    ELSE NULL::text
                END AS "case"
           FROM agh.ael_solicitacao_exames soetemp
             LEFT JOIN agh.agh_atendimentos atd_1 ON atd_1.seq = soetemp.atd_seq
             LEFT JOIN agh.ain_quartos qrt_1 ON atd_1.qrt_numero = qrt_1.numero
             LEFT JOIN agh.agh_unidades_funcionais auf ON auf.seq = atd_1.unf_seq
          WHERE soetemp.seq = soe.seq) AS localizacao
   FROM agh.ael_item_solicitacao_exames ise
     JOIN agh.ael_exames exa ON exa.sigla::text = ise.ufe_ema_exa_sigla::text
     JOIN agh.ael_materiais_analises man ON man.seq = ise.ufe_ema_man_seq
     JOIN agh.ael_extrato_item_solics eis ON eis.ise_soe_seq = ise.soe_seq AND eis.ise_seqp = ise.seqp AND eis.sit_codigo::text = ise.sit_codigo::text
     JOIN agh.ael_solicitacao_exames soe ON soe.seq = ise.soe_seq
     JOIN agh.fat_convenios_saude cnv ON cnv.codigo = soe.csp_cnv_codigo
     JOIN agh.rap_servidores ser ON ser.matricula = soe.ser_matricula_eh_responsabilid AND ser.vin_codigo = soe.ser_vin_codigo_eh_responsabili
     JOIN agh.rap_pessoas_fisicas pes ON pes.codigo = ser.pes_codigo
     LEFT JOIN agh.agh_atendimentos atd ON atd.seq = soe.atd_seq
     LEFT JOIN agh.ain_quartos qrt ON atd.qrt_numero = qrt.numero
     LEFT JOIN agh.ael_amostra_item_exames aie ON aie.ise_soe_seq = ise.soe_seq AND aie.ise_seqp = ise.seqp
  WHERE (eis.criado_em IN ( SELECT max(eis1.criado_em) AS max
           FROM agh.ael_extrato_item_solics eis1
          WHERE eis1.ise_soe_seq = eis.ise_soe_seq AND eis1.ise_seqp = eis.ise_seqp))
  GROUP BY soe.seq, soe.atd_seq, soe.criado_em, man.descricao, eis.dthr_evento, (exa.descricao_usual::text || ' /  '::text) || man.descricao::text, pes.nome, cnv.descricao, atd.lto_lto_id, atd.qrt_numero, qrt.descricao, atd.unf_seq, ise.dthr_programada, cnv.grupo_convenio, aie.origem_mapa, ise.ufe_ema_exa_sigla, ise.sit_codigo, ise.ufe_unf_seq, ( SELECT
                CASE
                    WHEN soetemp.atd_seq > 0 THEN pac_atd.nome
                    WHEN pac_atv.nome IS NOT NULL THEN
                    CASE
                        WHEN pjq.numero IS NOT NULL THEN ((('GPP-'::text || pjq.numero::text) || ' - '::text) || pac_atv.nome::text)::character varying
                        ELSE pac_atv.nome
                    END
                    WHEN atv.nome_paciente IS NOT NULL THEN
                    CASE
                        WHEN pjq.numero IS NOT NULL THEN ((('GPP-'::text || pjq.numero::text) || ' - '::text) || atv.nome_paciente::text)::character varying
                        ELSE atv.nome_paciente
                    END
                    WHEN pjq.numero IS NOT NULL THEN ((('GPP-'::text || pjq.numero::text) || ' - '::text) || pjq.nome::text)::character varying
                    WHEN ccq.seq IS NOT NULL THEN ccq.material
                    WHEN lae.seq IS NOT NULL THEN lae.nome
                    WHEN ddv.seq IS NOT NULL THEN ddv.nome
                    WHEN cad.seq IS NOT NULL THEN cad.nome
                    ELSE NULL::character varying
                END AS "case"
           FROM agh.ael_solicitacao_exames soetemp
             LEFT JOIN agh.agh_atendimentos atd_1 ON atd_1.seq = soetemp.atd_seq
             LEFT JOIN agh.aip_pacientes pac_atd ON pac_atd.codigo = atd_1.pac_codigo
             LEFT JOIN agh.ael_atendimento_diversos atv ON atv.seq = soetemp.atv_seq
             LEFT JOIN agh.aip_pacientes pac_atv ON pac_atv.codigo = atv.pac_codigo
             LEFT JOIN agh.ael_projeto_pesquisas pjq ON pjq.seq = atv.pjq_seq
             LEFT JOIN agh.ael_cad_ctrl_qualidades ccq ON ccq.seq = atv.ccq_seq
             LEFT JOIN agh.ael_laboratorio_externos lae ON lae.seq = atv.lae_seq
             LEFT JOIN agh.ael_dados_cadaveres ddv ON ddv.seq = atv.ddv_seq
             LEFT JOIN agh.abs_candidatos_doadores cad ON cad.seq = atv.cad_seq
          WHERE soetemp.seq = soe.seq), ( SELECT COALESCE(pac.prontuario, atv.prontuario) AS "coalesce"
           FROM agh.ael_solicitacao_exames soetemp
             LEFT JOIN agh.agh_atendimentos atd_1 ON atd_1.seq = soetemp.atd_seq
             LEFT JOIN agh.ael_atendimento_diversos atv ON atv.seq = soetemp.atv_seq
             LEFT JOIN agh.aip_pacientes pac ON pac.codigo = COALESCE(atd_1.pac_codigo, atv.pac_codigo)
          WHERE soetemp.seq = soe.seq), ( SELECT
                CASE
                    WHEN atd_1.origem::text = 'N'::text THEN 'I'::character varying
                    WHEN atd_1.origem IS NULL THEN 'D'::character varying
                    ELSE atd_1.origem
                END AS origem
           FROM agh.ael_solicitacao_exames soetemp
             LEFT JOIN agh.agh_atendimentos atd_1 ON atd_1.seq = soetemp.atd_seq
             LEFT JOIN agh.ael_atendimento_diversos atv ON atv.seq = soetemp.atv_seq
          WHERE soetemp.seq = soe.seq), ( SELECT
                CASE
                    WHEN atd_1.lto_lto_id IS NOT NULL THEN 'L:'::text || atd_1.lto_lto_id::text
                    WHEN qrt_1.descricao IS NOT NULL THEN 'Q:'::text || qrt_1.descricao::text
                    WHEN atd_1.unf_seq IS NOT NULL THEN (((('U:'::text || auf.andar::text) || ' '::text) || auf.ind_ala::text) || ' - '::text) || auf.descricao::text
                    ELSE NULL::text
                END AS "case"
           FROM agh.ael_solicitacao_exames soetemp
             LEFT JOIN agh.agh_atendimentos atd_1 ON atd_1.seq = soetemp.atd_seq
             LEFT JOIN agh.ain_quartos qrt_1 ON atd_1.qrt_numero = qrt_1.numero
             LEFT JOIN agh.agh_unidades_funcionais auf ON auf.seq = atd_1.unf_seq
          WHERE soetemp.seq = soe.seq);

ALTER TABLE agh.v_ael_exames_solicitacao_atd_aghu
    OWNER TO postgres;

GRANT ALL ON TABLE agh.v_ael_exames_solicitacao_atd_aghu TO acesso_completo;
GRANT ALL ON TABLE agh.v_ael_exames_solicitacao_atd_aghu TO postgres;
GRANT SELECT ON TABLE agh.v_ael_exames_solicitacao_atd_aghu TO acesso_leitura;

CREATE OR REPLACE VIEW agh.v_ael_exames_solicitacao_atd
 AS
 SELECT soe.seq AS soe_seq,
    soe.atd_seq,
    soe.criado_em,
    man.descricao AS descricao_material,
    eis.dthr_evento,
    (exa.descricao_usual::text || ' /  '::text) || man.descricao::text AS nome_exame_material,
    pes.nome AS soe_servidor_nome,
    cnv.descricao AS cnv_descricao,
    atd.lto_lto_id,
    atd.qrt_numero,
    atd.unf_seq,
    ise.dthr_programada,
    cnv.grupo_convenio,
    aie.origem_mapa,
    ise.ufe_ema_exa_sigla,
    ise.sit_codigo,
    ise.ufe_unf_seq,
    ( SELECT
                CASE
                    WHEN soetemp.atd_seq > 0 THEN pac_atd.nome
                    WHEN pac_atv.nome IS NOT NULL THEN
                    CASE
                        WHEN pjq.numero IS NOT NULL THEN ((('GPP-'::text || pjq.numero::text) || ' - '::text) || pac_atv.nome::text)::character varying
                        ELSE pac_atv.nome
                    END
                    WHEN atv.nome_paciente IS NOT NULL THEN
                    CASE
                        WHEN pjq.numero IS NOT NULL THEN ((('GPP-'::text || pjq.numero::text) || ' - '::text) || atv.nome_paciente::text)::character varying
                        ELSE atv.nome_paciente
                    END
                    WHEN pjq.numero IS NOT NULL THEN ((('GPP-'::text || pjq.numero::text) || ' - '::text) || pjq.nome::text)::character varying
                    WHEN ccq.seq IS NOT NULL THEN ccq.material
                    WHEN lae.seq IS NOT NULL THEN lae.nome
                    WHEN ddv.seq IS NOT NULL THEN ddv.nome
                    WHEN cad.seq IS NOT NULL THEN cad.nome
                    ELSE NULL::character varying
                END AS "case"
           FROM agh.ael_solicitacao_exames soetemp
             LEFT JOIN agh.agh_atendimentos atd_1 ON atd_1.seq = soetemp.atd_seq
             LEFT JOIN agh.aip_pacientes pac_atd ON pac_atd.codigo = atd_1.pac_codigo
             LEFT JOIN agh.ael_atendimento_diversos atv ON atv.seq = soetemp.atv_seq
             LEFT JOIN agh.aip_pacientes pac_atv ON pac_atv.codigo = atv.pac_codigo
             LEFT JOIN agh.ael_projeto_pesquisas pjq ON pjq.seq = atv.pjq_seq
             LEFT JOIN agh.ael_cad_ctrl_qualidades ccq ON ccq.seq = atv.ccq_seq
             LEFT JOIN agh.ael_laboratorio_externos lae ON lae.seq = atv.lae_seq
             LEFT JOIN agh.ael_dados_cadaveres ddv ON ddv.seq = atv.ddv_seq
             LEFT JOIN agh.abs_candidatos_doadores cad ON cad.seq = atv.cad_seq
          WHERE soetemp.seq = soe.seq) AS nome_paciente,
    ( SELECT COALESCE(pac.prontuario, atv.prontuario) AS "coalesce"
           FROM agh.ael_solicitacao_exames soetemp
             LEFT JOIN agh.agh_atendimentos atd_1 ON atd_1.seq = soetemp.atd_seq
             LEFT JOIN agh.ael_atendimento_diversos atv ON atv.seq = soetemp.atv_seq
             LEFT JOIN agh.aip_pacientes pac ON pac.codigo = COALESCE(atd_1.pac_codigo, atv.pac_codigo)
          WHERE soetemp.seq = soe.seq) AS prontuario,
    ( SELECT
                CASE
                    WHEN atd_1.origem::text = 'N'::text THEN 'I'::character varying
                    WHEN atd_1.origem IS NULL THEN 'D'::character varying
                    ELSE atd_1.origem
                END AS origem
           FROM agh.ael_solicitacao_exames soetemp
             LEFT JOIN agh.agh_atendimentos atd_1 ON atd_1.seq = soetemp.atd_seq
             LEFT JOIN agh.ael_atendimento_diversos atv ON atv.seq = soetemp.atv_seq
          WHERE soetemp.seq = soe.seq) AS origem,
    ( SELECT
                CASE
                    WHEN atd_1.lto_lto_id IS NOT NULL THEN 'L:'::text || atd_1.lto_lto_id::text
                    WHEN atd_1.qrt_numero IS NOT NULL THEN 'Q:'::text || atd_1.qrt_numero
                    WHEN atd_1.unf_seq IS NOT NULL THEN (((('U:'::text || auf.andar::text) || ' '::text) || auf.ind_ala::text) || ' - '::text) || auf.descricao::text
                    ELSE NULL::text
                END AS "case"
           FROM agh.ael_solicitacao_exames soetemp
             LEFT JOIN agh.agh_atendimentos atd_1 ON atd_1.seq = soetemp.atd_seq
             LEFT JOIN agh.agh_unidades_funcionais auf ON auf.seq = atd_1.unf_seq
          WHERE soetemp.seq = soe.seq) AS localizacao
   FROM agh.ael_item_solicitacao_exames ise
     JOIN agh.ael_exames exa ON exa.sigla::text = ise.ufe_ema_exa_sigla::text
     JOIN agh.ael_materiais_analises man ON man.seq = ise.ufe_ema_man_seq
     JOIN agh.ael_extrato_item_solics eis ON eis.ise_soe_seq = ise.soe_seq AND eis.ise_seqp = ise.seqp AND eis.sit_codigo::text = ise.sit_codigo::text
     JOIN agh.ael_solicitacao_exames soe ON soe.seq = ise.soe_seq
     JOIN agh.fat_convenios_saude cnv ON cnv.codigo = soe.csp_cnv_codigo
     JOIN agh.rap_servidores ser ON ser.matricula = soe.ser_matricula_eh_responsabilid AND ser.vin_codigo = soe.ser_vin_codigo_eh_responsabili
     JOIN agh.rap_pessoas_fisicas pes ON pes.codigo = ser.pes_codigo
     LEFT JOIN agh.agh_atendimentos atd ON atd.seq = soe.atd_seq
     LEFT JOIN agh.ael_amostra_item_exames aie ON aie.ise_soe_seq = ise.soe_seq AND aie.ise_seqp = ise.seqp
  WHERE (eis.criado_em IN ( SELECT max(eis1.criado_em) AS max
           FROM agh.ael_extrato_item_solics eis1
          WHERE eis1.ise_soe_seq = eis.ise_soe_seq AND eis1.ise_seqp = eis.ise_seqp))
  GROUP BY soe.seq, soe.atd_seq, soe.criado_em, man.descricao, eis.dthr_evento, (exa.descricao_usual::text || ' /  '::text) || man.descricao::text, pes.nome, cnv.descricao, atd.lto_lto_id, atd.qrt_numero, atd.unf_seq, ise.dthr_programada, cnv.grupo_convenio, aie.origem_mapa, ise.ufe_ema_exa_sigla, ise.sit_codigo, ise.ufe_unf_seq, ( SELECT
                CASE
                    WHEN soetemp.atd_seq > 0 THEN pac_atd.nome
                    WHEN pac_atv.nome IS NOT NULL THEN
                    CASE
                        WHEN pjq.numero IS NOT NULL THEN ((('GPP-'::text || pjq.numero::text) || ' - '::text) || pac_atv.nome::text)::character varying
                        ELSE pac_atv.nome
                    END
                    WHEN atv.nome_paciente IS NOT NULL THEN
                    CASE
                        WHEN pjq.numero IS NOT NULL THEN ((('GPP-'::text || pjq.numero::text) || ' - '::text) || atv.nome_paciente::text)::character varying
                        ELSE atv.nome_paciente
                    END
                    WHEN pjq.numero IS NOT NULL THEN ((('GPP-'::text || pjq.numero::text) || ' - '::text) || pjq.nome::text)::character varying
                    WHEN ccq.seq IS NOT NULL THEN ccq.material
                    WHEN lae.seq IS NOT NULL THEN lae.nome
                    WHEN ddv.seq IS NOT NULL THEN ddv.nome
                    WHEN cad.seq IS NOT NULL THEN cad.nome
                    ELSE NULL::character varying
                END AS "case"
           FROM agh.ael_solicitacao_exames soetemp
             LEFT JOIN agh.agh_atendimentos atd_1 ON atd_1.seq = soetemp.atd_seq
             LEFT JOIN agh.aip_pacientes pac_atd ON pac_atd.codigo = atd_1.pac_codigo
             LEFT JOIN agh.ael_atendimento_diversos atv ON atv.seq = soetemp.atv_seq
             LEFT JOIN agh.aip_pacientes pac_atv ON pac_atv.codigo = atv.pac_codigo
             LEFT JOIN agh.ael_projeto_pesquisas pjq ON pjq.seq = atv.pjq_seq
             LEFT JOIN agh.ael_cad_ctrl_qualidades ccq ON ccq.seq = atv.ccq_seq
             LEFT JOIN agh.ael_laboratorio_externos lae ON lae.seq = atv.lae_seq
             LEFT JOIN agh.ael_dados_cadaveres ddv ON ddv.seq = atv.ddv_seq
             LEFT JOIN agh.abs_candidatos_doadores cad ON cad.seq = atv.cad_seq
          WHERE soetemp.seq = soe.seq), ( SELECT COALESCE(pac.prontuario, atv.prontuario) AS "coalesce"
           FROM agh.ael_solicitacao_exames soetemp
             LEFT JOIN agh.agh_atendimentos atd_1 ON atd_1.seq = soetemp.atd_seq
             LEFT JOIN agh.ael_atendimento_diversos atv ON atv.seq = soetemp.atv_seq
             LEFT JOIN agh.aip_pacientes pac ON pac.codigo = COALESCE(atd_1.pac_codigo, atv.pac_codigo)
          WHERE soetemp.seq = soe.seq), ( SELECT
                CASE
                    WHEN atd_1.origem::text = 'N'::text THEN 'I'::character varying
                    WHEN atd_1.origem IS NULL THEN 'D'::character varying
                    ELSE atd_1.origem
                END AS origem
           FROM agh.ael_solicitacao_exames soetemp
             LEFT JOIN agh.agh_atendimentos atd_1 ON atd_1.seq = soetemp.atd_seq
             LEFT JOIN agh.ael_atendimento_diversos atv ON atv.seq = soetemp.atv_seq
          WHERE soetemp.seq = soe.seq), ( SELECT
                CASE
                    WHEN atd_1.lto_lto_id IS NOT NULL THEN 'L:'::text || atd_1.lto_lto_id::text
                    WHEN atd_1.qrt_numero IS NOT NULL THEN 'Q:'::text || atd_1.qrt_numero
                    WHEN atd_1.unf_seq IS NOT NULL THEN (((('U:'::text || auf.andar::text) || ' '::text) || auf.ind_ala::text) || ' - '::text) || auf.descricao::text
                    ELSE NULL::text
                END AS "case"
           FROM agh.ael_solicitacao_exames soetemp
             LEFT JOIN agh.agh_atendimentos atd_1 ON atd_1.seq = soetemp.atd_seq
             LEFT JOIN agh.agh_unidades_funcionais auf ON auf.seq = atd_1.unf_seq
          WHERE soetemp.seq = soe.seq);

ALTER TABLE agh.v_ael_exames_solicitacao_atd
    OWNER TO postgres;

GRANT ALL ON TABLE agh.v_ael_exames_solicitacao_atd TO acesso_completo;
GRANT ALL ON TABLE agh.v_ael_exames_solicitacao_atd TO postgres;
GRANT SELECT ON TABLE agh.v_ael_exames_solicitacao_atd TO acesso_leitura;

CREATE OR REPLACE VIEW agh.v_ael_exames_liberados
 AS
 SELECT DISTINCT ise.seqp,
    sit.descricao AS situacao_codigo_descricao,
    ( SELECT max(aelextrato8_.dthr_evento) AS max
           FROM agh.ael_extrato_item_solics aelextrato8_
          WHERE aelextrato8_.ise_soe_seq = ise.soe_seq AND aelextrato8_.ise_seqp = ise.seqp AND aelextrato8_.sit_codigo::text = 'AE'::text) AS dthr_evento_extrato_item,
    ase.criado_em AS dthr_solic_criado_em,
    ( SELECT count(aelnotaadi9_.seqp) AS count
           FROM agh.ael_notas_adicionais aelnotaadi9_
          WHERE aelnotaadi9_.ise_soe_seq = ise.soe_seq AND aelnotaadi9_.ise_seqp = ise.seqp) AS qtde_nota_adicional,
    ama.descricao AS descricao_mat_analise,
    ama.seq AS seq_mat_analise,
    ael.descricao_usual,
    ase.seq AS soe_seq,
    aedoc.seq AS codigo_documento,
    ise.pac_oru_acc_number AS codigo_imagem,
    und.descricao AS unf_descricao,
    und.seq AS unf_seq,
    atd.pac_codigo
   FROM agh.ael_item_solicitacao_exames ise
     JOIN agh.ael_materiais_analises ama ON ise.ufe_ema_man_seq = ama.seq
     JOIN agh.ael_exames ael ON ise.ufe_ema_exa_sigla::text = ael.sigla::text
     JOIN agh.agh_unidades_funcionais und ON ise.ufe_unf_seq = und.seq
     JOIN agh.ael_solicitacao_exames ase ON ise.soe_seq = ase.seq
     JOIN agh.agh_atendimentos atd ON ase.atd_seq = atd.seq
     LEFT JOIN agh.ael_doc_resultado_exames aedoc ON ise.seqp = aedoc.ise_seqp AND ise.soe_seq = aedoc.ise_soe_seq
     LEFT JOIN agh.ael_resultados_exames are ON ise.seqp = are.ise_seqp AND ise.soe_seq = are.ise_soe_seq
     LEFT JOIN agh.ael_sit_item_solicitacoes sit ON sit.codigo::text = ise.sit_codigo::text
  WHERE ise.sit_codigo::text = 'LI'::text AND (aedoc.ind_anulacao_doc IS NULL OR aedoc.ind_anulacao_doc::text = 'N'::text);

ALTER TABLE agh.v_ael_exames_liberados
    OWNER TO postgres;

GRANT ALL ON TABLE agh.v_ael_exames_liberados TO postgres;
GRANT INSERT, SELECT, UPDATE, DELETE ON TABLE agh.v_ael_exames_liberados TO PUBLIC;

CREATE OR REPLACE VIEW agh.v_ael_exame_solic_atd_aghu
 AS
 SELECT soe.seq AS soe_seq,
    soe.atd_seq,
    soe.criado_em,
    man.descricao AS descricao_material,
    eis.dthr_evento,
    (exa.descricao_usual::text || ' /  '::text) || man.descricao::text AS nome_exame_material,
    pes.nome AS soe_servidor_nome,
    cnv.descricao AS cnv_descricao,
    atd.lto_lto_id,
    atd.qrt_numero,
    qrt.descricao AS qrt_descricao,
    atd.unf_seq,
    ise.dthr_programada,
    cnv.grupo_convenio,
    aie.origem_mapa,
    ise.ufe_ema_exa_sigla,
    ise.sit_codigo,
    ise.ufe_unf_seq,
    ( SELECT
                CASE
                    WHEN soetemp.atd_seq > 0 THEN pac_atd.nome
                    WHEN pac_atv.nome IS NOT NULL THEN
                    CASE
                        WHEN pjq.numero IS NOT NULL THEN ((('GPP-'::text || pjq.numero::text) || ' - '::text) || pac_atv.nome::text)::character varying
                        ELSE pac_atv.nome
                    END
                    WHEN atv.nome_paciente IS NOT NULL THEN
                    CASE
                        WHEN pjq.numero IS NOT NULL THEN ((('GPP-'::text || pjq.numero::text) || ' - '::text) || atv.nome_paciente::text)::character varying
                        ELSE atv.nome_paciente
                    END
                    WHEN pjq.numero IS NOT NULL THEN ((('GPP-'::text || pjq.numero::text) || ' - '::text) || pjq.nome::text)::character varying
                    WHEN ccq.seq IS NOT NULL THEN ccq.material
                    WHEN lae.seq IS NOT NULL THEN lae.nome
                    WHEN ddv.seq IS NOT NULL THEN ddv.nome
                    WHEN cad.seq IS NOT NULL THEN cad.nome
                    ELSE NULL::character varying
                END AS "case"
           FROM agh.ael_solicitacao_exames soetemp
             LEFT JOIN agh.agh_atendimentos atd_1 ON atd_1.seq = soetemp.atd_seq
             LEFT JOIN agh.aip_pacientes pac_atd ON pac_atd.codigo = atd_1.pac_codigo
             LEFT JOIN agh.ael_atendimento_diversos atv ON atv.seq = soetemp.atv_seq
             LEFT JOIN agh.aip_pacientes pac_atv ON pac_atv.codigo = atv.pac_codigo
             LEFT JOIN agh.ael_projeto_pesquisas pjq ON pjq.seq = atv.pjq_seq
             LEFT JOIN agh.ael_cad_ctrl_qualidades ccq ON ccq.seq = atv.ccq_seq
             LEFT JOIN agh.ael_laboratorio_externos lae ON lae.seq = atv.lae_seq
             LEFT JOIN agh.ael_dados_cadaveres ddv ON ddv.seq = atv.ddv_seq
             LEFT JOIN agh.abs_candidatos_doadores cad ON cad.seq = atv.cad_seq
          WHERE soetemp.seq = soe.seq) AS nome_paciente,
    ( SELECT COALESCE(pac.prontuario, atv.prontuario) AS "coalesce"
           FROM agh.ael_solicitacao_exames soetemp
             LEFT JOIN agh.agh_atendimentos atd_1 ON atd_1.seq = soetemp.atd_seq
             LEFT JOIN agh.ael_atendimento_diversos atv ON atv.seq = soetemp.atv_seq
             LEFT JOIN agh.aip_pacientes pac ON pac.codigo = COALESCE(atd_1.pac_codigo, atv.pac_codigo)
          WHERE soetemp.seq = soe.seq) AS prontuario,
    ( SELECT
                CASE
                    WHEN atd_1.origem::text = 'N'::text THEN 'I'::character varying
                    WHEN atd_1.origem IS NULL THEN 'D'::character varying
                    ELSE atd_1.origem
                END AS origem
           FROM agh.ael_solicitacao_exames soetemp
             LEFT JOIN agh.agh_atendimentos atd_1 ON atd_1.seq = soetemp.atd_seq
             LEFT JOIN agh.ael_atendimento_diversos atv ON atv.seq = soetemp.atv_seq
          WHERE soetemp.seq = soe.seq) AS origem,
    ( SELECT
                CASE
                    WHEN atd_1.lto_lto_id IS NOT NULL THEN 'L:'::text || atd_1.lto_lto_id::text
                    WHEN qrt_1.descricao IS NOT NULL THEN 'Q:'::text || qrt_1.descricao::text
                    WHEN atd_1.unf_seq IS NOT NULL THEN (((('U:'::text || auf.andar::text) || ' '::text) || auf.ind_ala::text) || ' - '::text) || auf.descricao::text
                    ELSE NULL::text
                END AS "case"
           FROM agh.ael_solicitacao_exames soetemp
             LEFT JOIN agh.agh_atendimentos atd_1 ON atd_1.seq = soetemp.atd_seq
             LEFT JOIN agh.ain_quartos qrt_1 ON atd_1.qrt_numero = qrt_1.numero
             LEFT JOIN agh.agh_unidades_funcionais auf ON auf.seq = atd_1.unf_seq
          WHERE soetemp.seq = soe.seq) AS localizacao
   FROM agh.ael_item_solicitacao_exames ise
     JOIN agh.ael_exames exa ON exa.sigla::text = ise.ufe_ema_exa_sigla::text
     JOIN agh.ael_materiais_analises man ON man.seq = ise.ufe_ema_man_seq
     JOIN agh.ael_extrato_item_solics eis ON eis.ise_soe_seq = ise.soe_seq AND eis.ise_seqp = ise.seqp AND eis.sit_codigo::text = ise.sit_codigo::text
     JOIN agh.ael_solicitacao_exames soe ON soe.seq = ise.soe_seq
     JOIN agh.fat_convenios_saude cnv ON cnv.codigo = soe.csp_cnv_codigo
     LEFT JOIN agh.rap_servidores ser ON ser.matricula = soe.ser_matricula_eh_responsabilid AND ser.vin_codigo = soe.ser_vin_codigo_eh_responsabili
     LEFT JOIN agh.rap_pessoas_fisicas pes ON pes.codigo = ser.pes_codigo
     LEFT JOIN agh.agh_atendimentos atd ON atd.seq = soe.atd_seq
     LEFT JOIN agh.ain_quartos qrt ON atd.qrt_numero = qrt.numero
     LEFT JOIN agh.ael_amostra_item_exames aie ON aie.ise_soe_seq = ise.soe_seq AND aie.ise_seqp = ise.seqp
  WHERE (eis.criado_em IN ( SELECT max(eis1.criado_em) AS max
           FROM agh.ael_extrato_item_solics eis1
          WHERE eis1.ise_soe_seq = eis.ise_soe_seq AND eis1.ise_seqp = eis.ise_seqp))
  GROUP BY soe.seq, soe.atd_seq, soe.criado_em, man.descricao, eis.dthr_evento, (exa.descricao_usual::text || ' /  '::text) || man.descricao::text, pes.nome, cnv.descricao, atd.lto_lto_id, atd.qrt_numero, qrt.descricao, atd.unf_seq, ise.dthr_programada, cnv.grupo_convenio, aie.origem_mapa, ise.ufe_ema_exa_sigla, ise.sit_codigo, ise.ufe_unf_seq, ( SELECT
                CASE
                    WHEN soetemp.atd_seq > 0 THEN pac_atd.nome
                    WHEN pac_atv.nome IS NOT NULL THEN
                    CASE
                        WHEN pjq.numero IS NOT NULL THEN ((('GPP-'::text || pjq.numero::text) || ' - '::text) || pac_atv.nome::text)::character varying
                        ELSE pac_atv.nome
                    END
                    WHEN atv.nome_paciente IS NOT NULL THEN
                    CASE
                        WHEN pjq.numero IS NOT NULL THEN ((('GPP-'::text || pjq.numero::text) || ' - '::text) || atv.nome_paciente::text)::character varying
                        ELSE atv.nome_paciente
                    END
                    WHEN pjq.numero IS NOT NULL THEN ((('GPP-'::text || pjq.numero::text) || ' - '::text) || pjq.nome::text)::character varying
                    WHEN ccq.seq IS NOT NULL THEN ccq.material
                    WHEN lae.seq IS NOT NULL THEN lae.nome
                    WHEN ddv.seq IS NOT NULL THEN ddv.nome
                    WHEN cad.seq IS NOT NULL THEN cad.nome
                    ELSE NULL::character varying
                END AS "case"
           FROM agh.ael_solicitacao_exames soetemp
             LEFT JOIN agh.agh_atendimentos atd_1 ON atd_1.seq = soetemp.atd_seq
             LEFT JOIN agh.aip_pacientes pac_atd ON pac_atd.codigo = atd_1.pac_codigo
             LEFT JOIN agh.ael_atendimento_diversos atv ON atv.seq = soetemp.atv_seq
             LEFT JOIN agh.aip_pacientes pac_atv ON pac_atv.codigo = atv.pac_codigo
             LEFT JOIN agh.ael_projeto_pesquisas pjq ON pjq.seq = atv.pjq_seq
             LEFT JOIN agh.ael_cad_ctrl_qualidades ccq ON ccq.seq = atv.ccq_seq
             LEFT JOIN agh.ael_laboratorio_externos lae ON lae.seq = atv.lae_seq
             LEFT JOIN agh.ael_dados_cadaveres ddv ON ddv.seq = atv.ddv_seq
             LEFT JOIN agh.abs_candidatos_doadores cad ON cad.seq = atv.cad_seq
          WHERE soetemp.seq = soe.seq), ( SELECT COALESCE(pac.prontuario, atv.prontuario) AS "coalesce"
           FROM agh.ael_solicitacao_exames soetemp
             LEFT JOIN agh.agh_atendimentos atd_1 ON atd_1.seq = soetemp.atd_seq
             LEFT JOIN agh.ael_atendimento_diversos atv ON atv.seq = soetemp.atv_seq
             LEFT JOIN agh.aip_pacientes pac ON pac.codigo = COALESCE(atd_1.pac_codigo, atv.pac_codigo)
          WHERE soetemp.seq = soe.seq), ( SELECT
                CASE
                    WHEN atd_1.origem::text = 'N'::text THEN 'I'::character varying
                    WHEN atd_1.origem IS NULL THEN 'D'::character varying
                    ELSE atd_1.origem
                END AS origem
           FROM agh.ael_solicitacao_exames soetemp
             LEFT JOIN agh.agh_atendimentos atd_1 ON atd_1.seq = soetemp.atd_seq
             LEFT JOIN agh.ael_atendimento_diversos atv ON atv.seq = soetemp.atv_seq
          WHERE soetemp.seq = soe.seq), ( SELECT
                CASE
                    WHEN atd_1.lto_lto_id IS NOT NULL THEN 'L:'::text || atd_1.lto_lto_id::text
                    WHEN qrt_1.descricao IS NOT NULL THEN 'Q:'::text || qrt_1.descricao::text
                    WHEN atd_1.unf_seq IS NOT NULL THEN (((('U:'::text || auf.andar::text) || ' '::text) || auf.ind_ala::text) || ' - '::text) || auf.descricao::text
                    ELSE NULL::text
                END AS "case"
           FROM agh.ael_solicitacao_exames soetemp
             LEFT JOIN agh.agh_atendimentos atd_1 ON atd_1.seq = soetemp.atd_seq
             LEFT JOIN agh.ain_quartos qrt_1 ON atd_1.qrt_numero = qrt_1.numero
             LEFT JOIN agh.agh_unidades_funcionais auf ON auf.seq = atd_1.unf_seq
          WHERE soetemp.seq = soe.seq);

ALTER TABLE agh.v_ael_exame_solic_atd_aghu
    OWNER TO postgres;

GRANT ALL ON TABLE agh.v_ael_exame_solic_atd_aghu TO acesso_completo;
GRANT ALL ON TABLE agh.v_ael_exame_solic_atd_aghu TO postgres;
GRANT SELECT ON TABLE agh.v_ael_exame_solic_atd_aghu TO acesso_leitura;

CREATE OR REPLACE VIEW agh.v_abs_unf_executa_exames
 AS
 SELECT exa.sigla,
    man.seq AS man_seq,
    ufe.unf_seq,
    exa.descricao_usual AS descricao_usual_exame
   FROM agh.ael_exames exa,
    agh.ael_exames_material_analise ema,
    agh.ael_materiais_analises man,
    agh.ael_unf_executa_exames ufe,
    agh.agh_unidades_funcionais unf,
    agh.agh_caract_unid_funcionais cuf
  WHERE ufe.ind_situacao::text = 'A'::text AND ema.exa_sigla::text = ufe.ema_exa_sigla::text AND ema.man_seq = ufe.ema_man_seq AND ema.ind_situacao::text = 'A'::text AND exa.sigla::text = ema.exa_sigla::text AND man.seq = ema.man_seq AND unf.seq = ufe.unf_seq AND unf.seq = cuf.unf_seq AND (cuf.caracteristica::text = ANY (ARRAY['Unid sorologia doadores'::character varying::text, 'Unid Radioimunoensaio'::character varying::text]));

ALTER TABLE agh.v_abs_unf_executa_exames
    OWNER TO postgres;

GRANT ALL ON TABLE agh.v_abs_unf_executa_exames TO acesso_completo;
GRANT ALL ON TABLE agh.v_abs_unf_executa_exames TO postgres;
GRANT SELECT ON TABLE agh.v_abs_unf_executa_exames TO acesso_leitura;


END $$