DO
$$
BEGIN

IF EXISTS (
        SELECT 1
        FROM information_schema.columns
        WHERE table_schema = 'agh'
        AND table_name = 'sco_materiais'
        AND column_name = 'codigo_ebserh'
    ) THEN

    alter table AGH.SCO_MATERIAIS alter column CODIGO_EBSERH type char(6);
    update AGH.SCO_MATERIAIS set CODIGO_EBSERH = lpad(CODIGO_EBSERH, 6, '0') where CODIGO_EBSERH is not null;

END IF;

IF EXISTS (
        SELECT 1
        FROM information_schema.columns
        WHERE table_schema = 'agh'
        AND table_name = 'sco_materiais'
        AND column_name = 'codigo_tipo_ebserh'
    ) THEN

    update AGH.SCO_MATERIAIS
    set CODIGO_TIPO_EBSERH = upper(CODIGO_TIPO_EBSERH)
    where CODIGO_TIPO_EBSERH is not null;

    update AGH.SCO_MATERIAIS
    set CODIGO_TIPO_EBSERH = null, CODIGO_EBSERH = null, VARIACAO_EBSERH = null
    where CODIGO_TIPO_EBSERH is not null
      and CODIGO_TIPO_EBSERH not in ('EBF', 'EBS', 'EBL', 'EBC', 'EBQ', 'EBN', 'EBH', 'PROVPPS', 'PROVMED');

END IF;

END $$;