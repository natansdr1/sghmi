DO $$
BEGIN

	IF NOT EXISTS (
		SELECT
		FROM information_schema.columns
		WHERE table_schema = 'agh'
		AND table_name = 'sce_item_rms'
		AND column_name = 'dips_mdto_seq'
	) THEN
ALTER TABLE agh.sce_item_rms ADD COLUMN dips_mdto_seq bigint;
COMMENT ON COLUMN agh.sce_item_rms.dips_mdto_seq IS 'Guardar o seq da dispensação para ter referencia na devolução quando a requisição de materiais já estiver efetivada e for feito o estorno';
	RAISE NOTICE 'EXECUTADO ALTERAÇÃO: #25688 - Novas coluna agh.sce_item_rms';
END IF;

END $$