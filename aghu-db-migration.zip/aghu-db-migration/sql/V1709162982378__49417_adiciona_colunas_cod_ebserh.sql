DO
$$
BEGIN

   IF NOT EXISTS (
            SELECT 1
            FROM information_schema.columns
            WHERE table_schema = 'agh'
            AND table_name = 'sco_materiais'
            AND column_name = 'codigo_ebserh'
        ) THEN

        alter table AGH.SCO_MATERIAIS add column CODIGO_EBSERH char(5);

    END IF;

   IF NOT EXISTS (
            SELECT 1
            FROM information_schema.columns
            WHERE table_schema = 'agh'
            AND table_name = 'sco_materiais'
            AND column_name = 'codigo_tipo_ebserh'
        ) THEN

        alter table AGH.SCO_MATERIAIS add column CODIGO_TIPO_EBSERH varchar(20);

    END IF;

   IF NOT EXISTS (
            SELECT 1
            FROM information_schema.columns
            WHERE table_schema = 'agh'
            AND table_name = 'sco_materiais'
            AND column_name = 'variacao_ebserh'
        ) THEN

        alter table AGH.SCO_MATERIAIS add column VARIACAO_EBSERH char(3);

    END IF;

   IF EXISTS (
        SELECT 1
        FROM information_schema.columns
        WHERE table_schema = 'agh'
        AND table_name = 'sco_materiais'
        AND column_name = 'cod_ebserh'
    ) THEN

        update AGH.SCO_MATERIAIS set codigo_tipo_ebserh=substring(cod_ebserh, 0, 4), codigo_ebserh=substring(cod_ebserh, 4) where cod_ebserh is not null;

        alter table AGH.SCO_MATERIAIS drop column cod_ebserh;

    END IF;

END $$;