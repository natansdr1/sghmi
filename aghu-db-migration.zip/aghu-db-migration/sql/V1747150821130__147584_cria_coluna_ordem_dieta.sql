do $$
begin
 
    if not exists(
            select 1
            from information_schema.columns
            where table_schema = 'agh'
                and table_name = 'mpm_prescricao_dietas'
                and column_name = 'ordem'
        ) then
alter table agh.mpm_prescricao_dietas add column ordem int4 null;
end if;
 
end $$