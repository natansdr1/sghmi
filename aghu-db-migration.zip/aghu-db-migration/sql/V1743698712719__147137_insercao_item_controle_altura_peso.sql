DO $$
DECLARE
  v_descricao_grupo TEXT := 'Monitorização Metabólica';
  v_ordem_grupo INT2 := 5;
  v_tipo_monitorizacao TEXT = 'MN';
  v_descricao_kg TEXT := 'Kg';
  v_descricao_m TEXT := 'm';
  v_descricao_peso TEXT := 'Peso';
  v_sigla_peso TEXT := 'Peso';
  v_ordem_peso INT2 := 3;
  v_descricao_altura TEXT := 'Altura';
  v_sigla_altura TEXT := 'Alt';
  v_tipo_medicao_numerica TEXT := 'NU';
  v_ordem_altura INT2 := 2;
  v_sequence_peso INT;
  v_sequence_altura INT;
  v_matricula_aghu INT;
  v_vinculo_aghu SMALLINT;
BEGIN

  RAISE INFO 'Iniciando processo de inclusão de itens de controle: Altura e Peso';

  SELECT matricula, vin_codigo
  INTO v_matricula_aghu, v_vinculo_aghu
  FROM agh.rap_servidores ser
  JOIN agh.rap_pessoas_fisicas pes
    ON ser.pes_codigo = pes.codigo
  WHERE lower(pes.nome) like '%aghu%';

  RAISE INFO 'Identificada matrícula (%) e vínculo (%) do AGHU'
    , v_matricula_aghu, v_vinculo_aghu;

  IF NOT EXISTS (
    SELECT 1
    FROM agh.ecp_grupo_controles
    WHERE lower(descricao) = lower(v_descricao_grupo)
  ) THEN
    INSERT INTO agh.ecp_grupo_controles (
      seq, descricao, ordem, situacao
    , criado_em, ser_matricula, ser_vin_codigo
    , "version", tipo
    )
    VALUES (
      NEXTVAL('agh.ecp_gco_sq1')
    , v_descricao_grupo
    , v_ordem_grupo
    , 'A'
    , NOW()
    , v_matricula_aghu
    , v_vinculo_aghu
    , 0
    , v_tipo_monitorizacao
    );

    RAISE INFO 'Inserido grupo de controle: %', v_descricao_grupo;
  END IF;

  IF NOT EXISTS (
    SELECT 1
    FROM agh.mpm_unidade_medida_medicas
    WHERE lower(descricao) = lower(v_descricao_kg)
  ) THEN
    INSERT INTO agh.mpm_unidade_medida_medicas (
      seq, ser_matricula, ser_vin_codigo
    , descricao, criado_em
    )
    VALUES (
      NEXTVAL('agh.mpm_umm_sq1')
    , v_matricula_aghu
    , v_vinculo_aghu
    , v_descricao_kg
    , NOW()
    );

    RAISE INFO 'Inserida unidade de medida médica: %', v_descricao_kg;
  END IF;

  IF NOT EXISTS (
    SELECT 1
    FROM agh.mpm_unidade_medida_medicas
    WHERE lower(descricao) = lower(v_descricao_m)
  ) THEN
    INSERT INTO agh.mpm_unidade_medida_medicas (
      seq, ser_matricula, ser_vin_codigo
    , descricao, criado_em
    )
    VALUES (
      NEXTVAL('agh.mpm_umm_sq1')
    , v_matricula_aghu
    , v_vinculo_aghu
    , v_descricao_m
    , NOW()
    );

    RAISE INFO 'Inserida unidade de medida médica: %', v_descricao_m;
  END IF;

  IF EXISTS (
    SELECT 1
    FROM agh.ecp_item_controles
    WHERE lower(descricao) != lower(v_descricao_peso)
    AND lower(sigla) = lower(v_sigla_peso)
  ) THEN
    UPDATE agh.ecp_item_controles
    SET sigla = LEFT(v_sigla_peso, LENGTH(v_sigla_peso) - 1)
    WHERE lower(sigla) = lower(v_sigla_peso);

    RAISE INFO 'Encontrado item de controle com a sigla %, mas com outra descrição.', v_sigla_peso;
    RAISE INFO 'Alterada a sigla para %.', LEFT(v_sigla_peso, LENGTH(v_sigla_peso) - 1);
  END IF;

  IF EXISTS (
    SELECT 1
    FROM agh.ecp_item_controles
    WHERE lower(descricao) != lower(v_descricao_altura)
    AND lower(sigla) = lower(v_sigla_altura)
  ) THEN
    UPDATE agh.ecp_item_controles
    SET sigla = LEFT(v_sigla_altura, LENGTH(v_sigla_altura) - 1)
    WHERE lower(sigla) = lower(v_sigla_altura);

    RAISE INFO 'Encontrado item de controle com a sigla %, mas com outra descrição.', v_sigla_altura;
    RAISE INFO 'Alterada a sigla para %.', LEFT(v_sigla_altura, LENGTH(v_sigla_altura) - 1);
  END IF;

  SELECT seq INTO v_sequence_peso
  FROM agh.ecp_item_controles
  WHERE lower(descricao) = lower(v_descricao_peso);

  IF (v_sequence_peso IS NULL) THEN
    INSERT INTO agh.ecp_item_controles (
      seq, descricao, sigla, ordem, tipo_medicao
    , criado_em, situacao, gco_seq, umm_seq
    , ser_matricula, ser_vin_codigo, "version"
    )
    VALUES (
      NEXTVAL('agh.ecp_ice_sq1')
    , v_descricao_peso
    , v_sigla_peso
    , v_ordem_peso
    , v_tipo_medicao_numerica
    , NOW()
    , 'A'
    , (SELECT seq FROM agh.ecp_grupo_controles WHERE lower(descricao) = lower(v_descricao_grupo))
    , (SELECT seq FROM agh.mpm_unidade_medida_medicas WHERE lower(descricao) = lower(v_descricao_kg))
    , v_matricula_aghu
    , v_vinculo_aghu
    , 0
    );

    RAISE INFO 'Inserido item de controle: %', v_descricao_peso;
  ELSE
    UPDATE agh.ecp_item_controles
      SET
        sigla = v_sigla_peso
      , umm_seq = (SELECT seq FROM agh.mpm_unidade_medida_medicas WHERE lower(descricao) = lower(v_descricao_kg))
    WHERE seq = v_sequence_peso;

    RAISE INFO 'Atualizado item de controle: %', v_descricao_peso;
  END IF;

  SELECT seq INTO v_sequence_altura
  FROM agh.ecp_item_controles
  WHERE lower(descricao) = lower(v_descricao_altura);

  IF (v_sequence_altura IS NULL) THEN
    INSERT INTO agh.ecp_item_controles (
      seq, descricao, sigla, ordem, tipo_medicao
    , criado_em, situacao, gco_seq, umm_seq
    , ser_matricula, ser_vin_codigo, "version"
    )
    VALUES (
      NEXTVAL('agh.ecp_ice_sq1')
    , v_descricao_altura
    , v_sigla_altura
    , v_ordem_altura
    , v_tipo_medicao_numerica
    , NOW()
    , 'A'
    , (SELECT seq FROM agh.ecp_grupo_controles WHERE lower(descricao) = lower(v_descricao_grupo))
    , (SELECT seq FROM agh.mpm_unidade_medida_medicas WHERE lower(descricao) = lower(v_descricao_m))
    , v_matricula_aghu
    , v_vinculo_aghu
    , 0
    );

    RAISE INFO 'Inserido item de controle: %', v_descricao_altura;
  ELSE
    UPDATE agh.ecp_item_controles
      SET
        sigla = v_sigla_altura
      , umm_seq = (SELECT seq FROM agh.mpm_unidade_medida_medicas WHERE lower(descricao) = lower(v_descricao_m))
    WHERE seq = v_sequence_altura;

    RAISE INFO 'Atualizado item de controle: %', v_descricao_altura;
  END IF;

  RAISE INFO 'Finalizado processo de inclusão de itens de controle: Altura e Peso';
END;
$$;
