DO $$
begin 
	
	IF not exists (SELECT COUNT(*) FROM information_schema.table_constraints AS tc WHERE tc.constraint_name = 'afa_disp_mdto_lote_pkey' and tc.table_name='afa_disp_mdto_lote') THEN
ALTER TABLE agh.afa_disp_mdto_lote ADD CONSTRAINT afa_disp_mdto_lote_pkey PRIMARY KEY (seq);
END IF;
	
	IF not exists (SELECT COUNT(*) FROM information_schema.table_constraints AS tc WHERE tc.constraint_name = 'afa_disp_mdto_lote_fk1' and tc.table_name='afa_disp_mdto_lote') THEN
ALTER TABLE agh.afa_disp_mdto_lote ADD CONSTRAINT afa_disp_mdto_lote_fk1 FOREIGN KEY (dsm_seq) REFERENCES agh.afa_dispensacao_mdtos (seq);
END IF;
	
	IF not exists (SELECT COUNT(*) FROM information_schema.table_constraints AS tc WHERE tc.constraint_name = 'afa_disp_mdto_lote_fk2' and tc.table_name='afa_disp_mdto_lote') THEN
ALTER TABLE agh.afa_disp_mdto_lote ADD CONSTRAINT afa_disp_mdto_lote_fk2 FOREIGN KEY (lote_mat) REFERENCES agh.sce_lotes_materiais (seq);
END IF;
	
	IF not exists (SELECT COUNT(*) FROM information_schema.table_constraints AS tc WHERE tc.constraint_name = 'afa_disp_mdto_lote_fk3' and tc.table_name='afa_disp_mdto_lote') THEN
ALTER TABLE agh.afa_disp_mdto_lote ADD CONSTRAINT afa_disp_mdto_lote_fk3 FOREIGN KEY (ser_matricula, ser_vin_codigo) REFERENCES agh.rap_servidores (matricula, vin_codigo);
END IF;
	
	IF not exists (SELECT COUNT(*) FROM information_schema.table_constraints AS tc WHERE tc.constraint_name = 'afa_disp_mdto_lote_fk4' and tc.table_name='afa_disp_mdto_lote') THEN
ALTER TABLE agh.afa_disp_mdto_lote ADD CONSTRAINT afa_disp_mdto_lote_fk4 FOREIGN KEY (eal_seq) REFERENCES agh.SCE_ESTQ_ALMOXS (seq);
END IF;

END $$