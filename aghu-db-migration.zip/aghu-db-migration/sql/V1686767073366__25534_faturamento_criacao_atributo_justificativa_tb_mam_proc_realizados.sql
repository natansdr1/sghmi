do $$
begin
	if not exists(select 1 from information_schema.columns
		where table_schema = 'agh' and table_name = 'mam_proc_realizados' and column_name = 'justificativa_quantidade') then begin
		alter table agh.mam_proc_realizados add justificativa_quantidade character varying(1000) null;
		comment on column agh.mam_proc_realizados.justificativa_quantidade
			is 'representa a justificativa para quando o campo quantidade do procedimento for maior que o estabelecido pela tabela sigtap.';
		raise notice 'coluna justificativa_quantidade criada na tabela agh.mam_proc_realizados.';
	exception
		when others then
			raise info 'error name:%', sqlerrm;
			raise info 'error state:%', sqlstate;
	end;
	end if;
end $$;