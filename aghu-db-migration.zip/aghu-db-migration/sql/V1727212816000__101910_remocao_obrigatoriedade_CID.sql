DO $$
BEGIN
    IF EXISTS (
        SELECT 1
        FROM information_schema.columns
        WHERE table_schema = 'agh'
        AND table_name = 'ael_solicitacao_exames'
        AND column_name = 'agh_cid_solicitacao_seq'
    ) THEN
        ALTER TABLE agh.ael_solicitacao_exames ALTER COLUMN agh_cid_solicitacao_seq DROP NOT NULL;
        RAISE NOTICE 'EXECUTADO ALTERAÇÃO: #101910 - Removendo restrição NOT NULL da coluna agh_cid_solicitacao_seq';
    END IF;
END $$;