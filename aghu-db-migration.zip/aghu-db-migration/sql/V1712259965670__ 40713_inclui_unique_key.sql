DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname = 'mat_inv_unique_key'
        AND conrelid = 'agh.sce_itens_mat_inventario'::regclass
    ) THEN
        alter table agh.sce_itens_mat_inventario add constraint mat_inv_unique_key unique (seq_inv,cod_material);
        RAISE NOTICE 'Constraint agh.sce_itens_mat_inventario.mat_inv_unique_key criado com sucesso.';
        analyse agh.sce_itens_mat_inventario;
        RAISE NOTICE 'Analise da tabela executada agh.sce_itens_mat_inventario.mat_inv_unique_key com sucesso.';
    END IF;
END $$