DO $$
    BEGIN
        -- Se P_CAMPO_INFORMACOES_GERAIS existir, atualiza campo sis_sigla para AEL
        IF exists(select 1 from agh.AGH_PARAMETROS p where p.nome = 'P_CAMPO_INFORMACOES_GERAIS') then
            UPDATE agh.AGH_PARAMETROS
            SET sis_sigla = 'AEL'
            WHERE nome = 'P_CAMPO_INFORMACOES_GERAIS';
            raise notice 'Registro atualizado com sucesso';
        ELSE
            raise notice 'Registro Já existente';
        END IF;
    END $$;