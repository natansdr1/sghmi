DO $$
BEGIN

	IF NOT EXISTS (
		SELECT 1
		FROM information_schema.columns
		WHERE table_schema = 'agh'
		AND table_name = 'mbc_prof_descricoes'
		AND column_name = 'ind_funcao_prof'
	) THEN

ALTER TABLE agh.mbc_prof_descricoes ADD COLUMN	ind_funcao_prof varchar(3) NULL;
ALTER TABLE agh.mbc_prof_descricoes ADD CONSTRAINT mbc_pfd_desc_ind_funcao_prof_ck1 CHECK (((ind_funcao_prof)::text = ANY (ARRAY[('MPF'::CHARACTER VARYING)::text,
    ('ANP'::CHARACTER VARYING)::text,
    ('ANR'::CHARACTER VARYING)::text,
    ('ENF'::CHARACTER VARYING)::text,
    ('INS'::CHARACTER VARYING)::text,
    ('MAX'::CHARACTER VARYING)::text,
    ('CIR'::CHARACTER VARYING)::text,
    ('MCO'::CHARACTER VARYING)::text,
    ('ANC'::CHARACTER VARYING)::text,
    ('ESE'::CHARACTER VARYING)::text,
    ('MRE'::CHARACTER VARYING)::text,
    ('OPF'::CHARACTER VARYING)::text,
    ('ORE'::CHARACTER VARYING)::text,
    ('TEF'::CHARACTER VARYING)::text,
    ('OCD'::CHARACTER VARYING)::text,
    ('TSB'::CHARACTER VARYING)::text,
    ('AXE'::CHARACTER VARYING)::text])));

COMMENT ON COLUMN agh.mbc_prof_descricoes.ind_funcao_prof IS 'Campo para dominio de função do profissional.';
	RAISE NOTICE 'EXECUTADO ALTERAÇÃO: #25228 - Novas coluna agh.mbc_prof_descricoes.ind_funcao_prof';
END IF;

    IF NOT EXISTS (
		SELECT 1
		FROM information_schema.columns
		WHERE table_schema = 'agh'
		AND table_name = 'pdt_profs'
		AND column_name = 'ind_funcao_prof'
	) THEN

ALTER TABLE agh.pdt_profs ADD COLUMN	ind_funcao_prof varchar(3) NULL;
ALTER TABLE agh.pdt_profs ADD CONSTRAINT pdt_profs_func_ind_funcao_prof_ck1 CHECK (((ind_funcao_prof)::text = ANY (ARRAY[('MPF'::CHARACTER VARYING)::text,
    ('ANP'::CHARACTER VARYING)::text,
    ('ANR'::CHARACTER VARYING)::text,
    ('ENF'::CHARACTER VARYING)::text,
    ('INS'::CHARACTER VARYING)::text,
    ('MAX'::CHARACTER VARYING)::text,
    ('CIR'::CHARACTER VARYING)::text,
    ('MCO'::CHARACTER VARYING)::text,
    ('ANC'::CHARACTER VARYING)::text,
    ('ESE'::CHARACTER VARYING)::text,
    ('MRE'::CHARACTER VARYING)::text,
    ('OPF'::CHARACTER VARYING)::text,
    ('ORE'::CHARACTER VARYING)::text,
    ('TEF'::CHARACTER VARYING)::text,
    ('OCD'::CHARACTER VARYING)::text,
    ('TSB'::CHARACTER VARYING)::text,
    ('AXE'::CHARACTER VARYING)::text])));


COMMENT ON COLUMN agh.pdt_profs.ind_funcao_prof IS 'Campo para dominio de função do profissional.';
	RAISE NOTICE 'EXECUTADO ALTERAÇÃO: #25228 - Novas coluna agh.pdt_profs.ind_funcao_prof';
END IF;

END $$