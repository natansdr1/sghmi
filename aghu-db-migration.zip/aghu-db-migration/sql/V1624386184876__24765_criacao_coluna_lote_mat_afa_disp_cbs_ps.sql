DO $$
BEGIN

	IF NOT EXISTS (
		SELECT
		FROM information_schema.columns
		WHERE table_schema = 'agh'
		AND table_name = 'afa_disp_mdto_cb_sps'
		AND column_name = 'lote_mat'
	) THEN
ALTER TABLE agh.afa_disp_mdto_cb_sps ADD COLUMN lote_mat integer;
COMMENT ON COLUMN agh.afa_disp_mdto_cb_sps.lote_mat IS 'Guardar lote materiais por codigo de barras';
	RAISE NOTICE 'EXECUTADO ALTERAÇÃO: #24765 - Novas colunas agh.afa_disp_mdto_cb_sps';
END IF;

END $$