-- Criaçao da sequence AFA_DML_SQ1 e tabela AFA_DISP_MDTO_LOTE para a melhoria dispensacaoFarmacia que possibilita o usuario a dispensar quantidade por lote
DO $$
BEGIN

IF not exists (SELECT COUNT(*) FROM information_schema.sequences WHERE sequence_schema = 'agh' AND sequence_name = 'afa_dml_sq1') THEN
    CREATE SEQUENCE AGH.AFA_DML_SQ1
        INCREMENT 1
        MINVALUE 1
        MAXVALUE 2147483646
        START 1
        CACHE 1;
    ALTER TABLE AGH.AFA_DML_SQ1 OWNER TO postgres;
    GRANT ALL ON SEQUENCE AGH.AFA_DML_SQ1 TO postgres;
    GRANT ALL ON SEQUENCE AGH.AFA_DML_SQ1 TO acesso_completo;
    GRANT SELECT ON SEQUENCE AGH.AFA_DML_SQ1 TO acesso_leitura;
END IF;

IF not exists(SELECT null FROM information_schema.tables WHERE table_schema = 'agh' AND table_name = 'afa_disp_mdto_lote') THEN
CREATE TABLE agh.AFA_DISP_MDTO_LOTE
(
    SEQ integer NOT NULL,
    DSM_SEQ bigint NOT NULL,
    LOTE_MAT integer NOT NULL,
    QTD_DISPENSADO integer NOT NULL,
    CRIADO_EM timestamp without time zone NOT NULL,
    SER_MATRICULA integer NOT NULL,
    SER_VIN_CODIGO smallint NOT NULL,
    MIC_COMPUTADOR character varying(50),
    EAL_SEQ integer NOT NULL
)
    WITH (
        OIDS=FALSE
        );
ALTER TABLE agh.AFA_DISP_MDTO_LOTE OWNER TO postgres;
GRANT ALL ON TABLE agh.AFA_DISP_MDTO_LOTE TO postgres;
GRANT ALL ON TABLE agh.AFA_DISP_MDTO_LOTE TO acesso_completo;
GRANT SELECT ON TABLE agh.AFA_DISP_MDTO_LOTE TO acesso_leitura;
RAISE NOTICE 'EXECUTADO ALTERAÇÃO: #dispensacaoFarmacia - Criação da tabela agh.AFA_DISP_MDTO_LOTE';
END IF;

END $$
