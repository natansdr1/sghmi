DO $$
DECLARE
    v_alterado INT := 0;
BEGIN
    IF EXISTS (
        SELECT 1
        FROM information_schema.tables 
        WHERE table_schema = 'agh' 
          AND table_name = 'ain_calculo_paciente_dia'
    ) THEN
        IF EXISTS (
            SELECT 1
            FROM information_schema.columns 
            WHERE table_schema = 'agh' 
              AND table_name = 'ain_calculo_paciente_dia'
              AND column_name = 'unf_seq'
              AND data_type = 'character varying'
              AND character_maximum_length = 2
        ) THEN
            BEGIN
                EXECUTE 'ALTER TABLE agh.ain_calculo_paciente_dia 
                         ALTER COLUMN unf_seq TYPE int2 USING unf_seq::int2';
                v_alterado := 1;
                RAISE NOTICE 'Tipo da coluna alterado com sucesso para int2.';
            EXCEPTION
                WHEN others THEN
                    RAISE WARNING 'Erro ao alterar o tipo da coluna: %', SQLERRM;
            END;
        ELSE
            RAISE NOTICE 'Coluna "unf_seq" não é do tipo varchar(2), nenhuma alteração feita.';
        END IF;
    ELSE
        RAISE NOTICE 'Tabela "agh.ain_calculo_paciente_dia" não encontrada.';
    END IF;
    IF v_alterado = 0 THEN
        RAISE NOTICE 'Script concluído sem alterações.';
    END IF;
END;
$$;