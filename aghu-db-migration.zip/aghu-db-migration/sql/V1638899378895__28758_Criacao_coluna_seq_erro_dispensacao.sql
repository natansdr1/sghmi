DO $$
BEGIN
    IF NOT EXISTS (
        SELECT
        FROM information_schema.columns
        WHERE table_schema ilike 'agh'
        AND table_name ilike 'SCE_ITEM_RMS'
        AND column_name ilike 'SEQ') THEN
    ALTER TABLE agh.SCE_ITEM_RMS ADD COLUMN SEQ integer;
    END IF;

    UPDATE agh.SCE_ITEM_RMS
    SET SEQ = 1
    WHERE SEQ is null;

    ALTER TABLE agh.SCE_ITEM_RMS
    DROP CONSTRAINT sce_item_rms_pkey;

    ALTER TABLE agh.SCE_ITEM_RMS
    ADD CONSTRAINT sce_item_rms_pkey PRIMARY KEY(RMS_SEQ, EAL_SEQ, SEQ);

    IF NOT EXISTS (
        SELECT
        FROM information_schema.columns
        WHERE table_schema ilike 'agh'
        AND table_name ilike 'SCE_ITEM_DAS'
        AND column_name ilike 'DIPS_MDTO_SEQ') THEN
    ALTER TABLE agh.SCE_ITEM_DAS ADD COLUMN DIPS_MDTO_SEQ bigint;
    END IF;
END $$