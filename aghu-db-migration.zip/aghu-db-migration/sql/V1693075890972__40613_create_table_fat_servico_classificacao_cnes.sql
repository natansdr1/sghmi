DO
$$
    BEGIN

        if not exists (select 1
                       from information_schema.tables
                       where table_schema = 'agh'
                         and table_name = 'fat_serv_classificacao_cnes') then

            CREATE TABLE AGH.FAT_SERV_CLASSIFICACAO_CNES
            (
                SEQ int8 NOT NULL,
                UNIDADE_ID varchar(31) NOT NULL,
                CODIGO_SERVICO varchar(3) NOT NULL,
                CODIGO_CARACTERIZACAO varchar(3),
                STATUS varchar(1),
                STATUS_MOVIMENTO varchar(1),
                SERVICO_AMBULATORIAL varchar(1),
                SERVICO_AMBULATORIAL_SUS varchar(1),
                SERVICO_HOSPITALAR varchar(1),
                SERVICO_HOSPITALAR_SUS varchar(1),
                DT_ATUALIZACAO  varchar(10),
                USUARIO  varchar(12),
                CODIGO_SERVICO_CLASSIFICACAO varchar(3),
                CPF_CNPJ_TERCEIRO varchar(14),
                RAZAO_SOCIAL_TERCEIRO varchar(60),
                DT_COMPETENCIA varchar(6),
                CRIADO_EM TIMESTAMP(6),
                ALTERADO_EM TIMESTAMP(6),
                DT_COMPETENCIA_DT timestamp(6),
                IND_SITUACAO varchar(1),
                CONSTRAINT FAT_FCSCSQ1_PK PRIMARY KEY (SEQ)
            );
            CREATE INDEX FAT_FCSCUNI1_IDX ON AGH.FAT_SERV_CLASSIFICACAO_CNES using btree (SEQ);

            comment on table AGH.FAT_SERV_CLASSIFICACAO_CNES is 'Tabela de classificação de serviços do CNES';
            comment on column AGH.FAT_SERV_CLASSIFICACAO_CNES.SEQ is 'Chave sequencial da tabela';
            comment on column AGH.FAT_SERV_CLASSIFICACAO_CNES.UNIDADE_ID is 'Código da unidade';
            comment on column AGH.FAT_SERV_CLASSIFICACAO_CNES.CODIGO_SERVICO is 'Código do serviço';
            comment on column AGH.FAT_SERV_CLASSIFICACAO_CNES.CODIGO_CARACTERIZACAO is 'Código da caracterização';
            comment on column AGH.FAT_SERV_CLASSIFICACAO_CNES.STATUS is 'Status do registro';
            comment on column AGH.FAT_SERV_CLASSIFICACAO_CNES.STATUS_MOVIMENTO is 'Status do movimento';
            comment on column AGH.FAT_SERV_CLASSIFICACAO_CNES.SERVICO_AMBULATORIAL is 'Serviço ambulatorial';
            comment on column AGH.FAT_SERV_CLASSIFICACAO_CNES.SERVICO_AMBULATORIAL_SUS is 'Serviço ambulatorial SUS';
            comment on column AGH.FAT_SERV_CLASSIFICACAO_CNES.SERVICO_HOSPITALAR is 'Serviço hospitalar';
            comment on column AGH.FAT_SERV_CLASSIFICACAO_CNES.SERVICO_HOSPITALAR_SUS is 'Serviço hospitalar SUS';
            comment on column AGH.FAT_SERV_CLASSIFICACAO_CNES.DT_ATUALIZACAO is 'Data de atualização';
            comment on column AGH.FAT_SERV_CLASSIFICACAO_CNES.USUARIO is 'Usuário';
            comment on column AGH.FAT_SERV_CLASSIFICACAO_CNES.CODIGO_SERVICO_CLASSIFICACAO is 'Código do serviço de classificação';
            comment on column AGH.FAT_SERV_CLASSIFICACAO_CNES.CPF_CNPJ_TERCEIRO is 'CPF/CNPJ do terceiro';
            comment on column AGH.FAT_SERV_CLASSIFICACAO_CNES.RAZAO_SOCIAL_TERCEIRO is 'Razão social do terceiro';
            comment on column AGH.FAT_SERV_CLASSIFICACAO_CNES.DT_COMPETENCIA is 'Data de competência';
            comment on column AGH.FAT_SERV_CLASSIFICACAO_CNES.CRIADO_EM is 'Data de criação do registro';
            comment on column AGH.FAT_SERV_CLASSIFICACAO_CNES.ALTERADO_EM is 'Data de alteração do registro';
            comment on column AGH.FAT_SERV_CLASSIFICACAO_CNES.IND_SITUACAO is 'Indicador de situação do registro';


		    GRANT INSERT, SELECT, UPDATE, DELETE ON TABLE agh.FAT_SERV_CLASSIFICACAO_CNES TO acesso_completo;
		    GRANT SELECT ON TABLE agh.FAT_SERV_CLASSIFICACAO_CNES TO acesso_leitura;

        end if;
    end;
$$