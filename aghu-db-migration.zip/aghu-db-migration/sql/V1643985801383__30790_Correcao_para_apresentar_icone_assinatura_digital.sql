create or replace view v_afa_prcr_disp_mdtos_painel
            (atd_seq, seq, dt_referencia, dthr_inicio, dthr_fim, atd_seq_local, prontuario, lto_lto_id, qrt_numero,
             unf_seq, trp_seq, codigo, nome, apa_atd_seq, apa_seq, seqp, countsolic, countdisp, countconf, countenv,
             counttriado, countocorr, unf_descricao, configprescmed, dataprescmed, configprescmedassinada,
             esta_assinada, clinica_codigo)
as
SELECT x.atd_seq,
       x.seq,
       x.dt_referencia,
       x.dthr_inicio,
       x.dthr_fim,
       x.atd_seq_local,
       x.prontuario,
       x.lto_lto_id,
       x.qrt_numero,
       x.unf_seq,
       x.trp_seq,
       x.codigo,
       x.nome,
       x.apa_atd_seq,
       x.apa_seq,
       x.seqp,
       x.countsolic,
       x.countdisp,
       x.countconf,
       x.countenv,
       x.counttriado,
       x.countocorr,
       (((COALESCE(unf.andar, ''::character varying)::text || ' '::text) ||
         COALESCE(unf.ind_ala, ''::character varying)::text) || ' - '::text) ||
       COALESCE(unf.descricao, ''::character varying)::text AS unf_descricao,
       CASE
           WHEN
                   CASE
                       WHEN atd.ind_pac_atendimento::text = 'S'::text AND cuf.unf_seq IS NOT NULL THEN 'false'::text
                       ELSE 'true'::text
END = 'true'::text THEN ''::text
           WHEN NOT ((SELECT count(*) AS count
                      FROM agh.mpm_prescricao_medicas pm
                      WHERE pm.atd_seq = atd.seq
                        AND pm.ser_matricula_valida IS NOT NULL
                        AND pm.ser_vin_codigo_valida IS NOT NULL
                        AND pm.dthr_fim > now())) > 0 THEN 'PRESCRICAO_NAO_REALIZADA'::text
           WHEN NOT ((SELECT count(*) AS count
                      FROM agh.mpm_prescricao_medicas pm
                      WHERE pm.atd_seq = atd.seq
                        AND pm.ser_matricula_valida IS NOT NULL
                        AND pm.ser_vin_codigo_valida IS NOT NULL
                        AND pm.dthr_inicio > now()
                        AND to_char(unf.hrio_validade_pme, 'HH24:mi'::text) =
                            to_char(pm.dthr_inicio, 'HH24:mi'::text))) > 0 THEN 'PRESCRICAO_VENCE_NO_DIA'::text
           ELSE 'PRESCRICAO_VENCE_NO_DIA_SEGUINTE'::text
END                                              AS configprescmed,
       CASE
           WHEN
                   CASE
                       WHEN atd.ind_pac_atendimento::text = 'S'::text AND cuf.unf_seq IS NOT NULL THEN 'false'::text
                       ELSE 'true'::text
END = 'true'::text THEN NULL::timestamp without time zone
           WHEN NOT ((SELECT count(*) AS count
                      FROM agh.mpm_prescricao_medicas pm
                      WHERE pm.atd_seq = atd.seq
                        AND pm.ser_matricula_valida IS NOT NULL
                        AND pm.ser_vin_codigo_valida IS NOT NULL
                        AND pm.dthr_fim > now())) > 0 THEN NULL::timestamp without time zone
           ELSE (SELECT max(pm.dthr_inicio) AS dthr_inicio
                 FROM agh.mpm_prescricao_medicas pm
                 WHERE pm.atd_seq = atd.seq
                   AND pm.ser_matricula_valida IS NOT NULL
                   AND pm.ser_vin_codigo_valida IS NOT NULL
                   AND to_char(unf.hrio_validade_pme, 'HH24:mi'::text) = to_char(pm.dthr_inicio, 'HH24:mi'::text))
END                                              AS dataprescmed,
       CASE
           WHEN (select docv.situacao from agh.agh_documentos doc
                                               inner join agh.agh_versoes_documentos docv on doc.seq = docv.dok_seq
                 where doc.entidade_alvo = x.seq) = 'A' then 'ASSINADO'::text
           ELSE '' end AS configprescmedassinada,
       CASE
           WHEN ((SELECT count(docs.pac_codigo) AS count
                  FROM agh.v_agh_versoes_documentos docs
                  WHERE docs.dov_situacao::text = 'A'::text
                    AND docs.dok_tipo::text = 'PM'::text
                    AND docs.pac_codigo = atd.pac_codigo)) > 0 THEN 'ASSINADO'::text
           ELSE ''::text
END                                              AS esta_assinada,
       clinicas.codigo                                      AS clinica_codigo
FROM agh.v_afa_prcr_disp_mdtos x
         JOIN agh.agh_atendimentos atd ON atd.seq = x.atd_seq
         LEFT JOIN agh.agh_unidades_funcionais unf ON atd.unf_seq = unf.seq
         LEFT JOIN agh.agh_caract_unid_funcionais cuf
                   ON cuf.unf_seq = atd.unf_seq AND cuf.caracteristica::text = 'Pme Informatizada'::text
         LEFT JOIN agh.agh_clinicas clinicas ON unf.clc_codigo = clinicas.codigo;

alter table v_afa_prcr_disp_mdtos_painel
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on v_afa_prcr_disp_mdtos_painel to acesso_completo;

grant select on v_afa_prcr_disp_mdtos_painel to acesso_leitura;